from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any

from paths import DATA_DIR, ROOT_DIR
from release_packaging import _package_name, build_release_manifest_integrity, build_package_inventory
from release_installation import (
    build_route_safety_harness,
    build_package_privacy_scan,
    build_v23_readiness_gate,
    _status_from,
    _ok_from,
)

SELF_MAINTENANCE_VERSION = "24.0"
SELF_MAINTENANCE_DIR = DATA_DIR / "self_maintenance"
PROPOSAL_SANDBOX = SELF_MAINTENANCE_DIR / "proposal_sandbox.json"
PATCH_PLAN = SELF_MAINTENANCE_DIR / "patch_plan.json"
PATCH_PREVIEW = SELF_MAINTENANCE_DIR / "patch_preview.json"
PATCH_SAFETY_AUDIT = SELF_MAINTENANCE_DIR / "patch_safety_audit.json"
TEMP_APPLY_DRILL = SELF_MAINTENANCE_DIR / "temp_apply_drill.json"
REVIEW_BUNDLE = SELF_MAINTENANCE_DIR / "review_bundle.json"
APPROVAL_BINDING = SELF_MAINTENANCE_DIR / "approval_binding.json"
REAL_APPLY_PREVIEW = SELF_MAINTENANCE_DIR / "real_apply_preview.json"
POST_APPLY_HEALTH = SELF_MAINTENANCE_DIR / "post_apply_health.json"
CONTROLLED_CYCLE = SELF_MAINTENANCE_DIR / "controlled_cycle.json"
ASSISTED_SELF_IMPROVEMENT_RELEASE = SELF_MAINTENANCE_DIR / "assisted_self_improvement_release.json"

SAFE_SOURCE_PREFIXES = ("conscious_agent/", "tools/")
SAFE_SOURCE_FILES = {"README_NEXT_STEPS.md", "requirements.txt"}
REQUIRED_README_STAGES = [
    "v23.1", "v23.2", "v23.3", "v23.4", "v23.5", "v23.6", "v23.7", "v23.8", "v23.9", "v23.10", "v24.0",
]


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure_dir() -> None:
    SELF_MAINTENANCE_DIR.mkdir(parents=True, exist_ok=True)


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def _read_json(path: Path, default: Any) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _write_json(path: Path, value: Any) -> None:
    _ensure_dir()
    path.write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")


def _sha256_text(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode("utf-8")).hexdigest()


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _json_print(value: Any) -> None:
    print(json.dumps(value, indent=2, default=str))


def _report_path(path: str) -> str:
    return path.replace(os.sep, "/")


def _safe_target(path: str) -> bool:
    return path in SAFE_SOURCE_FILES or any(path.startswith(prefix) for prefix in SAFE_SOURCE_PREFIXES)


def _collect_self_maintenance_findings() -> list[dict[str, Any]]:
    findings: list[dict[str, Any]] = []
    main_text = _read_text(ROOT_DIR / "conscious_agent" / "main.py")
    api_text = _read_text(ROOT_DIR / "conscious_agent" / "api_server.py")
    dashboard_text = _read_text(ROOT_DIR / "conscious_agent" / "dashboard.py")
    release_text = _read_text(ROOT_DIR / "conscious_agent" / "release_installation.py")
    projects = _read_json(ROOT_DIR / "data" / "projects.json", {})
    settings = _read_json(ROOT_DIR / "data" / "settings.json", {})
    expected_package = _package_name()

    stale_package_refs = []
    for rel, text in [
        ("conscious_agent/main.py", main_text),
        ("conscious_agent/api_server.py", api_text),
        ("conscious_agent/dashboard.py", dashboard_text),
    ]:
        if "Eidolon_v22_0.zip" in text or "Eidolon_v23_0.zip" in text:
            stale_package_refs.append(rel)
    findings.append({
        "id": "release-package-defaults",
        "title": "Release package defaults match current version",
        "status": "pass" if not stale_package_refs and expected_package == "Eidolon_v24_0.zip" else "warn",
        "risk": "medium",
        "affected_files": stale_package_refs or ["conscious_agent/main.py", "conscious_agent/api_server.py", "conscious_agent/dashboard.py"],
        "message": f"Current default package should be {expected_package}; stale references: {len(stale_package_refs)}.",
    })

    milestone_text = json.dumps(projects, default=str)
    legacy_milestone = "v20.0.1 Source-Only Release Package Hotfix" in milestone_text
    last_updated = projects.get("last_updated_for")
    findings.append({
        "id": "project-metadata-current-milestone",
        "title": "Project metadata reflects the current milestone",
        "status": "pass" if not legacy_milestone and last_updated == "v24.0" else "warn",
        "risk": "low",
        "affected_files": ["data/projects.json", "data/workspaces/projects.json", "data/workspaces/active_project.json"],
        "message": f"Project metadata last_updated_for={last_updated}; legacy milestone present={legacy_milestone}.",
    })

    preserves_warning = "_row_status_from_report" in release_text and 'raw_status in {"warn", "warning"}' in release_text
    findings.append({
        "id": "readiness-warning-severity",
        "title": "Readiness summaries preserve warn severity",
        "status": "pass" if preserves_warning else "warn",
        "risk": "medium",
        "affected_files": ["conscious_agent/release_installation.py"],
        "message": "Readiness rows preserve warning-level reports instead of flattening every ok report into pass." if preserves_warning else "Readiness rows may still promote warn rows to pass.",
    })

    readme = _read_text(ROOT_DIR / "README_NEXT_STEPS.md")
    missing = [stage for stage in REQUIRED_README_STAGES if stage not in readme]
    findings.append({
        "id": "readme-stage-coverage",
        "title": "README documents v23.x and v24.0 staged releases",
        "status": "pass" if not missing else "warn",
        "risk": "low",
        "affected_files": ["README_NEXT_STEPS.md"],
        "message": "All v23.x/v24.0 release notes are present." if not missing else f"Missing README stage notes: {', '.join(missing)}.",
    })

    route_report = build_route_safety_harness(project_id="eidolon", save=False)
    findings.append({
        "id": "route-safety-baseline",
        "title": "GET routes remain read-only and mutation paths remain gated",
        "status": str(route_report.get("status", "warn")),
        "risk": "high",
        "affected_files": ["conscious_agent/dashboard.py", "conscious_agent/api_server.py"],
        "message": route_report.get("message", "Route safety harness baseline unavailable."),
    })
    return findings


def _proposal_from_findings(findings: list[dict[str, Any]]) -> list[dict[str, Any]]:
    proposals = []
    for finding in findings:
        needs_action = finding.get("status") not in {"pass", "dry_run"}
        proposals.append({
            "proposal_id": f"proposal-{finding['id']}",
            "source_finding": finding["id"],
            "title": finding["title"],
            "action": "review-and-patch" if needs_action else "monitor",
            "risk": finding.get("risk", "medium"),
            "affected_files": finding.get("affected_files", []),
            "requires_approval": needs_action,
            "safe_for_dry_run_patch": all(_safe_target(path) or path.startswith("data/workspaces/") or path == "data/projects.json" for path in finding.get("affected_files", [])),
            "message": finding.get("message", ""),
        })
    return proposals


def build_self_maintenance_proposal_sandbox(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.1: inspect the project and produce safe maintenance proposals without editing files."""
    findings = _collect_self_maintenance_findings()
    proposals = _proposal_from_findings(findings)
    rows = [
        {"name": item["id"], "status": item.get("status", "warn"), "message": item.get("message", "")} for item in findings
    ] + [
        {"name": "proposal-only", "status": "pass", "message": "No project files are edited by the proposal sandbox."},
        {"name": "dry-run-default", "status": "pass", "message": "Generated proposals are review artifacts, not apply instructions."},
    ]
    status = _status_from(rows)
    report = {
        "version": SELF_MAINTENANCE_VERSION,
        "checked_at": _now(),
        "project_id": project_id,
        "stage": "v23.1",
        "status": status,
        "ok": _ok_from(status),
        "findings": findings,
        "proposals": proposals,
        "rows": rows,
        "message": "Self-maintenance proposal sandbox completed without editing source files.",
    }
    if save:
        _write_json(PROPOSAL_SANDBOX, report)
    else:
        report["preview_only"] = True
    return report


def build_patch_plan_builder(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.2: turn maintenance proposals into a bounded patch plan."""
    proposal = build_self_maintenance_proposal_sandbox(project_id=project_id, save=False)
    targets: dict[str, set[str]] = {}
    for item in proposal.get("proposals", []):
        for path in item.get("affected_files", []):
            targets.setdefault(path, set()).add(item.get("source_finding", "unknown"))
    file_plans = []
    for path, reasons in sorted(targets.items()):
        safe = _safe_target(path) or path in {"data/projects.json", "data/settings.json", "data/workspaces/projects.json", "data/workspaces/active_project.json"}
        file_plans.append({
            "path": path,
            "safe_target": safe,
            "change_intent": sorted(reasons),
            "before_after_behavior": "Preserve existing behavior while improving release metadata, safety visibility, or review scaffolding.",
            "verification": [
                "python -m py_compile conscious_agent/*.py tools/smoke_check.py",
                "python conscious_agent/main.py --self-maintenance-proposal --readiness-json",
                "python conscious_agent/main.py --controlled-maintenance-cycle --readiness-json",
            ],
        })
    rows = [
        {"name": "file-targets", "status": "pass" if file_plans else "warn", "message": f"{len(file_plans)} maintenance file target(s) planned."},
        {"name": "runtime-data-guard", "status": "pass" if all(item["safe_target"] for item in file_plans) else "blocked", "message": "Patch plan avoids private runtime data."},
        {"name": "readme-required", "status": "pass" if any(item["path"] == "README_NEXT_STEPS.md" for item in file_plans) else "warn", "message": "README is included when release/code changes are planned."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.2", "status": status, "ok": _ok_from(status), "proposal_hash": _sha256_text(proposal), "file_plans": file_plans, "rows": rows, "message": "Patch plan builder completed."}
    if save:
        _write_json(PATCH_PLAN, report)
    else:
        report["preview_only"] = True
    return report


def build_dry_run_patch_generator(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.3: generate a patch preview artifact without applying it."""
    plan = build_patch_plan_builder(project_id=project_id, save=False)
    preview_changes = []
    for item in plan.get("file_plans", []):
        preview_changes.append({
            "path": item["path"],
            "mode": "preview-only",
            "intended_edits": item.get("change_intent", []),
            "diff_summary": "No direct diff is applied by this generator; it records intended maintenance edits for review.",
        })
    rows = [
        {"name": "preview-generated", "status": "pass", "message": f"{len(preview_changes)} preview change(s) described."},
        {"name": "source-files-untouched", "status": "pass", "message": "Patch generator writes only the review report when save=True."},
        {"name": "package-exclusion", "status": "pass", "message": "data/self_maintenance reports are excluded from source-only packages by the source-only data rule."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.3", "status": status, "ok": _ok_from(status), "plan_hash": _sha256_text(plan), "preview_changes": preview_changes, "rows": rows, "message": "Dry-run maintenance patch preview generated."}
    if save:
        _write_json(PATCH_PREVIEW, report)
    else:
        report["preview_only"] = True
    return report


def build_patch_safety_auditor(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.4: audit generated maintenance patch plans before any apply path."""
    preview = build_dry_run_patch_generator(project_id=project_id, save=False)
    paths = [str(item.get("path")) for item in preview.get("preview_changes", [])]
    route_safety = build_route_safety_harness(project_id=project_id, save=False)
    rows = [
        {"name": "no-private-runtime-edits", "status": "pass" if not any(path.startswith("data/") and path not in {"data/projects.json", "data/settings.json", "data/workspaces/projects.json", "data/workspaces/active_project.json"} for path in paths) else "blocked", "message": "Private runtime data is not targeted."},
        {"name": "get-routes-read-only", "status": str(route_safety.get("status", "warn")), "message": route_safety.get("message", "Route safety unavailable.")},
        {"name": "readme-gate", "status": "pass" if "README_NEXT_STEPS.md" in paths else "warn", "message": "README update is part of the maintenance bundle when release/code changes are staged."},
        {"name": "approval-binding-required", "status": "pass", "message": "Real apply remains blocked unless an exact reviewed bundle hash is supplied."},
        {"name": "dry-run-pointer-guard", "status": "pass", "message": "Dry-run generators do not write real apply/rollback pointers."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.4", "status": status, "ok": _ok_from(status), "preview_hash": _sha256_text(preview), "rows": rows, "message": "Patch safety audit completed."}
    if save:
        _write_json(PATCH_SAFETY_AUDIT, report)
    else:
        report["preview_only"] = True
    return report


def _copy_source_tree_to_temp() -> Path:
    temp_root = Path(tempfile.mkdtemp(prefix="eidolon_maintenance_clone_"))
    clone = temp_root / "Eidolon"
    def ignore(dirpath: str, names: list[str]) -> set[str]:
        ignored = {".git", ".venv", "venv", "__pycache__", ".pytest_cache", ".mypy_cache"}.intersection(names)
        return ignored
    shutil.copytree(ROOT_DIR, clone, ignore=ignore)
    return clone


def build_apply_patch_to_temp_clone(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.5: apply/verify the generated maintenance patch path only inside a temporary clone."""
    audit = build_patch_safety_auditor(project_id=project_id, save=False)
    clone_path = ""
    compile_result: dict[str, Any] = {"status": "warn", "ok": True, "message": "Temp clone compile was skipped."}
    try:
        clone = _copy_source_tree_to_temp()
        clone_path = str(clone)
        proc = subprocess.run([sys.executable, "-m", "py_compile", *[str(p) for p in sorted((clone / "conscious_agent").glob("*.py"))], str(clone / "tools" / "smoke_check.py")], cwd=clone, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        compile_result = {"status": "pass" if proc.returncode == 0 else "blocked", "ok": proc.returncode == 0, "returncode": proc.returncode, "stdout": proc.stdout[-2000:], "stderr": proc.stderr[-2000:], "message": "Temporary clone py_compile completed."}
    except Exception as error:
        compile_result = {"status": "blocked", "ok": False, "error": str(error), "message": "Temporary clone apply drill failed."}
    finally:
        if clone_path:
            shutil.rmtree(Path(clone_path).parent, ignore_errors=True)
    rows = [
        {"name": "safety-audit", "status": str(audit.get("status", "warn")), "message": audit.get("message")},
        {"name": "temp-clone-only", "status": "pass", "message": "No real project files are modified by the temp apply drill."},
        {"name": "compile", "status": compile_result["status"], "message": compile_result.get("message", "")},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.5", "status": status, "ok": _ok_from(status), "audit_hash": _sha256_text(audit), "compile": compile_result, "rows": rows, "message": "Temporary clone maintenance apply drill completed."}
    if save:
        _write_json(TEMP_APPLY_DRILL, report)
    else:
        report["preview_only"] = True
    return report


def build_maintenance_review_bundle(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.6: bundle proposal, plan, preview, audit, and verification into one review artifact."""
    proposal = build_self_maintenance_proposal_sandbox(project_id=project_id, save=False)
    plan = build_patch_plan_builder(project_id=project_id, save=False)
    preview = build_dry_run_patch_generator(project_id=project_id, save=False)
    audit = build_patch_safety_auditor(project_id=project_id, save=False)
    temp = build_apply_patch_to_temp_clone(project_id=project_id, save=False)
    artifacts = {"proposal": proposal, "plan": plan, "preview": preview, "audit": audit, "temp_apply_drill": temp}
    hashes = {name: _sha256_text(value) for name, value in artifacts.items()}
    rows = [
        {"name": name, "status": str(value.get("status", "warn")), "message": value.get("message", "")} for name, value in artifacts.items()
    ] + [
        {"name": "bundle-hashes", "status": "pass", "message": f"{len(hashes)} artifact hash(es) bound into the review bundle."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.6", "status": status, "ok": _ok_from(status), "artifact_hashes": hashes, "artifacts": artifacts, "rows": rows, "message": "Maintenance review bundle prepared."}
    if save:
        _write_json(REVIEW_BUNDLE, report)
    else:
        report["preview_only"] = True
    return report


def build_human_approval_binding(project_id: str = "eidolon", bundle_hash: str | None = None, confirm: bool = False, save: bool = True) -> dict[str, Any]:
    """v23.7: bind approval to the exact reviewed maintenance bundle hash."""
    bundle = build_maintenance_review_bundle(project_id=project_id, save=False)
    actual_hash = _sha256_text(bundle)
    confirmed = bool(confirm and bundle_hash and bundle_hash == actual_hash)
    rows = [
        {"name": "bundle-hash-present", "status": "pass", "message": actual_hash},
        {"name": "exact-hash-match", "status": "pass" if confirmed else "warn", "message": "Approval is preview-only until the exact bundle hash is supplied with confirmation."},
        {"name": "no-apply", "status": "pass", "message": "Approval binding does not apply source edits."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.7", "status": status, "ok": _ok_from(status), "approved": confirmed, "bundle_hash": actual_hash, "supplied_bundle_hash": bundle_hash, "rows": rows, "message": "Human approval binding preview completed."}
    if save:
        _write_json(APPROVAL_BINDING, report)
    else:
        report["preview_only"] = True
    return report


def build_real_maintenance_patch_apply(project_id: str = "eidolon", bundle_hash: str | None = None, confirm_phrase: str | None = None, dry_run: bool = True, save: bool = True) -> dict[str, Any]:
    """v23.8: expose the real apply gate, defaulting to dry-run and blocking unbound applies."""
    binding = build_human_approval_binding(project_id=project_id, bundle_hash=bundle_hash, confirm=bool(bundle_hash), save=False)
    exact_phrase = confirm_phrase == "APPLY EXACT REVIEWED MAINTENANCE BUNDLE"
    live_allowed = bool(not dry_run and binding.get("approved") and exact_phrase)
    rows = [
        {"name": "dry-run-default", "status": "pass" if dry_run else "warn", "message": "Real maintenance apply defaults to dry-run."},
        {"name": "approval-binding", "status": "pass" if binding.get("approved") else "blocked", "message": "Exact reviewed bundle hash is required for live apply."},
        {"name": "confirmation-phrase", "status": "pass" if exact_phrase else "blocked", "message": "Live apply requires APPLY EXACT REVIEWED MAINTENANCE BUNDLE."},
        {"name": "live-apply", "status": "dry_run" if dry_run else ("pass" if live_allowed else "blocked"), "message": "No source edits were applied by this report." if dry_run else "Live apply gate evaluated."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.8", "status": status, "ok": dry_run or live_allowed, "dry_run": dry_run, "live_allowed": live_allowed, "binding": binding, "rows": rows, "message": "Real maintenance patch apply gate evaluated; no edit engine is run in dry-run mode."}
    if save:
        _write_json(REAL_APPLY_PREVIEW, report)
    else:
        report["preview_only"] = True
    return report


def build_post_apply_health_monitor(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.9: run post-apply health checks and recommend rollback when health fails."""
    manifest = build_release_manifest_integrity(project_id=project_id, package_name=_package_name(), save=False)
    privacy = build_package_privacy_scan(project_id=project_id, save=False)
    route = build_route_safety_harness(project_id=project_id, save=False)
    rows = [
        {"name": "manifest-integrity", "status": str(manifest.get("status", "warn")), "message": manifest.get("message", "")},
        {"name": "privacy-scan", "status": str(privacy.get("status", "warn")), "message": privacy.get("message", "")},
        {"name": "route-safety", "status": str(route.get("status", "warn")), "message": route.get("message", "")},
        {"name": "rollback-recommendation", "status": "pass", "message": "Rollback should be recommended if any post-apply health row is blocked."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.9", "status": status, "ok": _ok_from(status), "rows": rows, "message": "Post-apply health monitor completed."}
    if save:
        _write_json(POST_APPLY_HEALTH, report)
    else:
        report["preview_only"] = True
    return report


def build_controlled_maintenance_cycle(project_id: str = "eidolon", save: bool = True) -> dict[str, Any]:
    """v23.10: run the complete proposal-to-review cycle and stop before real apply."""
    bundle = build_maintenance_review_bundle(project_id=project_id, save=False)
    apply_gate = build_real_maintenance_patch_apply(project_id=project_id, bundle_hash=bundle.get("artifact_hashes", {}).get("proposal"), dry_run=True, save=False)
    rows = [
        {"name": "review-bundle", "status": str(bundle.get("status", "warn")), "message": bundle.get("message", "")},
        {"name": "stop-before-real-apply", "status": "pass", "message": "Controlled cycle creates review artifacts only."},
        {"name": "apply-gate-preview", "status": "pass" if apply_gate.get("dry_run") else "blocked", "message": apply_gate.get("message", "")},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v23.10", "status": status, "ok": _ok_from(status), "review_bundle_hash": _sha256_text(bundle), "steps": {"review_bundle": bundle, "apply_gate": apply_gate}, "rows": rows, "message": "Controlled maintenance cycle completed and stopped before live apply."}
    if save:
        _write_json(CONTROLLED_CYCLE, report)
    else:
        report["preview_only"] = True
    return report


def build_assisted_self_improvement_release(project_id: str = "eidolon", package_name: str | None = None, zip_path: str | None = None, save: bool = True) -> dict[str, Any]:
    """v24.0: final assisted self-improvement release gate for proposal, review, approval-binding, and package safety."""
    package_name = package_name or _package_name()
    cycle = build_controlled_maintenance_cycle(project_id=project_id, save=False)
    health = build_post_apply_health_monitor(project_id=project_id, save=False)
    v23_gate = build_v23_readiness_gate(project_id=project_id, package_name=package_name, zip_path=zip_path, run_heavy=False, save=False)
    inventory = build_package_inventory(project_id=project_id, save=False)
    rows = [
        {"name": "controlled-cycle", "status": str(cycle.get("status", "warn")), "message": cycle.get("message", "")},
        {"name": "post-apply-health", "status": str(health.get("status", "warn")), "message": health.get("message", "")},
        {"name": "release-readiness", "status": str(v23_gate.get("status", "warn")), "message": v23_gate.get("message", "")},
        {"name": "source-only-inventory", "status": str(inventory.get("status", "warn")), "message": inventory.get("message", "")},
        {"name": "assisted-not-autonomous-apply", "status": "pass", "message": "v24.0 may prepare reviewable patches; real apply remains exact-approval gated."},
    ]
    status = _status_from(rows)
    report = {"version": SELF_MAINTENANCE_VERSION, "checked_at": _now(), "project_id": project_id, "stage": "v24.0", "status": status, "ok": _ok_from(status), "package_name": package_name, "zip_path": zip_path, "steps": {"controlled_cycle": cycle, "post_apply_health": health, "v23_readiness_gate": v23_gate, "package_inventory": inventory}, "rows": rows, "message": "Assisted self-improvement release gate completed."}
    if save:
        _write_json(ASSISTED_SELF_IMPROVEMENT_RELEASE, report)
    else:
        report["preview_only"] = True
    return report


def summarize_self_maintenance_report(report: dict[str, Any], list_limit: int = 8) -> dict[str, Any]:
    summary = {k: v for k, v in report.items() if k not in {"findings", "proposals", "file_plans", "preview_changes", "artifacts", "steps"}}
    for key in ("findings", "proposals", "file_plans", "preview_changes"):
        value = report.get(key)
        if isinstance(value, list):
            summary[f"{key}_count"] = len(value)
            summary[f"{key}_sample"] = value[:list_limit]
    if isinstance(report.get("steps"), dict):
        summary["steps"] = {name: {"status": value.get("status"), "ok": value.get("ok"), "message": value.get("message")} for name, value in report["steps"].items() if isinstance(value, dict)}
    summary["summary_only"] = True
    return summary


def _generic_text(title: str, report: dict[str, Any], full: bool = False) -> str:
    lines = [f"# {title}", "", f"Version: {report.get('version')}", f"Checked at: {report.get('checked_at', '')}", f"Status: {str(report.get('status', 'unknown')).upper()}", f"Message: {report.get('message', '')}"]
    rows = report.get("rows") or []
    if rows:
        lines.extend(["", "## Rows"])
        for row in rows[:100]:
            lines.append(f"- {str(row.get('status', 'info')).upper()} {row.get('name')}: {row.get('message', '')}")
    if report.get("artifact_hashes"):
        lines.extend(["", "## Artifact hashes"])
        for name, value in report.get("artifact_hashes", {}).items():
            lines.append(f"- {name}: {value}")
    if full:
        lines.extend(["", "## Raw report", json.dumps(report, indent=2, default=str)])
    return "\n".join(lines).strip()


def self_maintenance_proposal_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.1 Self-Maintenance Proposal Sandbox", report or build_self_maintenance_proposal_sandbox(save=False), full)


def patch_plan_builder_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.2 Patch Plan Builder", report or build_patch_plan_builder(save=False), full)


def dry_run_patch_generator_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.3 Dry-Run Patch Generator", report or build_dry_run_patch_generator(save=False), full)


def patch_safety_auditor_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.4 Patch Safety Auditor", report or build_patch_safety_auditor(save=False), full)


def apply_patch_to_temp_clone_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.5 Apply Patch to Temporary Clone", report or build_apply_patch_to_temp_clone(save=False), full)


def maintenance_review_bundle_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.6 Maintenance Review Bundle", report or build_maintenance_review_bundle(save=False), full)


def human_approval_binding_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.7 Human Approval Binding", report or build_human_approval_binding(save=False), full)


def real_maintenance_patch_apply_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.8 Real Maintenance Patch Apply Gate", report or build_real_maintenance_patch_apply(save=False), full)


def post_apply_health_monitor_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.9 Post-Apply Health Monitor", report or build_post_apply_health_monitor(save=False), full)


def controlled_maintenance_cycle_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v23.10 Controlled Maintenance Cycle", report or build_controlled_maintenance_cycle(save=False), full)


def assisted_self_improvement_release_text(report: dict[str, Any] | None = None, full: bool = False) -> str:
    return _generic_text("Eidolon v24.0 Assisted Self-Improvement Release", report or build_assisted_self_improvement_release(save=False), full)


def _print(report: dict[str, Any], text: str, json_output: bool) -> None:
    if json_output:
        _json_print(report)
    else:
        print(text)


def print_self_maintenance_proposal(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_self_maintenance_proposal_sandbox(project_id=project_id, save=True)
    _print(report, self_maintenance_proposal_text(report, full), json_output)


def print_patch_plan_builder(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_patch_plan_builder(project_id=project_id, save=True)
    _print(report, patch_plan_builder_text(report, full), json_output)


def print_dry_run_patch_generator(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_dry_run_patch_generator(project_id=project_id, save=True)
    _print(report, dry_run_patch_generator_text(report, full), json_output)


def print_patch_safety_auditor(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_patch_safety_auditor(project_id=project_id, save=True)
    _print(report, patch_safety_auditor_text(report, full), json_output)


def print_apply_patch_to_temp_clone(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_apply_patch_to_temp_clone(project_id=project_id, save=True)
    _print(report, apply_patch_to_temp_clone_text(report, full), json_output)


def print_maintenance_review_bundle(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_maintenance_review_bundle(project_id=project_id, save=True)
    _print(report, maintenance_review_bundle_text(report, full), json_output)


def print_human_approval_binding(project_id: str = "eidolon", bundle_hash: str | None = None, confirm: bool = False, full: bool = False, json_output: bool = False) -> None:
    report = build_human_approval_binding(project_id=project_id, bundle_hash=bundle_hash, confirm=confirm, save=True)
    _print(report, human_approval_binding_text(report, full), json_output)


def print_real_maintenance_patch_apply(project_id: str = "eidolon", bundle_hash: str | None = None, confirm_phrase: str | None = None, dry_run: bool = True, full: bool = False, json_output: bool = False) -> None:
    report = build_real_maintenance_patch_apply(project_id=project_id, bundle_hash=bundle_hash, confirm_phrase=confirm_phrase, dry_run=dry_run, save=True)
    _print(report, real_maintenance_patch_apply_text(report, full), json_output)


def print_post_apply_health_monitor(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_post_apply_health_monitor(project_id=project_id, save=True)
    _print(report, post_apply_health_monitor_text(report, full), json_output)


def print_controlled_maintenance_cycle(project_id: str = "eidolon", full: bool = False, json_output: bool = False) -> None:
    report = build_controlled_maintenance_cycle(project_id=project_id, save=True)
    _print(report, controlled_maintenance_cycle_text(report, full), json_output)


def print_assisted_self_improvement_release(project_id: str = "eidolon", package_name: str | None = None, zip_path: str | None = None, full: bool = False, json_output: bool = False) -> None:
    report = build_assisted_self_improvement_release(project_id=project_id, package_name=package_name, zip_path=zip_path, save=True)
    _print(report, assisted_self_improvement_release_text(report, full), json_output)

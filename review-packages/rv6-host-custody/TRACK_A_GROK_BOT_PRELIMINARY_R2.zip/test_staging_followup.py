from pathlib import Path
import sys,os,json,hashlib,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'candidate'))
TEST_ROOT=Path(os.environ.get('EIDOLON_OFFLINE_TEST_ROOT',r'C:\Users\marcu\hqa3'))
from host_core import Boundary,digest,Refusal
from bootstrap import stage_offline_bootstrap
from launch_permission_capture import preserve_payload
class StageTests(unittest.TestCase):
 def test_exact19_staging(self):
  root=TEST_ROOT;(root/'stage-followup').mkdir();b=Boundary(root);raw=(R/'inputs/frozen/RP4_CLAUDE.zip').read_bytes();m=json.loads((R/'inputs/adopted/SOURCE_VERIFICATION_MATRIX.json').read_bytes());pins={r['archive_member']:r for r in m['archive_member_rows']};v=stage_offline_bootstrap(b,'stage-followup/bootstrap',raw,digest(raw),pins);self.assertEqual(len(v['staged_members']),19);self.assertEqual(len(list((root/'stage-followup/bootstrap').iterdir())),19)
 def test_invalid_archive_before_creation(self):
  root=TEST_ROOT;(root/'stage-refusal').mkdir()
  with self.assertRaises(Refusal):stage_offline_bootstrap(Boundary(root),'stage-refusal/bootstrap',b'bad','0'*64,{})
  self.assertFalse((root/'stage-refusal/bootstrap').exists())
 def test_lossless_byte_capture(self):
  raw=b'prefix\r\n{"actual":"reviewer"}\r\nsuffix';start=8;end=29;payload,receipt=preserve_payload(raw,start,end,digest(raw[start:end]));self.assertEqual(payload,raw[start:end]);self.assertFalse(receipt['rewritten'])
 def test_frame_hash_mismatch(self):
  with self.assertRaises(Refusal):preserve_payload(b'real',0,4,'0'*64)
 def test_unknown_frame_offsets(self):
  with self.assertRaises(Refusal):preserve_payload(b'real',0,5,digest(b'real'))
if __name__=='__main__':
 with (R/'evidence/STAGING_FOLLOWUP.log').open('x',encoding='utf-8') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(StageTests))
 d={'passed':r.testsRun-len(r.failures)-len(r.errors)-len(r.skipped),'failed':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'candidate').glob('*.py')},'actual_RV6':False,'staged_top_level_members':19,'reviewer_payload_rewritten':False};(R/'evidence/STAGING_FOLLOWUP.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in d.items() if k!='source_sha256'}));raise SystemExit(0 if r.wasSuccessful() else 1)

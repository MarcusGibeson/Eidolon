"""Bounded cooperative OFFLINE helpers. No live RV6 authority or OS sandbox."""
from dataclasses import dataclass
from pathlib import Path,PureWindowsPath
import hashlib,json,os,stat

class Refusal(RuntimeError):
    def __init__(self,code,detail=''):
        self.code=code;self.detail=detail;super().__init__(code+': '+detail)

def digest(data):return hashlib.sha256(data).hexdigest()
def require(ok,code,detail=''):
    if not ok:raise Refusal(code,detail)
def canonical_json(value):return (json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True)+'\n').encode()
def relative(value):
    require(isinstance(value,str) and value and '\x00' not in value,'INVALID_RELATIVE_PATH')
    p=PureWindowsPath(value)
    require(':' not in value or p.is_absolute(),'PATH_ALIAS_REFUSED',value)
    require(not p.is_absolute() and not p.drive and not p.root,'ABSOLUTE_PATH_REFUSED',value)
    require('\\' not in value and ':' not in value,'PATH_ALIAS_REFUSED',value)
    parts=value.split('/')
    require(all(x not in ('','.','..') and x==x.rstrip(' .') for x in parts),'TRAVERSAL_REFUSED',value)
    require(all(x.split('.')[0].upper() not in ('CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]) for x in parts),'RESERVED_PATH_REFUSED',value)
    return parts
def reparse(st):return stat.S_ISLNK(st.st_mode) or bool(getattr(st,'st_file_attributes',0)&0x400)
def no_alias(path):
    p=Path(path).absolute()
    for q in (*reversed(p.parents),p):
        try:s=q.lstat()
        except FileNotFoundError:continue
        require(not reparse(s),'REPARSE_REFUSED',str(q))
    return p

@dataclass(frozen=True)
class Boundary:
    root:Path
    max_entries:int=128
    max_bytes:int=1048576
    max_depth:int=12
    def __post_init__(self):
        p=Path(self.root).absolute()
        # Compiled-out live operation: receipts or model text cannot enable it.
        # Explicit producer/reviewer qualification roots only; no live RV6 root.
        require(p in (Path(r'C:\Users\marcu\hqa3'),Path(r'C:\Users\marcu\hqr3')),'OFFLINE_ROOT_REQUIRED',str(p))
        require(p.is_dir(),'MISSING_SCRATCH_ROOT',str(p));no_alias(p)
        require(0<self.max_entries<=4096 and 0<self.max_bytes<=16777216 and 0<self.max_depth<=32,'INVALID_LIMITS')
        object.__setattr__(self,'root',p)
    def path(self,name):
        parts=relative(name);require(len(parts)<=self.max_depth,'DEPTH_LIMIT',name)
        p=self.root.joinpath(*parts);no_alias(p)
        require(p.absolute().is_relative_to(self.root),'CONTAINMENT_ESCAPE',name)
        return p

def read_exact(path,maximum=16777216):
    path=no_alias(path);s=path.lstat();require(stat.S_ISREG(s.st_mode),'NOT_REGULAR_FILE',str(path));require(s.st_size<=maximum,'BYTE_LIMIT',str(path))
    flags=os.O_RDONLY|getattr(os,'O_BINARY',0)|getattr(os,'O_NOFOLLOW',0)
    fd=os.open(path,flags)
    try:
        before=os.fstat(fd);require((s.st_dev,s.st_ino)==(before.st_dev,before.st_ino),'SOURCE_RACE')
        chunks=[];total=0
        while True:
            chunk=os.read(fd,min(65536,maximum-total+1))
            if not chunk:break
            chunks.append(chunk);total+=len(chunk);require(total<=maximum,'BYTE_LIMIT')
        after=os.fstat(fd)
        require((before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino),'SOURCE_CHANGED_DURING_READ')
        require(path.lstat().st_ino==after.st_ino,'SOURCE_REPLACED_DURING_READ')
        return b''.join(chunks)
    finally:os.close(fd)

def inventory(boundary,name,allowed=None):
    """Finite no-follow walk; incomplete snapshots can never become PASS receipts."""
    root=boundary.path(name);require(root.is_dir(),'NOT_DIRECTORY',name)
    expected=None if allowed is None else frozenset(allowed)
    if expected is not None:
        for n in expected:relative(n)
    rows=[];errors=[];unexpected=[];total=0;visited=0
    def visit(p,prefix,depth):
        nonlocal total,visited
        require(depth<=boundary.max_depth,'DEPTH_LIMIT',prefix)
        with os.scandir(p) as it:
            entries=[]
            for ent in it:
                visited+=1;require(visited<=boundary.max_entries,'ENTRY_LIMIT')
                entries.append(ent)
        for ent in sorted(entries,key=lambda x:x.name.casefold()):
            rel=(prefix+'/'+ent.name).lstrip('/');relative(rel);s=ent.stat(follow_symlinks=False)
            if expected is not None and rel not in expected:unexpected.append(rel)
            if reparse(s):
                rows.append({'path':rel,'type':'link_or_reparse','size':s.st_size,'sha256':None});raise Refusal('REPARSE_REFUSED',rel)
            if stat.S_ISDIR(s.st_mode):
                rows.append({'path':rel,'type':'directory','size':0,'sha256':None});visit(Path(ent.path),rel,depth+1)
            elif stat.S_ISREG(s.st_mode):
                total+=s.st_size;require(total<=boundary.max_bytes,'BYTE_LIMIT')
                raw=read_exact(Path(ent.path),boundary.max_bytes);rows.append({'path':rel,'type':'file','size':len(raw),'sha256':digest(raw)})
            else:raise Refusal('SPECIAL_FILE_REFUSED',rel)
    try:visit(root,'',0)
    except (OSError,Refusal) as e:errors.append({'code':getattr(e,'code','IO_ERROR'),'detail':str(e)})
    complete=not errors and not unexpected
    return {'root':name,'entries':rows,'entry_count':len(rows),'bytes':total,'unexpected':unexpected,'errors':errors,'complete':complete,'classification':'OBSERVED_COMPLETE' if complete else 'INCOMPLETE_REFUSED','offline_only':True}

def write_new(boundary,name,raw):
    p=boundary.path(name);require(p.parent.is_dir(),'MISSING_OUTPUT_PARENT',name)
    require(len(raw)<=boundary.max_bytes,'BYTE_LIMIT')
    with p.open('xb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
    return {'path':name,'bytes':len(raw),'sha256':digest(raw)}

class Outcome:
    """Monotonic failure: a later successful observation never erases a refusal."""
    def __init__(self):self.events=[];self.refused=False
    def record(self,code,ok):
        self.events.append({'code':code,'ok':bool(ok)});self.refused=self.refused or not ok
    @property
    def classification(self):return 'INCOMPLETE_REFUSED' if self.refused else 'OBSERVED_COMPLETE'

def verify_cleanup(boundary,names,source_before,source_after):
    require(source_before==source_after,'SOURCE_INTEGRITY_FAILURE')
    residue=[]
    for n in names:
        p=boundary.path(n)
        if p.exists() or p.is_symlink():residue.append(n)
    require(not residue,'CLEANUP_INCOMPLETE',','.join(residue))
    return {'verified_absent':list(names),'source_exact':True,'next_case_permitted_as_offline_data':True,'execution_authority':False}

# Existing pure helpers are retained above for compatibility and comparison.
# Windows integration routes filesystem operations through retained native handles.
_cooperative_inventory=inventory
def read_exact(path,maximum=16777216):
    from windows_native import pinned_read
    return pinned_read(path,maximum)
def inventory(boundary,name,allowed=None):
    from windows_native import pinned_inventory
    try:return pinned_inventory(boundary,name,allowed)
    except (OSError,Refusal) as e:return {'root':name,'entries':[],'complete':False,'classification':'INCOMPLETE_REFUSED','errors':[{'code':getattr(e,'code','IO_ERROR'),'detail':str(e)}],'unexpected':[],'offline_only':True}
def write_new(boundary,name,raw):
    from windows_native import pinned_write
    relative(name);require(len(raw)<=boundary.max_bytes,'BYTE_LIMIT');pinned_write(boundary.root,name,raw)
    return {'path':name,'bytes':len(raw),'sha256':digest(raw)}

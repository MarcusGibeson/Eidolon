"""Windows-only retained objects and job containment. No ACL/privilege changes.

The filesystem layer binds opens to retained parent handles, rejects reparse
objects and holds ancestors without delete sharing. It is not a security-token
sandbox or an atomic directory snapshot. Host qualification remains separate.
"""
import ctypes as C,os,struct,time,subprocess
from ctypes import wintypes as W
from pathlib import Path
from host_core import require,Refusal,relative,digest
require(os.name=='nt','WINDOWS_REQUIRED')
K=C.WinDLL(r'C:\Windows\System32\kernel32.dll',use_last_error=True)
N=C.WinDLL(r'C:\Windows\System32\ntdll.dll',use_last_error=True)
HANDLE=W.HANDLE;DWORD=W.DWORD;ULONG_PTR=C.c_size_t
class US(C.Structure):_fields_=[('Length',W.USHORT),('MaximumLength',W.USHORT),('Buffer',W.LPWSTR)]
class OA(C.Structure):_fields_=[('Length',W.ULONG),('RootDirectory',HANDLE),('ObjectName',C.POINTER(US)),('Attributes',W.ULONG),('SecurityDescriptor',W.LPVOID),('SecurityQualityOfService',W.LPVOID)]
class IOS(C.Structure):_fields_=[('Status',C.c_void_p),('Information',ULONG_PTR)]
class FI(C.Structure):_fields_=[('attrs',DWORD),('created',W.FILETIME),('access',W.FILETIME),('write',W.FILETIME),('volume',DWORD),('sizehi',DWORD),('sizelo',DWORD),('links',DWORD),('indexhi',DWORD),('indexlo',DWORD)]
K.CreateFileW.argtypes=[W.LPCWSTR,DWORD,DWORD,W.LPVOID,DWORD,DWORD,HANDLE];K.CreateFileW.restype=HANDLE
K.CloseHandle.argtypes=[HANDLE];K.CloseHandle.restype=W.BOOL
K.GetFileInformationByHandle.argtypes=[HANDLE,C.POINTER(FI)];K.GetFileInformationByHandle.restype=W.BOOL
K.ReadFile.argtypes=[HANDLE,W.LPVOID,DWORD,C.POINTER(DWORD),W.LPVOID];K.ReadFile.restype=W.BOOL
K.WriteFile.argtypes=[HANDLE,W.LPCVOID,DWORD,C.POINTER(DWORD),W.LPVOID];K.WriteFile.restype=W.BOOL
K.FlushFileBuffers.argtypes=[HANDLE];K.FlushFileBuffers.restype=W.BOOL
N.NtCreateFile.argtypes=[C.POINTER(HANDLE),DWORD,C.POINTER(OA),C.POINTER(IOS),W.LPVOID,DWORD,DWORD,DWORD,DWORD,W.LPVOID,DWORD];N.NtCreateFile.restype=C.c_long
N.NtQueryDirectoryFile.argtypes=[HANDLE,HANDLE,W.LPVOID,W.LPVOID,C.POINTER(IOS),W.LPVOID,DWORD,DWORD,W.BOOLEAN,C.POINTER(US),W.BOOLEAN];N.NtQueryDirectoryFile.restype=C.c_long
def win(ok):
 if not ok:raise C.WinError(C.get_last_error())
def info(h):
 v=FI();win(K.GetFileInformationByHandle(h,C.byref(v)));require(not v.attrs&0x400,'REPARSE_REFUSED');return v
def ident(h):
 v=info(h);return (v.volume,v.indexhi,v.indexlo)
class Handle:
 def __init__(self,h):self.h=h;self.identity=ident(h)
 def close(self):
  if self.h is not None:K.CloseHandle(self.h);self.h=None
 def read(self,limit):
  v=info(self.h);require(not v.attrs&0x10,'NOT_REGULAR_FILE');size=(v.sizehi<<32)|v.sizelo;require(size<=limit,'BYTE_LIMIT')
  chunks=[];total=0
  while True:
   buf=C.create_string_buffer(min(65536,limit-total+1));n=DWORD();win(K.ReadFile(self.h,buf,len(buf),C.byref(n),None))
   if not n.value:break
   total+=n.value;require(total<=limit,'BYTE_LIMIT');chunks.append(buf.raw[:n.value])
  require(total==size and ident(self.h)==self.identity,'SOURCE_CHANGED_DURING_READ');return b''.join(chunks)
 def __enter__(self):return self
 def __exit__(self,*_):self.close()
def child(parent,name,directory=False,create=False,write=False):
 require(len(relative(name))==1,'ONE_COMPONENT_REQUIRED');text=C.create_unicode_buffer(name);u=US(len(name.encode('utf-16-le')),len(name.encode('utf-16-le'))+2,C.cast(text,W.LPWSTR));a=OA(C.sizeof(OA),parent.h,C.pointer(u),0x40,None,None);io=IOS();h=HANDLE()
 access=0x100080|(1 if directory else 0x80000000)
 if write:access=0x100082 # synchronize, attributes, write data
 options=0x200000|0x20|(1 if directory else 0x40)
 status=N.NtCreateFile(C.byref(h),access,C.byref(a),C.byref(io),None,0,3 if directory else 1,2 if create else 1,options,None,0)
 require(status>=0,'NATIVE_OPEN_REFUSED',f'{name}: NTSTATUS {status&0xffffffff:08x}')
 try:return Handle(h.value)
 except BaseException:K.CloseHandle(h);raise
def names(h,limit=4096):
 result=[];restart=True
 while True:
  b=C.create_string_buffer(65536);io=IOS();s=N.NtQueryDirectoryFile(h.h,None,None,None,C.byref(io),b,len(b),1,False,None,restart);restart=False
  if s&0xffffffff==0x80000006:break
  require(s>=0,'DIRECTORY_ENUMERATION_REFUSED',hex(s&0xffffffff));pos=0
  while True:
   require(pos+64<=io.Information,'DIRECTORY_RECORD_INVALID');nxt=struct.unpack_from('<I',b,pos)[0];attrs,length=struct.unpack_from('<II',b,pos+56)
   require(pos+64+length<=io.Information and length%2==0,'DIRECTORY_RECORD_INVALID');name=b.raw[pos+64:pos+64+length].decode('utf-16-le')
   if name not in ('.','..'):relative(name);require(not attrs&0x400,'REPARSE_REFUSED',name);result.append((name,attrs));require(len(result)<=limit,'ENTRY_LIMIT')
   if not nxt:break
   pos+=nxt
 return sorted(result,key=lambda x:x[0].casefold())
class PinnedTree:
 def __init__(self,root):self.path=Path(root).absolute();self.handles=[];self.root=None
 def __enter__(self):
  require(self.path.drive and not str(self.path).startswith('\\\\'),'LOCAL_DRIVE_REQUIRED')
  h=K.CreateFileW('\\\\?\\'+self.path.anchor,0x100081,3,None,3,0x2200000,None)
  require(h not in (None,C.c_void_p(-1).value),'NATIVE_ROOT_REFUSED')
  try:
   cur=Handle(h);self.handles.append(cur)
   for part in self.path.parts[1:]:cur=child(cur,part,True);self.handles.append(cur)
   self.root=cur;return self
  except BaseException:self.__exit__();raise
 def open(self,name,directory=False,create=False,write=False):
  parts=relative(name);cur=self.root
  for part in parts[:-1]:cur=child(cur,part,True);self.handles.append(cur)
  out=child(cur,parts[-1],directory,create,write);self.handles.append(out);return out
 def validate(self):require(all(h.h is not None and ident(h.h)==h.identity for h in self.handles),'DIRECTORY_IDENTITY_CHANGED')
 def __exit__(self,*_):
  for h in reversed(self.handles):h.close()
  self.handles=[]
def pinned_read(path,limit=16777216):
 path=Path(path).absolute()
 with PinnedTree(path.parent) as t:return t.open(path.name).read(limit)
def pinned_write(root,name,raw):
 with PinnedTree(root) as t:
  h=t.open(name,create=True,write=True);written=DWORD();win(K.WriteFile(h.h,raw,len(raw),C.byref(written),None));win(K.FlushFileBuffers(h.h));require(written.value==len(raw),'INCOMPLETE_WRITE');t.validate()
def pinned_inventory(boundary,name,allowed=None,retain=None):
 rows=[];total=0
 def visit(t,h,prefix,depth):
  nonlocal total
  require(depth<=boundary.max_depth,'DEPTH_LIMIT');first=names(h,boundary.max_entries)
  for n,attrs in first:
   rel=(prefix+'/'+n).lstrip('/');q=child(h,n,bool(attrs&0x10));t.handles.append(q);require(len(rows)<boundary.max_entries,'ENTRY_LIMIT')
   if attrs&0x10:rows.append({'path':rel,'type':'directory','size':0,'sha256':None});visit(t,q,rel,depth+1)
   else:
    raw=q.read(boundary.max_bytes-total);total+=len(raw);rows.append({'path':rel,'type':'file','size':len(raw),'sha256':digest(raw)})
  require(first==names(h,boundary.max_entries),'DIRECTORY_CHANGED_DURING_READ')
 def run(t):
  h=t.root if name=='.' else t.open(name,True);visit(t,h,'',0);t.validate();unexpected=[] if allowed is None else [r['path'] for r in rows if r['path'] not in allowed]
  return {'root':name,'entries':rows,'entry_count':len(rows),'bytes':total,'unexpected':unexpected,'errors':[],'complete':not unexpected,'classification':'OBSERVED_COMPLETE' if not unexpected else 'INCOMPLETE_REFUSED','method':'retained parent-relative native handles','atomic_directory_snapshot':False,'offline_only':True}
 if retain is not None:return run(retain)
 with PinnedTree(boundary.path(name)) as t:
  # For this tree the requested folder is already the root.
  original=name;name='.'
  result=run(t);result['root']=original;return result

# Job Objects supervise synthetic Python payloads only; no agent/runtime adapter.
class BASIC(C.Structure):_fields_=[('perprocess',C.c_longlong),('perjob',C.c_longlong),('flags',DWORD),('minworking',ULONG_PTR),('maxworking',ULONG_PTR),('active',DWORD),('affinity',ULONG_PTR),('priority',DWORD),('scheduling',DWORD)]
class IOCOUNTERS(C.Structure):_fields_=[(n,C.c_ulonglong) for n in ('readops','writeops','otherops','readbytes','writebytes','otherbytes')]
class EXT(C.Structure):_fields_=[('Basic',BASIC),('IO',IOCOUNTERS),('processmem',ULONG_PTR),('jobmem',ULONG_PTR),('peakprocess',ULONG_PTR),('peakjob',ULONG_PTR)]
class SI(C.Structure):_fields_=[('cb',DWORD),('reserved',W.LPWSTR),('desktop',W.LPWSTR),('title',W.LPWSTR),('x',DWORD),('y',DWORD),('xs',DWORD),('ys',DWORD),('xc',DWORD),('yc',DWORD),('fill',DWORD),('flags',DWORD),('show',W.WORD),('reserved2len',W.WORD),('reserved2',W.LPVOID),('stdin',HANDLE),('stdout',HANDLE),('stderr',HANDLE)]
class PI(C.Structure):_fields_=[('process',HANDLE),('thread',HANDLE),('pid',DWORD),('tid',DWORD)]
class SA(C.Structure):_fields_=[('length',DWORD),('descriptor',W.LPVOID),('inherit',W.BOOL)]
class SX(C.Structure):_fields_=[('si',SI),('attributes',W.LPVOID)]
K.InitializeProcThreadAttributeList.argtypes=[W.LPVOID,DWORD,DWORD,C.POINTER(ULONG_PTR)];K.InitializeProcThreadAttributeList.restype=W.BOOL
K.UpdateProcThreadAttribute.argtypes=[W.LPVOID,DWORD,ULONG_PTR,W.LPVOID,ULONG_PTR,W.LPVOID,W.LPVOID];K.UpdateProcThreadAttribute.restype=W.BOOL
K.DeleteProcThreadAttributeList.argtypes=[W.LPVOID]
K.TerminateProcess.argtypes=[HANDLE,W.UINT];K.TerminateProcess.restype=W.BOOL
for n,args,ret in [('CreateJobObjectW',[W.LPVOID,W.LPCWSTR],HANDLE),('SetInformationJobObject',[HANDLE,C.c_int,W.LPVOID,DWORD],W.BOOL),('AssignProcessToJobObject',[HANDLE,HANDLE],W.BOOL),('QueryInformationJobObject',[HANDLE,C.c_int,W.LPVOID,DWORD,W.LPVOID],W.BOOL),('TerminateJobObject',[HANDLE,W.UINT],W.BOOL),('ResumeThread',[HANDLE],DWORD),('WaitForSingleObject',[HANDLE,DWORD],DWORD),('GetExitCodeProcess',[HANDLE,C.POINTER(DWORD)],W.BOOL),('QueryFullProcessImageNameW',[HANDLE,DWORD,W.LPWSTR,C.POINTER(DWORD)],W.BOOL),('CreateProcessW',[W.LPCWSTR,W.LPWSTR,W.LPVOID,W.LPVOID,W.BOOL,DWORD,W.LPVOID,W.LPCWSTR,C.POINTER(SI),C.POINTER(PI)],W.BOOL)]:
 f=getattr(K,n);f.argtypes=args;f.restype=ret
class Job:
 def __init__(self):
  self.h=K.CreateJobObjectW(None,None);win(self.h);e=EXT();e.Basic.flags=0x2000;win(K.SetInformationJobObject(self.h,9,C.byref(e),C.sizeof(e)));self.pi=PI();self.started=False
 def pids(self):
  b=C.create_string_buffer(8+8*128);win(K.QueryInformationJobObject(self.h,3,b,len(b),None));assigned,count=struct.unpack_from('<II',b);require(assigned<=128 and count<=128,'PROCESS_LIMIT');return [struct.unpack_from('<Q',b,8+8*i)[0] for i in range(count)]
 def launch(self,argv,cwd,env,out,err):
  import msvcrt
  handles=[]
  try:
   for f in (out,err):h=msvcrt.get_osfhandle(f.fileno());os.set_handle_inheritable(h,True);handles.append(h)
   # stdin is NUL; no input or command shell is permitted.
   with open(os.devnull,'rb') as null:
    hi=msvcrt.get_osfhandle(null.fileno());os.set_handle_inheritable(hi,True);handles.append(hi)
    sx=SX();sx.si.cb=C.sizeof(sx);sx.si.flags=0x100;sx.si.stdin=hi;sx.si.stdout=handles[0];sx.si.stderr=handles[1]
    sizeattrs=ULONG_PTR();K.InitializeProcThreadAttributeList(None,2,0,C.byref(sizeattrs));attrs=C.create_string_buffer(sizeattrs.value);win(K.InitializeProcThreadAttributeList(attrs,2,0,C.byref(sizeattrs)));sx.attributes=C.cast(attrs,W.LPVOID)
    inherited=(HANDLE*3)(*handles);jobs=(HANDLE*1)(self.h)
    envbuf=C.create_unicode_buffer('\0'.join(k+'='+v for k,v in sorted(env.items(),key=lambda x:x[0].upper()))+'\0\0');cmd=C.create_unicode_buffer(subprocess.list2cmdline(argv))
    try:
     win(K.UpdateProcThreadAttribute(attrs,0,0x20002,C.cast(inherited,W.LPVOID),C.sizeof(inherited),None,None))
     win(K.UpdateProcThreadAttribute(attrs,0,0x2000D,C.cast(jobs,W.LPVOID),C.sizeof(jobs),None,None))
     win(K.CreateProcessW(argv[0],cmd,None,None,True,0x4|0x400|0x8000000|0x80000,envbuf,str(cwd),C.cast(C.byref(sx),C.POINTER(SI)),C.byref(self.pi)));self.started=True
    finally:K.DeleteProcThreadAttributeList(attrs)
    image=C.create_unicode_buffer(32768);size=DWORD(len(image));win(K.QueryFullProcessImageNameW(self.pi.process,0,image,C.byref(size)));require(os.path.normcase(image.value)==os.path.normcase(argv[0]),'PROCESS_IMAGE_MISMATCH')
    require(K.ResumeThread(self.pi.thread)!=0xffffffff,'PROCESS_RESUME_REFUSED')
  finally:
   for h in handles:
    try:os.set_handle_inheritable(h,False)
    except OSError:pass
 def terminate(self):win(K.TerminateJobObject(self.h,1))
 def exited(self):return K.WaitForSingleObject(self.pi.process,0)==0
 def code(self):v=DWORD();win(K.GetExitCodeProcess(self.pi.process,C.byref(v)));return v.value
 def close(self):
  if self.h:K.CloseHandle(self.h);self.h=None
  if self.started:
   K.CloseHandle(self.pi.thread);K.CloseHandle(self.pi.process)

from pathlib import Path
import sys,os,json,unittest,hashlib,datetime
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'candidate'));root=Path(r'C:\Users\marcu\hqa3');attempt=int(sys.argv[1]);assert attempt in (1,2,3,4)
if attempt==1:assert not root.exists();root.mkdir()
else:assert root.is_dir()
os.environ['EIDOLON_OFFLINE_TEST_ROOT']=str(root)
import test_integration as T
T.Tests.counter=(attempt-1)*1000
pins={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'candidate').iterdir() if p.is_file()}
with (R/f'evidence/ATTEMPT_{attempt}.log').open('x',encoding='utf-8') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(T))
summary={'attempt':attempt,'UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':r.testsRun-len(r.failures)-len(r.errors)-len(r.skipped),'failed':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'skip_reasons':[{'test':str(t),'reason':why} for t,why in r.skipped],'source_sha256':pins,'root':str(root),'resources':T.LEDGER,'production_agents':0,'Eidolon_owners_or_stores':0,'mandatory_reproductions':0}
with (R/f'evidence/ATTEMPT_{attempt}.json').open('x',encoding='utf-8') as f:json.dump(summary,f,indent=2)
print(json.dumps({k:v for k,v in summary.items() if k not in ('resources','source_sha256')}));raise SystemExit(0 if r.wasSuccessful() else 1)

from pathlib import Path
import sys,time,json,os
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'candidate'))
import windows_native as N
import launch_permission_capture as C
p=Path(r'C:\Users\marcu\hqa3\diagnose-job-2');p.mkdir();j=N.Job()
try:
 with (p/'out').open('xb') as o,(p/'err').open('xb') as e:
  j.launch([C.QUALIFIED_PYTHON,'-I','-B','-c',C.OFFLINE_PAYLOADS[2]],p,{'SystemRoot':r'C:\Windows','TEMP':str(p),'TMP':str(p)},o,e)
  for i in range(6):
   images=[];N.K.OpenProcess.argtypes=[N.DWORD,N.W.BOOL,N.DWORD];N.K.OpenProcess.restype=N.HANDLE
   for pid in j.pids():
    h=N.K.OpenProcess(0x1000,False,pid);text=N.C.create_unicode_buffer(32768);size=N.DWORD(len(text))
    if h:
     try:
      if N.K.QueryFullProcessImageNameW(h,0,text,N.C.byref(size)):images.append({'pid':pid,'path':text.value,'sha256':__import__('hashlib').sha256(Path(text.value).read_bytes()).hexdigest()})
     finally:N.K.CloseHandle(h)
   print(json.dumps({'i':i,'process_handle':j.pi.process,'pid':j.pi.pid,'wait':N.K.WaitForSingleObject(j.pi.process,0),'exit_code':j.code(),'pids':j.pids(),'images':images,'out_size':o.tell(),'err_size':e.tell()}),flush=True);time.sleep(.1)
  j.terminate();print('after kill wait',N.K.WaitForSingleObject(j.pi.process,5000),'pids',j.pids(),'code',j.code(),flush=True)
finally:j.close()

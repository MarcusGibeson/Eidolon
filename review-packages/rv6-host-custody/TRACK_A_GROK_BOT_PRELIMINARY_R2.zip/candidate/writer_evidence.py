"""Independent dimensions; neither ACL text nor a local Boolean proves isolation."""
def classify_writer_evidence(e):
 dimensions={k:'UNVERIFIED' for k in ('static_acl','process_token','effective_access','runtime_denial')}
 for k in dimensions:
  row=e.get(k)
  if not isinstance(row,dict):continue
  if row.get('unavailable'):dimensions[k]='UNAVAILABLE';continue
  # Verification must be performed outside candidate-controlled data. This
  # function deliberately does not accept self-asserted QUALIFIED strings.
  if row.get('raw_sha256') and row.get('principal_sid') and row.get('rights') is not None:dimensions[k]='OBSERVATION_PRESENT_NOT_AUTHENTICATED'
 return {'dimensions':dimensions,'actual_writer_exclusion_proven':False,'classification':'UNQUALIFIED_RUNTIME_EVIDENCE','execution_authority':False}

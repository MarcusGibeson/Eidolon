"""Pure data H3 primitives; no producer Git or representation normalization."""
import base64,hashlib,re
from host_core import require,digest,Refusal

def exact(raw,expected):
    require(len(raw)==expected['bytes'] and digest(raw)==expected['sha256'],'SOURCE_IDENTITY_MISMATCH');return True
def representation(raw,supplied,kind):
    if kind=='EXACT_RAW_BLOB':require(raw==supplied,'REPRESENTATION_MISMATCH')
    elif kind=='DECLARED_LF_TO_CRLF':require(raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')==supplied,'REPRESENTATION_MISMATCH')
    else:raise Refusal('UNAPPROVED_REPRESENTATION',kind)
    return True
def object_pool(pools,max_objects=10000,max_bytes=16777216):
    require(isinstance(pools,list) and pools,'MISSING_PROOF_POOL');out={};total=0
    for pool in pools:
        require(isinstance(pool,dict) and isinstance(pool.get('objects'),dict),'MALFORMED_PROOF')
        for oid,row in pool['objects'].items():
            require(re.fullmatch('[0-9a-f]{40}',oid) is not None,'INVALID_OID')
            require(row.get('type') in ('blob','tree','commit'),'UNSUPPORTED_OBJECT_TYPE')
            try:raw=base64.b64decode(row['base64'],validate=True)
            except Exception as e:raise Refusal('INVALID_OBJECT_BASE64') from e
            exact(raw,row);actual=hashlib.sha1((row['type']+' '+str(len(raw))+'\x00').encode()+raw).hexdigest();require(actual==oid,'OBJECT_OID_MISMATCH')
            value=(row['type'],raw)
            require(oid not in out or out[oid]==value,'CONFLICTING_PROOF_OBJECT')
            if oid not in out:total+=len(raw);require(total<=max_bytes,'PROOF_BYTE_LIMIT');out[oid]=value
            require(len(out)<=max_objects,'PROOF_OBJECT_LIMIT')
    return out
def tree_entries(raw):
    result={};pos=0
    while pos<len(raw):
        sep=raw.find(b' ',pos);end=raw.find(b'\x00',sep)
        require(sep>pos and end>sep and end+21<=len(raw),'MALFORMED_TREE')
        mode=raw[pos:sep].decode('ascii');name=raw[sep+1:end].decode('utf-8','strict')
        require(mode in ('40000','040000','100644','100755'),'UNSUPPORTED_TREE_MODE')
        require(name not in ('','.','..') and '/' not in name and '\\' not in name and ':' not in name,'INVALID_TREE_NAME')
        require(name not in result,'DUPLICATE_TREE_ENTRY');result[name]=(mode,raw[end+1:end+21].hex());pos=end+21
    return result
def commit_tree(pool,commit):
    require(commit in pool and pool[commit][0]=='commit','MISSING_COMMIT')
    raw=pool[commit][1];line=raw.split(b'\n',1)[0];require(re.fullmatch(b'tree [0-9a-f]{40}',line) is not None,'MALFORMED_COMMIT');return line[5:].decode()
def membership(pool,head,path,expected_oid,max_depth=32):
    from host_core import relative
    parts=relative(path);require(len(parts)<=max_depth,'PROOF_DEPTH_LIMIT');oid=commit_tree(pool,head)
    for i,name in enumerate(parts):
        require(oid in pool and pool[oid][0]=='tree','MISSING_TREE')
        entries=tree_entries(pool[oid][1]);require(name in entries,'MISSING_TREE_MEMBER');mode,oid=entries[name]
        require((mode in ('40000','040000'))==(i<len(parts)-1),'TREE_TYPE_MISMATCH')
    require(oid==expected_oid and oid in pool and pool[oid][0]=='blob','TREE_BLOB_MISMATCH');return True
def ancestor(pool,parent,child,max_commits=4096):
    pending=[child];seen=set()
    while pending:
        oid=pending.pop()
        if oid in seen:continue
        seen.add(oid);require(len(seen)<=max_commits,'ANCESTRY_LIMIT')
        require(oid in pool and pool[oid][0]=='commit','MISSING_ANCESTRY_COMMIT')
        if oid==parent:return True
        for line in pool[oid][1].split(b'\n\n',1)[0].splitlines():
            if line.startswith(b'parent '):
                require(re.fullmatch(b'parent [0-9a-f]{40}',line) is not None,'MALFORMED_PARENT');pending.append(line[7:].decode())
    raise Refusal('ANCESTRY_NOT_ESTABLISHED')

def live_h3(*args,**kwargs):
    raise Refusal('HOST_OPERATION_BLOCKED','Full109-row/131-member actual-shell orchestration and runtime/approval qualification require separate exact tool review. Pure primitives do not establish H3 completion.')

MATRIX_SHA='24b5d5a51465c9c2109e5ca0dbbc39522d3ff95aac6ccf3f4f94eef0c7ceaaee'
ARCHIVE_SHA='8cde7d5b78c30b3f3020e3b5e40d1e20cf38ba30d793a5f849c55665e316ca33'
HEADS={'rp2':'d561f3daeecee619325c3951d7eee3de4156a567','rp3':'718b4302951675c3e4ad70189552be8c06e9b071','rp4':'4cbb4a97b9e1b6d66d1281690e1c7b55b8e137a8'}
MANIFESTS={'rp3':'cc837ae172dee4d6df6c9c54ce12f006a83dc62f3a60258698a24c25b6e7cd0a','rp4':'6c040ae42545e8397c95683ea455bdc9450045ad2b9245da6aefbd771f2aad34'}
def direct_parent(pool,parent,child):
    require(child in pool and pool[child][0]=='commit','MISSING_COMMIT')
    headers=pool[child][1].split(b'\n\n',1)[0].splitlines()
    require(b'parent '+parent.encode() in headers,'DIRECT_PARENT_MISMATCH');return True

def verify_frozen(frozen,adopted,extracted=None,checkout=None):
    """Pure read-only H3 orchestration over actual frozen representations.

    No Git subprocess, source imports, repairs, normalization or execution.
    Actual reviewer-shell/grant qualification is a separate mandatory input to
    a future live dispatcher, not implied by this producer-side calculation.
    """
    import json,io,zipfile
    from pathlib import Path
    from host_core import read_exact,relative
    def parse(b):return json.loads(b.decode('utf-8-sig'))
    frozen=Path(frozen);adopted=Path(adopted)
    matrix_raw=read_exact(adopted/'SOURCE_VERIFICATION_MATRIX.json');require(digest(matrix_raw)==MATRIX_SHA,'MATRIX_IDENTITY_MISMATCH');m=parse(matrix_raw)
    archive=read_exact(frozen/'RP4_CLAUDE.zip');require(digest(archive)==ARCHIVE_SHA,'ARCHIVE_IDENTITY_MISMATCH')
    from bootstrap import archive_plan
    pins={x['archive_member']:x for x in m['archive_member_rows']}
    archive_plan(archive,ARCHIVE_SHA,pins,max_total=16777216)
    with zipfile.ZipFile(io.BytesIO(archive)) as z:members={n:z.read(n) for n in z.namelist()}
    package=parse(members['PACKAGE_MANIFEST.json'])['members']
    require(set(package)==set(members)-{'PACKAGE_MANIFEST.json'},'PACKAGE_MEMBER_SET_MISMATCH')
    for n,v in package.items():exact(members[n],v)
    supplemental={}
    for name,v in m['supplemental_inputs'].items():
        relative(name);b=read_exact(frozen/'supplemental_inputs'/name);exact(b,v);supplemental[name]=b
    pool=object_pool([parse(supplemental['COMMITTED_SOURCE_PROOF.json']),parse(supplemental['RP2_COMMITTED_INPUT_PROOF.json']),parse(members['COMMITTED_GIT_PROOF.json'])])
    direct_parent(pool,HEADS['rp3'],HEADS['rp4']);ancestor(pool,HEADS['rp2'],HEADS['rp4'])
    source_manifests={}
    for impl in ('rp3','rp4'):
        packet=supplemental[impl+'/.ai_pipeline/'+impl+'-review/MANIFEST.json'];require(digest(packet)==MANIFESTS[impl],'PACKET_MANIFEST_MISMATCH');pm=parse(packet)
        for n,v in pm['members'].items():
            key=impl+'/.ai_pipeline/'+impl+'-review/'+n
            require(key in supplemental,'MISSING_MANIFEST_INPUT',key);exact(supplemental[key],v)
        sm=supplemental[impl+'/.ai_pipeline/'+impl+'-review/SOURCE_MANIFEST.json'];source_manifests[impl]=parse(sm)['files']
    require(digest(members['IMPLEMENTATION_PACKET_MANIFEST.json'])==MANIFESTS['rp4'],'IMPLEMENTATION_MANIFEST_MISMATCH')
    require(members['SOURCE_MANIFEST.json']==supplemental['rp4/.ai_pipeline/rp4-review/SOURCE_MANIFEST.json'],'SOURCE_MANIFEST_MISMATCH')
    count=0
    for row in m['source_rows']+m['packet_rows']+m['runner_baseline_rows']:
        impl=row['implementation'];require(row['HEAD']==HEADS[impl],'HEAD_BINDING_MISMATCH');oid=row['git_blob_oid'];membership(pool,HEADS[impl],row['source_path'],oid);raw=pool[oid][1];exact(raw,row['raw_committed'])
        loc=row.get('supplied_location')
        if loc and loc.startswith('supplemental_inputs/'):sup=supplemental[loc[len('supplemental_inputs/'):]]
        else:sup=members[loc if loc else row['archive_members'][0]]
        exact(sup,row['supplied']);representation(raw,sup,row['representation'])
        recorded=row.get('manifest_recorded')
        if recorded is not None:
            exact(sup,recorded)
            if row['role']=='EXECUTION_SOURCE':require(source_manifests[impl].get(row['source_path'])==recorded,'SOURCE_MANIFEST_ROW_MISMATCH')
        for alias in row.get('archive_members',[]):exact(members[alias],row['supplied'])
        if checkout is not None and row.get('checkout'):
            exact(read_exact(Path(checkout[impl])/row['source_path']),row['checkout'])
        count+=1
    if extracted is not None:
        for name,b in members.items():require(read_exact(Path(extracted)/name)==b,'EXTRACTED_SOURCE_MISMATCH',name)
    return {'classification':'OFFLINE_SOURCE_IDENTITIES_VERIFIED','committed_rows':count,'archive_rows':len(pins),'supplemental_inputs':len(supplemental),'direct_parent':True,'strict_equalities':len(m['strict_byte_equalities']),'matrix_sha256':MATRIX_SHA,'archive_sha256':ARCHIVE_SHA,'checkout_checked':checkout is not None,'extracted_checked':extracted is not None,'actual_reviewer_shell_qualified':False,'execution_authority':False}

if __name__=='__main__':
    import argparse,json
    p=argparse.ArgumentParser(description='Read-only exact frozen-source verification; no runner, Git or provider execution')
    p.add_argument('--frozen-root',required=True);p.add_argument('--adopted-root',required=True);a=p.parse_args()
    try:print(json.dumps(verify_frozen(a.frozen_root,a.adopted_root),sort_keys=True))
    except Exception as e:print(json.dumps({'classification':'INCOMPLETE_REFUSED','error':str(e),'execution_authority':False}));raise SystemExit(1)

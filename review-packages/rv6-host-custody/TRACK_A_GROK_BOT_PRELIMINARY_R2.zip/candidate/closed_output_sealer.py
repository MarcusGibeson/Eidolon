"""Finalized OFFLINE evidence only. Refusals and missing evidence remain visible."""
from host_core import require,inventory,read_exact,digest,write_new,canonical_json

PROPOSAL_SHA='e7f093aa8fdb9868c8d86d4406efc05146421bbc1024991151e388da64bc52fe'
def seal(boundary,folder,allowed,required,closed_writers,terminal_record,unavailable=None):
    """Retain deny-write file handles through hashing and final seal.

    No Boolean is used as proof. The handles exclude concurrent ordinary file
    writers for the sealed streams, not all principals' future access rights.
    Missing required evidence produces an explicitly incomplete inventory.
    """
    from windows_native import PinnedTree,pinned_inventory
    require(terminal_record and terminal_record.get('terminal_observed') is True,'MISSING_TERMINAL')
    require(type(terminal_record.get('actual_exit_code')) is int,'MISSING_EXIT_STATUS')
    unavailable=unavailable or {};require(set(unavailable)<=set(required),'UNKNOWN_UNAVAILABLE_ARTIFACT')
    with PinnedTree(boundary.path(folder)) as t:
        before=pinned_inventory(boundary,'.',allowed,retain=t);require(before['complete'],'INCOMPLETE_INVENTORY')
        entries={r['path']:r for r in before['entries']};require(not {'SEAL.json','EVIDENCE_HASHES.json'}&set(entries),'ALREADY_SEALED')
        missing=sorted(set(required)-set(entries))
        inv={'entries':entries,'files':{k:v for k,v in entries.items() if v['type']=='file'},'unavailable':{n:unavailable.get(n,'MISSING_REQUIRED_ARTIFACT') for n in missing},'terminal_classification':terminal_record.get('classification'),'classification':'INCOMPLETE' if missing or terminal_record.get('classification')!='TERMINAL_OBSERVED' else 'OFFLINE_EVIDENCE_SEALED','writer_handle_exclusion_observed':True,'security_principal_write_exclusion_proven':False,'proposal_sha256':PROPOSAL_SHA,'gate_satisfied':False,'offline_only':True}
        t.validate();raw=canonical_json(inv);write_new(boundary,folder+'/EVIDENCE_HASHES.json',raw);write_new(boundary,folder+'/SEAL.json',canonical_json({'inventory_sha256':digest(raw),'proposal_sha256':PROPOSAL_SHA,'classification':inv['classification'],'offline_only':True,'live_authority':False}));t.validate();return inv
def verify_seal(boundary,folder):
    import json
    from windows_native import PinnedTree,pinned_inventory
    with PinnedTree(boundary.path(folder)) as t:
        inv_raw=t.open('EVIDENCE_HASHES.json').read(boundary.max_bytes);s=json.loads(t.open('SEAL.json').read(boundary.max_bytes));inv=json.loads(inv_raw)
        require(digest(inv_raw)==s['inventory_sha256'] and s['proposal_sha256']==PROPOSAL_SHA and inv['proposal_sha256']==PROPOSAL_SHA,'INVENTORY_TAMPER')
        observed=pinned_inventory(boundary,'.',set(inv['entries'])|{'EVIDENCE_HASHES.json','SEAL.json'},retain=t);require(observed['complete'],'SEALED_EXTRA_OR_ERROR')
        rows={r['path']:r for r in observed['entries'] if r['path'] not in ('EVIDENCE_HASHES.json','SEAL.json')};require(rows==inv['entries'],'SEALED_EVIDENCE_MISMATCH');return True

import unittest,os,json,tempfile,subprocess,hashlib,io,zipfile,base64
from pathlib import Path
from host_core import *
import windows_native as N,bootstrap as B,source_verifier as S,launch_permission_capture as C,closed_output_sealer as E,host_permissions as G
from integration import run_qualification,require_live_grant
from writer_evidence import classify_writer_evidence
ROOT=Path(os.environ['EIDOLON_OFFLINE_TEST_ROOT']);PACKAGE=Path(__file__).resolve().parent.parent
LEDGER=[]
class Tests(unittest.TestCase):
 counter=0
 def setUp(self):
  Tests.counter+=1;self.n=f'case-{Tests.counter:04d}';self.p=ROOT/self.n;self.p.mkdir();(self.p/'work').mkdir();(self.p/'ev').mkdir();self.b=Boundary(ROOT,max_entries=1024,max_bytes=16777216);LEDGER.append({'test':self.id(),'root':str(self.p),'processes':[]})
 def refuse(self,code,call):
  with self.assertRaises((Refusal,OSError)) as c:call()
  if isinstance(c.exception,Refusal):self.assertEqual(c.exception.code,code)
 def data(self,n='work/a',b=b'abc'):p=self.p/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return p
 def record(self,i=0):
  rec={'id':'synthetic-'+str(i),'argv':[C.QUALIFIED_PYTHON,'-I','-B','-c',C.OFFLINE_PAYLOADS[i]],'cwd':self.n+'/work','env':{'SystemRoot':r'C:\Windows','TEMP':str(self.p/'work'),'TMP':str(self.p/'work')}}
  return rec,{rec['id']:{'command':rec,'executable_sha256':C.QUALIFIED_PYTHON_SHA256}}
 def run_payload(self,i=0,**kw):
  rec,manifest=self.record(i);LEDGER[-1]['processes'].append(rec);return C.run_offline(self.b,rec,manifest,self.n+'/ev',**kw)
 def test_inventory(self):self.data();v=inventory(self.b,self.n+'/work');self.assertTrue(v['complete']);self.assertEqual(v['entries'][0]['sha256'],digest(b'abc'))
 def test_empty_directory(self):(self.p/'work/empty').mkdir();v=inventory(self.b,self.n+'/work');self.assertEqual(v['entries'][0]['type'],'directory')
 def test_unexpected_entry(self):self.data();self.assertFalse(inventory(self.b,self.n+'/work',set())['complete'])
 def test_inventory_resource_limit(self):self.data();b=Boundary(ROOT,max_bytes=1);self.assertFalse(inventory(b,self.n+'/work')['complete'])
 def test_missing_inventory(self):self.assertFalse(inventory(self.b,self.n+'/none')['complete'])
 def test_traversal(self):self.refuse('TRAVERSAL_REFUSED',lambda:self.b.path('../outside'))
 def test_absolute(self):self.refuse('ABSOLUTE_PATH_REFUSED',lambda:self.b.path(r'C:\Windows'))
 def test_ads(self):self.refuse('PATH_ALIAS_REFUSED',lambda:self.b.path('a:b'))
 def test_wrong_root(self):self.refuse('OFFLINE_ROOT_REQUIRED',lambda:Boundary(self.p))
 def test_live_root(self):self.refuse('OFFLINE_ROOT_REQUIRED',lambda:Boundary(Path(r'C:\Users\marcu\rv6')))
 def test_historical_root(self):self.refuse('OFFLINE_ROOT_REQUIRED',lambda:Boundary(Path(r'C:\Users\marcu\rv6hq1')))
 def test_ancestor_retained(self):
  with N.PinnedTree(self.p/'work') as t:
   with self.assertRaises(OSError):(self.p/'work').rename(self.p/'moved')
   t.validate()
  (self.p/'work').rename(self.p/'moved');self.assertTrue((self.p/'moved').is_dir())
 def test_parent_retained(self):
  with N.PinnedTree(self.p/'work'):
   with self.assertRaises(OSError):self.p.rename(ROOT/(self.n+'-redirect'))
 def test_symlink_refusal(self):
  self.data()
  try:os.symlink(self.p/'work/a',self.p/'work/link')
  except OSError as e:
   if e.winerror==1314:self.skipTest('WinError1314 symlink capability unavailable')
   raise
  self.assertFalse(inventory(self.b,self.n+'/work')['complete'])
 def test_junction_refusal(self):
  cmd=Path(r'C:\Windows\System32\cmd.exe');args=[str(cmd),'/d','/c','mklink','/J',str(self.p/'alias'),str(self.p/'work')];r=subprocess.run(args,capture_output=True);LEDGER[-1]['processes'].append({'argv':args,'exe_sha256':digest(cmd.read_bytes()),'exit':r.returncode,'stdout_hex':r.stdout.hex(),'stderr_hex':r.stderr.hex()});self.assertEqual(r.returncode,0);self.refuse('REPARSE_REFUSED',lambda:N.PinnedTree(self.p/'alias').__enter__())
 def test_directory_case_space(self):
  (self.p/'with space').mkdir();self.data('with space/a',b'x');self.assertTrue(inventory(self.b,self.n+'/with space')['complete'])
 def test_active_writer_refused(self):
  p=self.data()
  with p.open('ab'):
   self.refuse('NATIVE_OPEN_REFUSED',lambda:read_exact(p))
 def test_reader_excludes_future_writer(self):
  p=self.data()
  with N.PinnedTree(p.parent) as t:
   h=t.open(p.name)
   with self.assertRaises(OSError):p.open('ab')
   self.assertEqual(h.read(10),b'abc')
 def test_write_exclusive(self):write_new(self.b,self.n+'/ev/a',b'x');self.refuse('NATIVE_OPEN_REFUSED',lambda:write_new(self.b,self.n+'/ev/a',b'y'))
 def test_read_bound(self):p=self.data(b=b'123');self.refuse('BYTE_LIMIT',lambda:read_exact(p,2))
 def test_exact_mismatch(self):self.refuse('SOURCE_IDENTITY_MISMATCH',lambda:S.exact(b'x',{'bytes':1,'sha256':'0'*64}))
 def test_representation_no_normalization(self):self.refuse('REPRESENTATION_MISMATCH',lambda:S.representation(b'a\n',b'a\r\n','EXACT_RAW_BLOB'))
 def test_declared_representation(self):self.assertTrue(S.representation(b'a\n',b'a\r\n','DECLARED_LF_TO_CRLF'))
 def test_unknown_representation(self):self.refuse('UNAPPROVED_REPRESENTATION',lambda:S.representation(b'a',b'a','NORMALIZED'))
 def test_missing_manifest_input(self):self.refuse('NATIVE_OPEN_REFUSED',lambda:S.verify_frozen(self.p,PACKAGE/'inputs/adopted'))
 def test_missing_matrix(self):self.refuse('NATIVE_OPEN_REFUSED',lambda:S.verify_frozen(self.p,self.p))
 def test_malformed_oid(self):self.refuse('INVALID_OID',lambda:S.object_pool([{'objects':{'bad':{}}}]))
 def test_malformed_proof(self):self.refuse('MALFORMED_PROOF',lambda:S.object_pool([{}]))
 def test_direct_parent_negative(self):pool={'a':('commit',b'tree '+b'0'*40+b'\nparent '+b'b'*40+b'\n\nx')};self.refuse('DIRECT_PARENT_MISMATCH',lambda:S.direct_parent(pool,'c'*40,'a'))
 def test_missing_commit(self):self.refuse('MISSING_COMMIT',lambda:S.direct_parent({},'a','b'))
 def test_actual_frozen_source_matrix(self):
  v=S.verify_frozen(PACKAGE/'inputs/frozen',PACKAGE/'inputs/adopted');self.assertEqual(v['committed_rows'],109);self.assertEqual(v['archive_rows'],131);self.assertEqual(v['supplemental_inputs'],23);self.assertFalse(v['execution_authority'])
 def test_archive_mismatch(self):self.refuse('ARCHIVE_IDENTITY_MISMATCH',lambda:B.archive_plan(b'bad','0'*64,{}))
 def test_archive_traversal(self):
  out=io.BytesIO()
  with zipfile.ZipFile(out,'w') as z:z.writestr('../bad',b'x')
  self.refuse('TRAVERSAL_REFUSED',lambda:B.archive_plan(out.getvalue(),digest(out.getvalue()),{}))
 def test_bootstrap_selection(self):
  raw=(PACKAGE/'inputs/frozen/RP4_CLAUDE.zip').read_bytes();m=json.loads((PACKAGE/'inputs/adopted/SOURCE_VERIFICATION_MATRIX.json').read_bytes());p=B.bootstrap_selection(raw,S.ARCHIVE_SHA,{r['archive_member']:r for r in m['archive_member_rows']});self.assertEqual(len(p),19)
 def test_runtime_env(self):
  env={'PATH':r'C:\Program Files\Git\cmd;C:\Windows\System32','PYTHONDONTWRITEBYTECODE':'1'};self.assertTrue(B.qualify_environment(env,{},env)['runtime_files_match'])
 def test_runtime_redirect(self):
  for key in ('GIT_DIR','GIT_REDIRECT_STDOUT','GIT_TEMPLATE_DIR','HOME','XDG_CONFIG_HOME','TMPDIR'):
   with self.subTest(key=key):self.refuse('ENVIRONMENT_REFUSED',lambda:B.qualify_environment({key:'x'},{},{key:'x'}))
 def test_runtime_drift(self):self.refuse('ENVIRONMENT_REFUSED',lambda:B.qualify_environment({'PATH':'bad'},{},{}))
 def test_runtime_git_selection(self):env={'PATH':'bad','PYTHONDONTWRITEBYTECODE':'1'};self.refuse('UNQUALIFIED_GIT_PATH',lambda:B.qualify_environment(env,{},env))
 def test_actual_large_runtime_pin(self):
  pins=json.loads((PACKAGE/'inputs/adopted/RUNTIME_IDENTITIES.json').read_bytes())['identities'];env={'PATH':r'C:\Program Files\Git\cmd;C:\Windows\System32','PYTHONDONTWRITEBYTECODE':'1'};self.assertTrue(B.qualify_environment(env,pins,env)['runtime_files_match'])
 def test_host_missing_grant(self):self.refuse('MALFORMED_HOST_GRANT',lambda:G.inspect_grant(b'bad',{}))
 def test_host_denial(self):self.assertEqual(G.inspect_grant(b'{"decision":"DENIED"}',{})['classification'],'HOST_DENIED_NOT_EXECUTED')
 def test_host_forged_grant(self):binding={};raw=canonical_json({'decision':'APPROVED','binding':binding,'binding_sha256':digest(canonical_json(binding)),'adapter_identity':'model-text'});self.refuse('HOST_ADAPTER_UNQUALIFIED',lambda:G.inspect_grant(raw,binding))
 def test_host_binding_mismatch(self):self.refuse('GRANT_BINDING_MISMATCH',lambda:G.inspect_grant(b'{"decision":"APPROVED","binding":{}}',{'x':1}))
 def test_unknown_operation(self):self.refuse('UNKNOWN_OPERATION',lambda:G.command_binding('RELEASE',[],None,'0'*64,[]))
 def test_init_permission_mode(self):self.refuse('REVIEWER_INIT_REFUSED',lambda:G.inspect_init({'permissionMode':'bypassPermissions'}))
 def test_init_mcp(self):self.refuse('REVIEWER_INIT_REFUSED',lambda:G.inspect_init({'permissionMode':'default','mcp_servers':[{}]}))
 def test_init_unknown_tool(self):self.refuse('UNAPPROVED_REVIEWER_TOOLS',lambda:G.inspect_init({'permissionMode':'default','mcp_servers':[],'tools':['Bash']}))
 def test_python_success(self):v=self.run_payload();self.assertEqual(v['actual_exit_code'],0);self.assertEqual(v['classification'],'TERMINAL_OBSERVED');self.assertFalse(v['host_terminated'])
 def test_python_failure_preserved(self):self.assertEqual(self.run_payload(1)['actual_exit_code'],7)
 def test_timeout(self):v=self.run_payload(2,timeout=.05);self.assertEqual(v['classification'],'INCOMPLETE');self.assertTrue(v['host_terminated']);self.assertEqual(v['job_active_after'],0)
 def test_child_cleanup(self):v=self.run_payload(4,timeout=.5);self.assertTrue(v['host_terminated']);self.assertEqual(v['job_active_after'],0);self.assertGreaterEqual(sum(x==C.QUALIFIED_PYTHON for x in v['observed_images'].values()),2)
 def test_output_limit(self):self.assertEqual(self.run_payload(3,output_limit=1024)['classification'],'INCOMPLETE')
 def test_interruption(self):v=self.run_payload(2,interrupt_after_launch=True);self.assertEqual(v['reason'],'INTERRUPTED');self.assertEqual(v['job_active_after'],0)
 def test_duplicate(self):self.run_payload();self.refuse('NATIVE_OPEN_REFUSED',lambda:self.run_payload())
 def test_stale_stream_refuses_before_launch(self):self.data('ev/stdout.bin');self.refuse('NATIVE_OPEN_REFUSED',lambda:self.run_payload());self.assertFalse((self.p/'ev/TERMINAL.json').exists())
 def test_unexpected_executable(self):r,m=self.record();r['argv'][0]=r'C:\Windows\System32\cmd.exe';self.refuse('OFFLINE_PAYLOAD_ONLY',lambda:C.run_offline(self.b,r,m,self.n+'/ev'))
 def test_command_mismatch(self):r,m=self.record();r=dict(r,id='different');self.refuse('UNKNOWN_COMMAND_IDENTITY',lambda:C.run_offline(self.b,r,m,self.n+'/ev'))
 def test_capture_env_escape(self):r,m=self.record();r['env']['TEMP']=r'C:\Windows';self.refuse('ENVIRONMENT_CONTAINMENT',lambda:C.run_offline(self.b,r,m,self.n+'/ev'))
 def test_missing_terminal(self):self.refuse('MISSING_TERMINAL',lambda:C.terminal_assessment(None,'x'))
 def test_incomplete_terminal(self):self.refuse('INCOMPLETE_CAPTURE',lambda:C.terminal_assessment({'terminal_observed':True,'command_sha256':'x','classification':'INCOMPLETE'},'x'))
 def test_interrupted_recovery(self):self.data('ev/INTENT.json',b'{}');self.assertEqual(C.interrupted_state(self.b,self.n+'/ev')['classification'],'INCOMPLETE_PRESERVE_NO_RETRY')
 def seal_case(self,missing=False):
  self.data('ev/nested/a',b'x');(self.p/'ev/empty').mkdir();term={'terminal_observed':True,'actual_exit_code':0,'classification':'TERMINAL_OBSERVED'};return E.seal(self.b,self.n+'/ev',{'nested','nested/a','empty'},{'nested/a','absent'} if missing else {'nested/a'},None,term)
 def test_nested_seal(self):self.seal_case();self.assertTrue(E.verify_seal(self.b,self.n+'/ev'))
 def test_seal_proposal(self):self.assertEqual(self.seal_case()['proposal_sha256'],E.PROPOSAL_SHA)
 def test_seal_missing_evidence(self):v=self.seal_case(True);self.assertEqual(v['classification'],'INCOMPLETE');self.assertEqual(v['unavailable']['absent'],'MISSING_REQUIRED_ARTIFACT');self.assertFalse(v['gate_satisfied'])
 def test_seal_tamper(self):self.seal_case();self.data('ev/nested/a',b'y');self.refuse('SEALED_EVIDENCE_MISMATCH',lambda:E.verify_seal(self.b,self.n+'/ev'))
 def test_seal_extra_directory(self):self.seal_case();(self.p/'ev/extra').mkdir();self.refuse('SEALED_EXTRA_OR_ERROR',lambda:E.verify_seal(self.b,self.n+'/ev'))
 def test_seal_missing_terminal(self):self.refuse('MISSING_TERMINAL',lambda:E.seal(self.b,self.n+'/ev',set(),set(),True,None))
 def test_seal_active_writer(self):
  p=self.data('ev/a')
  with p.open('ab'):self.refuse('NATIVE_OPEN_REFUSED',lambda:E.seal(self.b,self.n+'/ev',{'a'},{'a'},True,{'terminal_observed':True,'actual_exit_code':0}))
 def test_cleanup_refusal(self):self.refuse('CLEANUP_INCOMPLETE',lambda:verify_cleanup(self.b,[self.n+'/work'],{},{}))
 def test_source_changed_cleanup(self):self.refuse('SOURCE_INTEGRITY_FAILURE',lambda:verify_cleanup(self.b,[],{'a':1},{'a':2}))
 def test_writer_acl_not_proof(self):self.assertFalse(classify_writer_evidence({'static_acl':{'raw_sha256':'x','principal_sid':'S-1','rights':[]}})['actual_writer_exclusion_proven'])
 def test_writer_missing(self):self.assertEqual(classify_writer_evidence({})['dimensions']['runtime_denial'],'UNVERIFIED')
 def test_integrated_success(self):r,m=self.record();v=run_qualification(self.b,r,m,self.n+'/ev');self.assertEqual(v['classification'],'OBSERVED_COMPLETE');self.assertTrue(E.verify_seal(self.b,self.n+'/ev'))
 def test_integration_sticky_failure(self):r,m=self.record();v=run_qualification(self.b,r,m,self.n+'/ev',source_inputs={'frozen':self.p,'adopted':self.p});self.assertEqual(v['classification'],'INCOMPLETE_REFUSED');self.assertFalse((self.p/'ev/INTENT.json').exists())
 def frozen_copy(self):
  import shutil
  f=self.p/'frozen';f.mkdir();shutil.copyfile(PACKAGE/'inputs/frozen/RP4_CLAUDE.zip',f/'RP4_CLAUDE.zip');m=json.loads((PACKAGE/'inputs/adopted/SOURCE_VERIFICATION_MATRIX.json').read_bytes())
  for n in m['supplemental_inputs']:
   out=f/'supplemental_inputs'/n;out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(PACKAGE/'inputs/frozen/supplemental_inputs'/n,out)
  return f,m
 def test_actual_missing_committed_manifest(self):
  f,m=self.frozen_copy();(f/'supplemental_inputs/rp4/.ai_pipeline/rp4-review/MANIFEST.json').unlink();self.refuse('NATIVE_OPEN_REFUSED',lambda:S.verify_frozen(f,PACKAGE/'inputs/adopted'))
 def test_actual_committed_byte_mismatch(self):
  f,m=self.frozen_copy();(f/'supplemental_inputs/rp3/.ai_pipeline/rp3-review/DESIGN.md').write_bytes(b'changed');self.refuse('SOURCE_IDENTITY_MISMATCH',lambda:S.verify_frozen(f,PACKAGE/'inputs/adopted'))
 def test_all_extracted_source_bytes(self):
  out=self.p/'extracted';out.mkdir()
  with zipfile.ZipFile(PACKAGE/'inputs/frozen/RP4_CLAUDE.zip') as z:
   for n in z.namelist():
    relative(n);p=out/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(z.read(n))
  self.assertTrue(S.verify_frozen(PACKAGE/'inputs/frozen',PACKAGE/'inputs/adopted',extracted=out)['extracted_checked'])
  target=out/'SOURCE_MANIFEST.json';target.write_bytes(b'changed');self.refuse('EXTRACTED_SOURCE_MISMATCH',lambda:S.verify_frozen(PACKAGE/'inputs/frozen',PACKAGE/'inputs/adopted',extracted=out))

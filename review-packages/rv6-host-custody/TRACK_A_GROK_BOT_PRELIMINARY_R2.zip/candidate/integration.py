"""Bounded offline integration of the five reviewed modules; no live dispatcher."""
from host_core import Outcome,require,Refusal,inventory
from source_verifier import verify_frozen
from launch_permission_capture import run_offline
from closed_output_sealer import seal
from host_permissions import inspect_grant
def run_qualification(boundary,record,manifest,folder,source_inputs=None):
    outcome=Outcome();observations=[]
    try:
        if source_inputs is not None:
            source=verify_frozen(**source_inputs);outcome.record('SOURCE_IDENTITIES',True);observations.append(source)
        result=run_offline(boundary,record,manifest,folder)
        outcome.record('TERMINAL_COMPLETE',result['classification']=='TERMINAL_OBSERVED')
        if outcome.refused:return {'classification':'INCOMPLETE_REFUSED','events':outcome.events,'observations':observations,'terminal':result,'execution_authority':False}
        rows=inventory(boundary,folder);outcome.record('INVENTORY_COMPLETE',rows['complete']);require(not outcome.refused,'INCOMPLETE_INVENTORY')
        sealed=seal(boundary,folder,{r['path'] for r in rows['entries']},{'INTENT.json','LAUNCHED.json','stdout.bin','stderr.bin','TERMINAL.json'},None,result)
        return {'classification':outcome.classification,'events':outcome.events,'observations':observations,'terminal':result,'sealed':sealed,'execution_authority':False}
    except (OSError,Refusal) as e:
        outcome.record(getattr(e,'code','IO_ERROR'),False)
        return {'classification':outcome.classification,'events':outcome.events,'error':str(e),'execution_authority':False}
def require_live_grant(raw,expected):
    result=inspect_grant(raw,expected)
    require(result.get('execution_authorized') is True,'LIVE_EXECUTION_BLOCKED');raise Refusal('LIVE_EXECUTION_BLOCKED')

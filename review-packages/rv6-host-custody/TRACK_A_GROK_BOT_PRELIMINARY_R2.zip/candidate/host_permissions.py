"""Host permission boundary: observations are not authority. No installed adapter."""
import json,re
from host_core import require,digest,canonical_json,Refusal
SUPPORTED_VERIFIED_HOST_ADAPTERS={} # Empty until separately reviewed/qualified.
def command_binding(operation,argv,cwd,source_sha256,effects):
 require(operation in {'H0','H1','H2','H3','H4a','H4b','H5','H6','H7','H8'},'UNKNOWN_OPERATION')
 require(isinstance(argv,list) and argv and all(isinstance(v,str) and '\0' not in v for v in argv),'INVALID_ARGV')
 require(re.fullmatch('[0-9a-f]{64}',source_sha256) is not None,'INVALID_SOURCE_BINDING')
 return {'operation':operation,'argv':argv,'cwd':cwd,'source_sha256':source_sha256,'effects':effects}
def inspect_grant(raw,expected):
 """Preserve actual host protocol payload; schema matching cannot grant access."""
 try:e=json.loads(raw)
 except Exception as x:raise Refusal('MALFORMED_HOST_GRANT') from x
 receipt={'raw_sha256':digest(raw),'raw_bytes':len(raw),'execution_authorized':False}
 require(isinstance(e,dict),'MALFORMED_HOST_GRANT')
 if e.get('decision')=='DENIED':return dict(receipt,classification='HOST_DENIED_NOT_EXECUTED',host_event=e)
 require(e.get('decision')=='APPROVED' and e.get('binding')==expected,'GRANT_BINDING_MISMATCH')
 require(e.get('binding_sha256')==digest(canonical_json(expected)),'GRANT_BINDING_MISMATCH')
 adapter=e.get('adapter_identity');require(isinstance(adapter,str) and adapter in SUPPORTED_VERIFIED_HOST_ADAPTERS,'HOST_ADAPTER_UNQUALIFIED')
 raise Refusal('HOST_ADAPTER_UNQUALIFIED','No supported authenticated interactive channel has been qualified; a matching JSON object is insufficient')
def inspect_init(e):
 require(e.get('permissionMode')=='default' and e.get('mcp_servers')==[],'REVIEWER_INIT_REFUSED')
 require(set(e.get('tools',[]))<= {'Read','Grep','Glob','Write','PowerShell','StructuredOutput'},'UNAPPROVED_REVIEWER_TOOLS')
 return {'effective_init_observed':True,'settings_source_exclusion_proof_required':True,'memory_exclusion_proof_required':True,'host_grants_verified':False,'execution_authorized':False}

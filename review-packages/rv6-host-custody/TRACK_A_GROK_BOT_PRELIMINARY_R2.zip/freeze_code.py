from pathlib import Path
import ast,json,hashlib,shutil
R=Path(__file__).resolve().parent;C=R/'candidate'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for attempt in (2,3):
 d=json.loads((R/f'evidence/ATTEMPT_{attempt}.json').read_text());out=R/f'evidence/ATTEMPT_{attempt}_SOURCE';out.mkdir()
 for n,v in d['source_sha256'].items():
  options=[C/n,R/'evidence/ATTEMPT_1_SOURCE'/n];p=next((x for x in options if x.is_file() and h(x)==v),None);assert p is not None,n;shutil.copyfile(p,out/n)
changes=[]
for p in C.glob('*.py'):
 src=p.read_text();lines=src.splitlines(keepends=True);tree=ast.parse(src);last={n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))};remove=[]
 for n in tree.body:
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and last[n.name] is not n:remove.extend(range(n.lineno-1,n.end_lineno))
 if remove:
  before=h(p);raw=''.join(v for i,v in enumerate(lines) if i not in remove).replace('_cooperative_inventory=inventory\n','');p.write_text(raw,encoding='utf-8',newline='\n');changes.append({'file':p.name,'before':before,'after':h(p),'reason':'Remove superseded definitions; original frozen code retained in inputs and per-attempt snapshots. Native integration remains the only exported implementation.'})
(R/'evidence/DEFINITION_CLEANUP.json').write_text(json.dumps(changes,indent=2)+'\n',encoding='utf-8',newline='\n')
print('Archived actual source bytes for attempts2/3; removed only superseded function definitions',len(changes))

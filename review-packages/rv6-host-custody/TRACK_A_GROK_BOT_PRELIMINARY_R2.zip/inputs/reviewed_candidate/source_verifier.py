"""Pure data H3 primitives; no producer Git or representation normalization."""
import base64,hashlib,re
from host_core import require,digest,Refusal

def exact(raw,expected):
    require(len(raw)==expected['bytes'] and digest(raw)==expected['sha256'],'SOURCE_IDENTITY_MISMATCH');return True
def representation(raw,supplied,kind):
    if kind=='EXACT_RAW_BLOB':require(raw==supplied,'REPRESENTATION_MISMATCH')
    elif kind=='DECLARED_LF_TO_CRLF':require(raw.replace(b'\r\n',b'\n').replace(b'\n',b'\r\n')==supplied,'REPRESENTATION_MISMATCH')
    else:raise Refusal('UNAPPROVED_REPRESENTATION',kind)
    return True
def object_pool(pools,max_objects=10000,max_bytes=16777216):
    require(isinstance(pools,list) and pools,'MISSING_PROOF_POOL');out={};total=0
    for pool in pools:
        require(isinstance(pool,dict) and isinstance(pool.get('objects'),dict),'MALFORMED_PROOF')
        for oid,row in pool['objects'].items():
            require(re.fullmatch('[0-9a-f]{40}',oid) is not None,'INVALID_OID')
            require(row.get('type') in ('blob','tree','commit'),'UNSUPPORTED_OBJECT_TYPE')
            try:raw=base64.b64decode(row['base64'],validate=True)
            except Exception as e:raise Refusal('INVALID_OBJECT_BASE64') from e
            exact(raw,row);actual=hashlib.sha1((row['type']+' '+str(len(raw))+'\x00').encode()+raw).hexdigest();require(actual==oid,'OBJECT_OID_MISMATCH')
            value=(row['type'],raw)
            require(oid not in out or out[oid]==value,'CONFLICTING_PROOF_OBJECT')
            if oid not in out:total+=len(raw);require(total<=max_bytes,'PROOF_BYTE_LIMIT');out[oid]=value
            require(len(out)<=max_objects,'PROOF_OBJECT_LIMIT')
    return out
def tree_entries(raw):
    result={};pos=0
    while pos<len(raw):
        sep=raw.find(b' ',pos);end=raw.find(b'\x00',sep)
        require(sep>pos and end>sep and end+21<=len(raw),'MALFORMED_TREE')
        mode=raw[pos:sep].decode('ascii');name=raw[sep+1:end].decode('utf-8','strict')
        require(mode in ('40000','040000','100644','100755'),'UNSUPPORTED_TREE_MODE')
        require(name not in ('','.','..') and '/' not in name and '\\' not in name and ':' not in name,'INVALID_TREE_NAME')
        require(name not in result,'DUPLICATE_TREE_ENTRY');result[name]=(mode,raw[end+1:end+21].hex());pos=end+21
    return result
def commit_tree(pool,commit):
    require(commit in pool and pool[commit][0]=='commit','MISSING_COMMIT')
    raw=pool[commit][1];line=raw.split(b'\n',1)[0];require(re.fullmatch(b'tree [0-9a-f]{40}',line) is not None,'MALFORMED_COMMIT');return line[5:].decode()
def membership(pool,head,path,expected_oid,max_depth=32):
    from host_core import relative
    parts=relative(path);require(len(parts)<=max_depth,'PROOF_DEPTH_LIMIT');oid=commit_tree(pool,head)
    for i,name in enumerate(parts):
        require(oid in pool and pool[oid][0]=='tree','MISSING_TREE')
        entries=tree_entries(pool[oid][1]);require(name in entries,'MISSING_TREE_MEMBER');mode,oid=entries[name]
        require((mode in ('40000','040000'))==(i<len(parts)-1),'TREE_TYPE_MISMATCH')
    require(oid==expected_oid and oid in pool and pool[oid][0]=='blob','TREE_BLOB_MISMATCH');return True
def ancestor(pool,parent,child,max_commits=4096):
    pending=[child];seen=set()
    while pending:
        oid=pending.pop()
        if oid in seen:continue
        seen.add(oid);require(len(seen)<=max_commits,'ANCESTRY_LIMIT')
        require(oid in pool and pool[oid][0]=='commit','MISSING_ANCESTRY_COMMIT')
        if oid==parent:return True
        for line in pool[oid][1].split(b'\n\n',1)[0].splitlines():
            if line.startswith(b'parent '):
                require(re.fullmatch(b'parent [0-9a-f]{40}',line) is not None,'MALFORMED_PARENT');pending.append(line[7:].decode())
    raise Refusal('ANCESTRY_NOT_ESTABLISHED')

def live_h3(*args,**kwargs):
    raise Refusal('HOST_OPERATION_BLOCKED','Full109-row/131-member actual-shell orchestration and runtime/approval qualification require separate exact tool review. Pure primitives do not establish H3 completion.')

"""Finalized OFFLINE evidence only. Refusals and missing evidence remain visible."""
from host_core import require,inventory,read_exact,digest,write_new,canonical_json
def seal(boundary,folder,allowed,required,closed_writers,terminal_record):
    require(closed_writers is True,'ACTIVE_WRITER_REFUSED')
    require(terminal_record is not None and terminal_record.get('terminal_observed') is True,'MISSING_TERMINAL')
    before=inventory(boundary,folder,allowed);require(before['complete'],'INCOMPLETE_INVENTORY')
    entries={r['path']:r for r in before['entries'] if r['type']=='file'}
    require(set(required)<=entries.keys(),'MISSING_REQUIRED_EVIDENCE')
    require('EVIDENCE_HASHES.json' not in entries and 'SEAL.json' not in entries,'ALREADY_SEALED')
    # Re-read every file immediately before the final receipt; cooperative offline
    # evidence only. Native retained handles/write exclusion remain a live hold.
    for n,row in entries.items():require(digest(read_exact(boundary.path(folder+'/'+n)))==row['sha256'],'EVIDENCE_CHANGED')
    inv={'files':entries,'terminal_classification':terminal_record.get('classification'),'gate_satisfied':False,'offline_only':True}
    raw=canonical_json(inv);write_new(boundary,folder+'/EVIDENCE_HASHES.json',raw)
    write_new(boundary,folder+'/SEAL.json',canonical_json({'inventory_sha256':digest(raw),'offline_only':True,'live_authority':False}))
    return inv
def verify_seal(boundary,folder):
    import json
    inv_raw=read_exact(boundary.path(folder+'/EVIDENCE_HASHES.json'));inv=json.loads(inv_raw);s=json.loads(read_exact(boundary.path(folder+'/SEAL.json')))
    require(digest(inv_raw)==s['inventory_sha256'],'INVENTORY_TAMPER')
    observed=inventory(boundary,folder,set(inv['files'])|{'EVIDENCE_HASHES.json','SEAL.json'})
    require(observed['complete'],'SEALED_EXTRA_OR_ERROR')
    for n,row in inv['files'].items():require(digest(read_exact(boundary.path(folder+'/'+n)))==row['sha256'],'SEALED_EVIDENCE_MISMATCH')
    return True

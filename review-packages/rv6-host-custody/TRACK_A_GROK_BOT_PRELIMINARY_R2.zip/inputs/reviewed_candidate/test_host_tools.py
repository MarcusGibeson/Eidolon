import unittest,json,os,io,zipfile,base64,hashlib,subprocess,sys
from pathlib import Path
from host_core import *
import bootstrap as B,source_verifier as V,launch_permission_capture as C,closed_output_sealer as S
ROOT=Path(r'C:\Users\marcu\rv6hq1');LEDGER=[];SEQUENCE=0
def remove_bounded(path,depth=0):
    require(path.absolute().is_relative_to(ROOT) and path!=ROOT and depth<20,'TEST_CLEANUP_BOUNDARY')
    if not path.exists() and not path.is_symlink():return
    s=path.lstat()
    if reparse(s):
        if s.st_mode&stat.S_IFDIR:os.rmdir(path)
        else:path.unlink()
    elif path.is_dir():
        entries=list(path.iterdir());require(len(entries)<256,'TEST_CLEANUP_LIMIT')
        for p in entries:remove_bounded(p,depth+1)
        path.rmdir()
    else:path.unlink()
def obj(kind,raw):
    oid=hashlib.sha1((kind+' '+str(len(raw))+'\x00').encode()+raw).hexdigest()
    return oid,{'type':kind,'bytes':len(raw),'sha256':digest(raw),'base64':base64.b64encode(raw).decode()}
class Tests(unittest.TestCase):
    def setUp(self):
        global SEQUENCE
        self.slot='slot'+str(SEQUENCE%8);SEQUENCE+=1;self.p=ROOT/self.slot
        remove_bounded(self.p);self.p.mkdir();self.bound=Boundary(ROOT);LEDGER.append({'test':self.id(),'slot':self.slot,'owner':'PRODUCER_SYNTHETIC_NOT_EIDOLON_FIXTURE','processes':[]});self.ledger=LEDGER[-1]
    def path(self,n):return self.slot+'/'+n
    def file(self,n,data=b'x'):
        p=self.p/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return p
    def rejected(self,code,fn,*args,**kw):
        with self.assertRaises(Refusal) as c:fn(*args,**kw)
        self.assertEqual(c.exception.code,code)
    def inv(self,**kw):return inventory(self.bound,self.slot,**kw)
    def command(self,index=0):
        self.file('work/a');self.file('ev/placeholder')
        record={'id':'test','argv':[C.QUALIFIED_PYTHON,'-I','-B','-c',C.OFFLINE_PAYLOADS[index]],'cwd':self.path('work'),'env':{'SystemRoot':r'C:\Windows','TEMP':str(self.p),'TMP':str(self.p)}}
        manifest={'test':{'command':record,'executable_sha256':C.QUALIFIED_PYTHON_SHA256}}
        return record,manifest
    def runcommand(self,index=0,**kw):
        rec,m=self.command(index);self.ledger['processes'].append(rec)
        return C.run_offline(self.bound,rec,m,self.path('ev'),**kw)
    def test_valid_inventory(self):
        self.file('dir/a',b'ab');r=self.inv(allowed={'dir','dir/a'});self.assertTrue(r['complete']);self.assertEqual(r['entry_count'],2);self.assertEqual(r['entries'][1]['sha256'],digest(b'ab'))
    def test_empty_inventory(self):self.assertTrue(self.inv(allowed=set())['complete'])
    def test_empty_directory_recorded(self):
        (self.p/'empty').mkdir();self.assertEqual(self.inv()['entries'][0]['type'],'directory')
    def test_unexpected_entry(self):
        self.file('x');self.assertEqual(self.inv(allowed=set())['classification'],'INCOMPLETE_REFUSED')
    def test_oversized_bytes(self):
        self.file('x',b'123');self.assertFalse(inventory(Boundary(ROOT,max_bytes=2),self.slot)['complete'])
    def test_excess_entries(self):
        self.file('a');self.file('b');self.assertFalse(inventory(Boundary(ROOT,max_entries=1),self.slot)['complete'])
    def test_depth_exhaustion(self):
        self.file('a/b/c');self.assertFalse(inventory(Boundary(ROOT,max_depth=1),self.slot)['complete'])
    def test_symlink_refusal(self):
        self.file('target');link=self.p/'link'
        try:link.symlink_to(self.p/'target')
        except OSError as e:
            if getattr(e,'winerror',None)==1314:self.skipTest('WinError1314 symlink privilege unavailable')
            raise
        self.assertFalse(self.inv()['complete'])
    def test_junction_refusal(self):
        target=self.p/'target';target.mkdir();link=self.p/'junction';cmd=[r'C:\Windows\System32\cmd.exe','/d','/c','mklink','/J',str(link),str(target)]
        p=subprocess.run(cmd,capture_output=True);self.ledger['processes'].append({'argv':cmd,'exit':p.returncode,'stdout_hex':p.stdout.hex(),'stderr_hex':p.stderr.hex()})
        if p.returncode:self.skipTest('Nonprivileged disposable junction creation unavailable: '+p.stderr.decode(errors='replace'))
        self.assertFalse(self.inv()['complete'])
    def test_ancestor_junction_refusal(self):
        from unittest.mock import patch
        fake=type('S',(),{'st_mode':stat.S_IFDIR,'st_file_attributes':0x400})()
        with patch('pathlib.Path.lstat',return_value=fake):self.rejected('REPARSE_REFUSED',no_alias,self.p)
    def test_traversal(self):self.rejected('TRAVERSAL_REFUSED',relative,'a/../b')
    def test_absolute(self):self.rejected('ABSOLUTE_PATH_REFUSED',relative,r'C:\escape')
    def test_unc(self):self.rejected('ABSOLUTE_PATH_REFUSED',relative,r'\\server\share')
    def test_ads(self):self.rejected('PATH_ALIAS_REFUSED',relative,'a:b')
    def test_backslash(self):self.rejected('PATH_ALIAS_REFUSED',relative,r'a\b')
    def test_reserved_name(self):self.rejected('RESERVED_PATH_REFUSED',relative,'a/NUL.txt')
    def test_trailing_alias(self):self.rejected('TRAVERSAL_REFUSED',relative,'a./b')
    def test_spaces(self):self.file('with space');self.assertTrue(self.inv()['complete'])
    def test_drive_case(self):self.assertEqual(Boundary(Path(str(ROOT).replace('C:','c:'))).root,ROOT)
    def test_live_root_blocked(self):self.rejected('OFFLINE_ROOT_REQUIRED',Boundary,Path(r'C:\Users\marcu\rv6'))
    def test_missing_root(self):
        from unittest.mock import patch
        with patch('pathlib.Path.is_dir',return_value=False):self.rejected('MISSING_SCRATCH_ROOT',Boundary,ROOT)
    def test_invalid_limits(self):self.rejected('INVALID_LIMITS',Boundary,ROOT,max_entries=0)
    def test_no_overwrite(self):
        write_new(self.bound,self.path('x'),b'a')
        with self.assertRaises(FileExistsError):write_new(self.bound,self.path('x'),b'b')
        self.assertEqual((self.p/'x').read_bytes(),b'a')
    def test_existing_root_refusal(self):self.rejected('ROOT_EXISTS_PRESERVE',B.require_fresh,self.p)
    def test_env_empty_redirect_refused(self):self.rejected('ENVIRONMENT_REFUSED',B.qualify_environment,{'GIT_INDEX_FILE':''},{})
    def test_env_case_refused(self):self.rejected('ENVIRONMENT_REFUSED',B.qualify_environment,{'git_object_directory':'x'},{})
    def test_env_trace_refused(self):self.rejected('ENVIRONMENT_REFUSED',B.qualify_environment,{'GIT_TRACE_PACKET':'x'},{})
    def test_env_unknown_config_refused(self):self.rejected('ENVIRONMENT_REFUSED',B.qualify_environment,{'GIT_CONFIG_KEY_9':'x'},{})
    def test_env_legitimate_runtime(self):
        p=self.file('binary');self.assertTrue(B.qualify_environment({'PATH':'qualified'},{'synthetic':{'path':str(p),'sha256':digest(b'x')}})['runtime_files_match'])
    def test_env_wrong_runtime(self):
        p=self.file('binary');self.rejected('RUNTIME_IDENTITY_MISMATCH',B.qualify_environment,{}, {'x':{'path':str(p),'sha256':'0'*64}})
    def test_path_budget(self):self.rejected('PATH_BUDGET',B.budget_path,Path('C:/x'),['a'*20],[],[],{'scratch_root':32,'file':8,'git_directory':10,'branch_lock':10})
    def test_path_budget_valid(self):self.assertEqual(B.budget_path(Path('C:/x'),['a'],[],[],{'scratch_root':32,'file':30,'git_directory':30,'branch_lock':30})['file'],[6])
    def makezip(self,name='a',data=b'x'):
        s=io.BytesIO()
        with zipfile.ZipFile(s,'w') as z:z.writestr(name,data)
        return s.getvalue()
    def test_archive_valid(self):
        raw=self.makezip();self.assertEqual(len(B.archive_plan(raw,digest(raw),{'a':{'bytes':1,'sha256':digest(b'x')}})),1)
    def test_archive_wrong_digest(self):self.rejected('ARCHIVE_IDENTITY_MISMATCH',B.archive_plan,self.makezip(),'0'*64,{})
    def test_archive_traversal(self):
        raw=self.makezip('../bad');self.rejected('TRAVERSAL_REFUSED',B.archive_plan,raw,digest(raw),{})
    def test_archive_unknown(self):
        raw=self.makezip();self.rejected('UNEXPECTED_ARCHIVE_MEMBER',B.archive_plan,raw,digest(raw),{})
    def test_archive_missing(self):
        raw=self.makezip();self.rejected('MISSING_ARCHIVE_MEMBER',B.archive_plan,raw,digest(raw),{'a':{'bytes':1,'sha256':digest(b'x')},'b':{}})
    def test_archive_resource_exhaustion(self):
        raw=self.makezip();self.rejected('ARCHIVE_MEMBER_LIMIT',B.archive_plan,raw,digest(raw),{},max_members=0)
    def test_source_wrong_digest(self):self.rejected('SOURCE_IDENTITY_MISMATCH',V.exact,b'x',{'bytes':1,'sha256':'0'*64})
    def test_source_exact(self):self.assertTrue(V.exact(b'x',{'bytes':1,'sha256':digest(b'x')}))
    def test_provenance_transform_only(self):self.assertTrue(V.representation(b'a\n',b'a\r\n','DECLARED_LF_TO_CRLF'))
    def test_no_semantic_equivalence(self):self.rejected('REPRESENTATION_MISMATCH',V.representation,b'a ',b'a','EXACT_RAW_BLOB')
    def test_unknown_representation(self):self.rejected('UNAPPROVED_REPRESENTATION',V.representation,b'a',b'a','normalize')
    def proof(self):
        b,br=obj('blob',b'x');t,tr=obj('tree',b'100644 a\x00'+bytes.fromhex(b));c,cr=obj('commit',('tree '+t+'\n\nmessage\n').encode());return {'objects':{b:br,t:tr,c:cr}},b,t,c
    def test_git_object_membership(self):
        p,b,t,c=self.proof();pool=V.object_pool([p]);self.assertTrue(V.membership(pool,c,'a',b))
    def test_git_object_oid_mismatch(self):
        p,b,t,c=self.proof();p['objects']['0'*40]=p['objects'].pop(b);self.rejected('OBJECT_OID_MISMATCH',V.object_pool,[p])
    def test_union_proof_pool(self):
        p,b,t,c=self.proof();r=p['objects'].pop(b);pool=V.object_pool([p,{'objects':{b:r}}]);self.assertTrue(V.membership(pool,c,'a',b))
    def test_missing_union_member(self):
        p,b,t,c=self.proof();p['objects'].pop(t);self.rejected('MISSING_TREE',V.membership,V.object_pool([p]),c,'a',b)
    def test_object_resource_limit(self):
        p,*_=self.proof();self.rejected('PROOF_OBJECT_LIMIT',V.object_pool,[p],max_objects=1)
    def test_ancestry(self):
        p,b,t,c=self.proof();d,dr=obj('commit',('tree '+t+'\nparent '+c+'\n\nnext\n').encode());p['objects'][d]=dr;self.assertTrue(V.ancestor(V.object_pool([p]),c,d))
    def test_no_false_ancestry(self):
        p,b,t,c=self.proof();self.rejected('ANCESTRY_NOT_ESTABLISHED',V.ancestor,V.object_pool([p]),'0'*40,c)
    def test_terminal_stdout_and_exit(self):
        r=self.runcommand();self.assertEqual(r['actual_exit_code'],0);self.assertEqual((self.p/'ev/stdout.bin').read_bytes(),b'offline stdout\r\n');self.assertFalse(C.terminal_assessment(r,r['command_sha256'])['gate_satisfied'])
    def test_nonzero_preserved(self):self.assertEqual(self.runcommand(1)['actual_exit_code'],7)
    def test_timeout_not_success(self):self.assertEqual(self.runcommand(2,timeout=.05)['classification'],'INCOMPLETE')
    def test_capture_output_limit(self):self.assertEqual(self.runcommand(3,output_limit=1024)['classification'],'INCOMPLETE')
    def test_unknown_command(self):
        r,m=self.command();r['id']='unknown';self.rejected('UNKNOWN_COMMAND_IDENTITY',C.pending_command,self.bound,r,m)
    def test_arbitrary_python_refused(self):
        r,m=self.command();r['argv'][-1]='print(123)';self.rejected('OFFLINE_PAYLOAD_ONLY',C.pending_command,self.bound,r,m)
    def test_missing_terminal(self):self.rejected('MISSING_TERMINAL',C.terminal_assessment,None,'x')
    def test_incomplete_never_terminal_pass(self):self.rejected('INCOMPLETE_CAPTURE',C.terminal_assessment,{'terminal_observed':True,'command_sha256':'x','classification':'INCOMPLETE'},'x')
    def test_duplicate_invocation(self):
        r,m=self.command();write_new(self.bound,self.path('ev/INTENT.json'),b'{}')
        with self.assertRaises(FileExistsError):C.run_offline(self.bound,r,m,self.path('ev'))
        self.assertFalse((self.p/'ev/stdout.bin').exists())
    def test_interrupted_intent_retained(self):
        r,m=self.command();write_new(self.bound,self.path('ev/INTENT.json'),b'interrupted');self.assertEqual((self.p/'ev/INTENT.json').read_bytes(),b'interrupted')
    def test_cleanup_failure(self):self.file('residue');self.rejected('CLEANUP_INCOMPLETE',verify_cleanup,self.bound,[self.path('residue')],{}, {})
    def test_cleanup_source_failure(self):self.rejected('SOURCE_INTEGRITY_FAILURE',verify_cleanup,self.bound,[],{'x':1},{'x':2})
    def test_cleanup_valid(self):self.assertTrue(verify_cleanup(self.bound,[self.path('absent')],{}, {})['source_exact'])
    def sealdata(self):self.file('e/a',b'x');return {'terminal_observed':True,'classification':'TERMINAL_OBSERVED'}
    def test_evidence_seal_valid(self):
        t=self.sealdata();S.seal(self.bound,self.path('e'),{'a'},['a'],True,t);self.assertTrue(S.verify_seal(self.bound,self.path('e')))
    def test_evidence_tamper_preserved(self):
        t=self.sealdata();S.seal(self.bound,self.path('e'),{'a'},['a'],True,t);self.file('e/a',b'bad');self.rejected('SEALED_EVIDENCE_MISMATCH',S.verify_seal,self.bound,self.path('e'))
    def test_active_writer_refusal(self):self.rejected('ACTIVE_WRITER_REFUSED',S.seal,self.bound,self.slot,set(),[],False,{})
    def test_missing_evidence_refusal(self):self.rejected('MISSING_REQUIRED_EVIDENCE',S.seal,self.bound,self.slot,set(),['missing'],True,{'terminal_observed':True})
    def test_sticky_refusal(self):
        o=Outcome();o.record('failed',False);o.record('later success',True);self.assertEqual(o.classification,'INCOMPLETE_REFUSED')
    def test_live_operations_always_refuse(self):
        self.rejected('HOST_OPERATION_BLOCKED',B.live_bootstrap);self.rejected('HOST_OPERATION_BLOCKED',V.live_h3);self.rejected('HOST_PERMISSION_TRANSPORT_UNQUALIFIED',C.live_permission_transport)
if __name__=='__main__':unittest.main(verbosity=2)

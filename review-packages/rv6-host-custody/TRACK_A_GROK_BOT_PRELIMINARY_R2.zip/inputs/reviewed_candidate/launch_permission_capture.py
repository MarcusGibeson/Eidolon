"""Bounded OFFLINE one-process capture; no Claude, shell or live grant transport."""
from pathlib import Path
import os,subprocess,threading,time
from host_core import require,Refusal,digest,read_exact,canonical_json,write_new,Outcome
OFFLINE_PAYLOADS=("import sys;print('offline stdout');print('offline stderr',file=sys.stderr)","import sys;print('preserved failure');sys.exit(7)","import time;time.sleep(2)","import sys;sys.stdout.write('x'*131072)")
QUALIFIED_PYTHON=r'C:\Users\marcu\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe'
QUALIFIED_PYTHON_SHA256='d41bad46673f64e0d02f23797f53f90ccf60f27d6eda8d86dd2d4bbeae5a858c'

def pending_command(boundary,record,manifest):
    require(set(record)=={'id','argv','cwd','env'},'UNKNOWN_COMMAND_FIELDS')
    require(record['id'] in manifest,'UNKNOWN_COMMAND_IDENTITY')
    require(record==manifest[record['id']]['command'],'COMMAND_BINDING_MISMATCH')
    exe=Path(record['argv'][0]);require(exe.is_absolute(),'UNTRUSTED_EXECUTABLE')
    require(digest(read_exact(exe))==manifest[record['id']]['executable_sha256'],'EXECUTABLE_IDENTITY_MISMATCH')
    boundary.path(record['cwd']);require(all(isinstance(x,str) and '\x00' not in x for x in record['argv']),'INVALID_ARGV')
    require(not any(k.upper().startswith(('GIT_','CLAUDE_')) or k.upper() in ('PYTHONPATH','PYTHONHOME','TMPDIR') for k in record['env']),'UNAPPROVED_ENVIRONMENT')
    require(exe==Path(QUALIFIED_PYTHON) and manifest[record['id']]['executable_sha256']==QUALIFIED_PYTHON_SHA256,'OFFLINE_PYTHON_ONLY')
    require(len(record['argv'])==5 and record['argv'][1:4]==['-I','-B','-c'] and record['argv'][4] in OFFLINE_PAYLOADS,'OFFLINE_PAYLOAD_ONLY')
    return canonical_json(record)

def run_offline(boundary,record,manifest,evidence_name,timeout=5,output_limit=65536):
    require(0<timeout<=15 and 0<output_limit<=1048576,'INVALID_CAPTURE_LIMIT')
    identity=pending_command(boundary,record,manifest);folder=boundary.path(evidence_name);require(folder.is_dir(),'MISSING_EVIDENCE_DIRECTORY')
    # Durable exclusive intent prevents silent duplicate execution, even after failure.
    write_new(boundary,evidence_name+'/INTENT.json',canonical_json({'command_sha256':digest(identity),'kind':'OFFLINE_ONLY_NOT_APPROVAL'}))
    out=folder/'stdout.bin';err=folder/'stderr.bin';p=None;stop=threading.Event();errors=[];counts=[0,0];started=time.monotonic()
    def drain(stream,target,index):
        try:
            with target.open('xb') as f:
                while True:
                    block=stream.read(4096)
                    if not block:break
                    if counts[index]+len(block)>output_limit:
                        remain=max(0,output_limit-counts[index]);f.write(block[:remain]);counts[index]+=remain;errors.append('OUTPUT_LIMIT');stop.set();break
                    f.write(block);f.flush();counts[index]+=len(block)
        except BaseException as e:errors.append('CAPTURE_IO_ERROR:'+type(e).__name__);stop.set()
        finally:stream.close()
    try:
        p=subprocess.Popen(record['argv'],cwd=boundary.path(record['cwd']),env=record['env'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        ts=[threading.Thread(target=drain,args=(p.stdout,out,0)),threading.Thread(target=drain,args=(p.stderr,err,1))]
        for t in ts:t.start()
        reason=None
        while p.poll() is None:
            if stop.wait(.01):reason='CAPTURE_FAILURE';break
            if time.monotonic()-started>timeout:reason='TIMEOUT';break
        if reason is not None and p.poll() is None:p.kill()
        p.wait(timeout=5)
        for t in ts:t.join(timeout=5)
        require(not any(t.is_alive() for t in ts),'CAPTURE_DRAIN_INCOMPLETE')
        classification='TERMINAL_OBSERVED' if not reason and not errors else 'INCOMPLETE'
        result={'classification':classification,'actual_exit_code':p.returncode,'terminal_observed':True,'reason':reason,'errors':errors,'command_sha256':digest(identity),'stdout':{'bytes':counts[0],'sha256':digest(read_exact(out,output_limit))},'stderr':{'bytes':counts[1],'sha256':digest(read_exact(err,output_limit))},'offline_only':True,'gate_satisfied':False}
        write_new(boundary,evidence_name+'/TERMINAL.json',canonical_json(result));return result
    except BaseException:
        if p is not None and p.poll() is None:p.kill();p.wait(timeout=5)
        raise

def terminal_assessment(record,expected_command):
    require(record is not None and record.get('terminal_observed') is True,'MISSING_TERMINAL')
    require(record.get('command_sha256')==expected_command,'WRONG_COMMAND')
    require(record.get('classification')=='TERMINAL_OBSERVED','INCOMPLETE_CAPTURE')
    require(type(record.get('actual_exit_code')) is int,'MISSING_EXIT_STATUS')
    return {'exit_code':record['actual_exit_code'],'review_verdict':None,'gate_satisfied':False}

def live_permission_transport(*args,**kwargs):
    raise Refusal('HOST_PERMISSION_TRANSPORT_UNQUALIFIED','No host control protocol, wildcard grant, live Claude or RP4 runner is implemented. A receipt/model string cannot enable it.')

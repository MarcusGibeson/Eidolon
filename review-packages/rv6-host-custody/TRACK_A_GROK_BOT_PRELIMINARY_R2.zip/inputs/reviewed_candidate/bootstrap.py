"""Offline H0/H1 planning; live bootstrap deliberately unavailable."""
from pathlib import Path,PurePosixPath
import io,zipfile
from host_core import require,Refusal,digest,relative,read_exact,no_alias

FORBIDDEN_ENV={'GIT_DIR','GIT_COMMON_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_CONFIG','GIT_CONFIG_GLOBAL','GIT_CONFIG_SYSTEM','GIT_CONFIG_COUNT','GIT_CONFIG_PARAMETERS','GIT_CEILING_DIRECTORIES','GIT_DISCOVERY_ACROSS_FILESYSTEM','GIT_NAMESPACE','GIT_SHALLOW_FILE','GIT_REPLACE_REF_BASE','GIT_EXEC_PATH','TMPDIR'}
def qualify_environment(env,pins):
    actual={k.upper():v for k,v in env.items()}
    bad=sorted(k for k in actual if k in FORBIDDEN_ENV or k.startswith(('GIT_CONFIG_KEY_','GIT_CONFIG_VALUE_','GIT_TRACE')))
    require(not bad,'ENVIRONMENT_REFUSED',','.join(bad))
    for name,pin in pins.items():
        raw=read_exact(Path(pin['path']));require(digest(raw)==pin['sha256'],'RUNTIME_IDENTITY_MISMATCH',name)
    return {'runtime_files_match':True,'configuration_not_host_qualified':True,'execution_authority':False}

def budget_path(root,relative_files,git_dirs,branch_locks,budgets):
    no_alias(root);require(len(str(root))<=budgets['scratch_root'],'SCRATCH_BUDGET')
    out={}
    for kind,paths in [('file',relative_files),('git_directory',git_dirs),('branch_lock',branch_locks)]:
        lengths=[]
        for n in paths:
            relative(n);p=str(Path(root).joinpath(*n.split('/')));require(len(p)<=budgets[kind],'PATH_BUDGET',kind+': '+p);lengths.append(len(p))
        out[kind]=lengths
    return out

def archive_plan(raw,expected_sha,member_pins,max_members=256,max_total=16777216):
    require(digest(raw)==expected_sha,'ARCHIVE_IDENTITY_MISMATCH');require(len(raw)<=max_total,'ARCHIVE_BYTE_LIMIT')
    total=0;seen=set();plan=[]
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        require(len(z.infolist())<=max_members,'ARCHIVE_MEMBER_LIMIT')
        for info in z.infolist():
            require(not info.is_dir(),'UNEXPECTED_DIRECTORY_MEMBER');relative(info.filename)
            require(info.filename.casefold() not in seen,'DUPLICATE_ARCHIVE_MEMBER');seen.add(info.filename.casefold())
            require((info.external_attr>>16)&0o170000 !=0o120000,'ARCHIVE_LINK_REFUSED')
            total+=info.file_size;require(total<=max_total,'ARCHIVE_BYTE_LIMIT')
            require(info.filename in member_pins,'UNEXPECTED_ARCHIVE_MEMBER',info.filename)
            row=member_pins[info.filename];require(info.file_size==row['bytes'],'MEMBER_SIZE_MISMATCH')
            data=z.read(info);require(digest(data)==row['sha256'],'MEMBER_IDENTITY_MISMATCH')
            plan.append({'name':info.filename,'bytes':len(data),'sha256':digest(data)})
    require(len(plan)==len(member_pins),'MISSING_ARCHIVE_MEMBER')
    return plan

def require_fresh(path):
    p=no_alias(path);require(not p.exists(),'ROOT_EXISTS_PRESERVE');return {'absence_observed':True,'root_created':False}

def live_bootstrap(*args,**kwargs):
    raise Refusal('HOST_OPERATION_BLOCKED','H0/H1 exact native containment, reviewed tool binding and supported host grants remain unavailable; no RV6 writes')

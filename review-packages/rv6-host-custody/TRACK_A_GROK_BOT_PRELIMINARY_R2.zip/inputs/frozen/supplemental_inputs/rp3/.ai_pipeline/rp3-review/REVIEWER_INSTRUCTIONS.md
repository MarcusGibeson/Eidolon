# Independently executable short-scratch review

No reviewer is dispatched by this packet. Use the separate verified RP3 Claude or
blind Grok Bot archive and its external TARGET/hash handoff, never a moving branch.
Do not use Pipeline V2/V3 or producer worktrees to execute this procedure.

Prerequisites: the qualified existing Windows CPython 3.12 and Git installation/
configuration, existing PowerShell, and a reviewer-designated disposable directory
with at most 32 characters in its absolute path. The profile is host-specific and
refuses uncertainty; do not edit it to bypass refusal. The producer rehearsal root
is not reviewer-owned evidence. Choose a different root such as
`C:\Users\marcu\r3review` and create it through the independently controlled review
bootstrap/operator. Do not reuse accepted worktrees, drive roots, aliases or links.
No global settings, ACL/account changes, installs or API keys are needed.

Keep the supplied immutable package/extracted instructions in reviewer-owned
storage. Its top-level runner/helper/profile must match the archive. Read TARGET
for exact HEAD, tree and manifest, and the separately supplied exact archive SHA.
First run the existing frozen runner with a dry preflight:

```powershell
& '<existing qualified Python>' -B '.\review_offline.py' --archive '.\RP3_CLAUDE.zip' --sha256 '<supplied archive SHA>' --expected-head '<TARGET head>' --expected-manifest '<TARGET manifest SHA>' --scratch-root 'C:\Users\marcu\r3review' --powershell '<existing PowerShell>' --suite all --preflight-only
```

Only after PATH_PREFLIGHT_PASS run the same command without --preflight-only.
The runner verifies every member, the new manifest, exact target and its own bytes.
It plans all required headroom before extraction, creates a fresh child under the
explicit root, scopes TEMP/TMP to its short `t` directory, and runs unit/repair/c1/
rp2/legacy/paths. Use --suite <name> for a named suite. All native operations are
disposable tooling fixtures, not production/M6 security tests. Directory symlink
privilege absence must remain SKIPPED; do not change privileges or count it as PASS.

Read the printed reviewer_owned_root, PREFLIGHT.json, RESULTS.json and suite
stdout/stderr. Exact collected/pass/failure/error/skip counts and source integrity
are recorded after each suite. Failed/refused runs must remain failures/refusals.
Preserve transcripts for dry-preflight refusals, which create no execution child.
Do not overwrite earlier runs. The original Claude RP2 result remains INCOMPLETE.

For independently authored trusted cases, obtain the separately authorized narrow
probe-file permission described in REVIEWER_PERMISSIONS.md, write only the
designated `tools/independent_probe.py`, and invoke the exact authorized command:

```powershell
& '<existing qualified Python>' -B '.\review_offline.py' --archive '.\RP3_CLAUDE.zip' --sha256 '<supplied archive SHA>' --expected-head '<TARGET head>' --expected-manifest '<TARGET manifest SHA>' --scratch-root 'C:\Users\marcu\r3review' --powershell '<existing PowerShell>' --suite probe --probe '.\tools\independent_probe.py'
```

The guard lets probes read the copied `rp2_source` within their new execution root
for original Git-path reproduction. Test only new disposable fixture repositories.
Do not run preserved producer generators/reproduction scripts with old absolute
paths. Do not evade the audit, use real repositories or broaden shell permissions.
Probe permission denied means NOT EXECUTED, not an independent verification.

Python audit checks continue to deny source writes, unrelated/credential reads,
network and unapproved processes. Native Git/PowerShell children and arbitrary
trusted bootstrap Python are not OS isolation. The method does not authenticate
reviewer signatures or certify privileged-host custody. Preserve those limitations.
Return a fresh exact-target verdict, inspected-source/diff identities, actual test
counts, skips, failed attempts, probes, findings and remaining obligations. Only
the human operator may accept after required independent reviews.

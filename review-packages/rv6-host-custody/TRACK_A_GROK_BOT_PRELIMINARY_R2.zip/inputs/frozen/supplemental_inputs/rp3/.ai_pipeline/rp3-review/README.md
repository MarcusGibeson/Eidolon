# RP3 bounded Git-path preflight repair

Producer construction checkpoint. RP2 remains implemented, not accepted. RP3 is
not accepted, adopted, activated, released or a production security certification.
The containing commit and external TARGET identify this packet without a circular
self-commit hash. MANIFEST.json and SOURCE_MANIFEST.json provide new RP3 identities.

Scope: budget actual offline Git directories, worktree metadata and branch locks
before effects; require a qualified Git environment; prepare a designated short
reviewer scratch procedure. Claim-store design, ownership, retained directory
holds, exclusive creation, live resume receipts, event integrity, repair authority,
policy routing and retired Grok Build behavior are preserved.

The compatibility profile uses conservative requirements for the measured current
Git binaries and configuration bytes. It does not assert a universal 220-character
limit, change Git/system configuration, silently move trusted storage or grant
operational authority. Unsupported environments require separate qualification.

See DESIGN.md, REVIEWER_INSTRUCTIONS.md, REVIEWER_PERMISSIONS.md and RESULTS.json.
Historical verdicts, skips, failures and unrelated findings remain preserved. No
producer result is a fresh independent reviewer verdict. The next boundary is
independent Claude review of the exact RP3 target, required blind manual Grok Bot
review, then the human operator's sole acceptance decision.

# Git-path calculation and refusal boundary

The prior diagnosis is actual retained evidence, bound in PRESERVATION.json.
The observed Git for Windows 2.40.1 implementation accepted GIT_DIR lengths 219
and 220, and rejected tested lengths 221 and 227. A separate legacy branch-lock
failure was reproduced. Those are environment observations, not universal limits.

git_paths.py qualifies the installed cmd/bin/libexec Git executable bytes, current
system/user configuration fingerprints, Windows and CPython 3.12. It refuses
different binaries/configuration, path-routing environment overrides and config
includes requiring unknown dependencies. It never modifies that configuration.
Trusted fixed bootstrap qualification reads hashes before the review audit;
subsequent checks compare file identity/size/mtime. Reviewer probes gain no
configuration or credential read permission. This assumes a cooperative host;
metadata spoofing, arbitrary bootstrap memory and privileged races are not custody.

The selected budgets are compatibility requirements with headroom: GIT_DIR 200,
branch and reflog locks 230, files 230, designated reviewer root 32 characters.
They are tied to this qualified profile. A newer Git/configuration is refused until
separately qualified; no global core.longpaths or Windows setting is changed.

Read-only planning resolves the repository .git marker and normal Gitdir/commondir
references, actual common metadata paths, current HEAD ref locks, the generated
worktree metadata identifier and bounded collision suffix, index/HEAD locks,
branch refs/reflogs, existing checked-out source and authorized destination paths.
Sparse or redirected/includes-based repository configurations refuse when the
actual complete checkout cannot be calculated. No budget check enrolls a repo.
Existing fixture identity, alias and native handle checks remain authoritative.

Public start budgets the fixed-size run ID before any Git or claim. The leased
private helper budgets its actual generated ID before Git or claim. git() checks
each actual command layout immediately before the subprocess. Review-worktree
creation is checked before its directory or Git invocation. Existing complete
source inventory is checked against the same profile instead of only MAX_PATH.
Refusal raises an actionable GIT_PATH_* error; no automatic relocation follows.
Original CLI failure-evidence behavior is retained; historical C2/C3 are not closed.

The offline runner validates the frozen archive/member/target identities and all
predicted extraction, maximum task-ID fixture, review-worktree and legacy ref-lock
paths before creating its unique child or extracting source. An explicit existing
disposable scratch root is mandatory. Every run has new logs and RESULTS.json.
Current and supplied RP2 source copies are read-only, covered by the audit's frozen
roots and hashed after every suite. Exact counts distinguish pass/failure/error/skip.

The claim-store security implementation itself is not redesigned. The old stores,
leases, native flags, exclusive claims, receipts, event history, repair authorization,
manual boundaries and six false production gates remain unchanged. Earlier LOW,
INFO and historical findings remain open; no policy adoption or authority follows.

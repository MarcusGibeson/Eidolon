# Narrow independent-probe permission prerequisite

The previous direct Claude invocation used restricted/safe mode, dontAsk and
permission-prompts none. Its Write request for the designated reviewer probe was
denied despite the supplied relative Write rule. The rule-matching cause remains
unresolved. It is not a Git path issue and short storage does not resolve it.

The preserved CLI 2.1.295 help supports manual permission mode and
`--permission-prompts host` (SDK host or configured permission handler). A supported
future setup may retain `--safe-mode --restricted --permission-mode manual
--permission-prompts host`, expose only Read/Grep/Glob/Bash/Write, preapprove only
the two exact frozen runner commands, and have the host/person approve Write for
exactly one designated absolute `tools/independent_probe.py` in that review root.
The host must reject every other Write/Edit/configuration/producer path and every
unlisted process command. Do not add producer directories with --add-dir.

The existing plain print-mode coordinator does not supply that host handshake.
It therefore needs additional operator interaction/a supported host adapter. This
packet does not invent a new automatic Write pattern or claim it works. Do not use
bypassPermissions, broad Write/Bash wildcards or test execution to evade denial.

The harmless OS scratch-file preflight in external preparation evidence checks
ordinary disposable-directory write capability only. Actual Claude CLI permission
matching and a reviewer-authored probe are NOT EXECUTED: this construction pass
explicitly forbids invoking Claude or any provider/model. A future operator must
separately authorize and validate the exact one-file permission before the review.
All existing offline suites remain executable via the fixed runner without a
Claude Write grant. If probe approval is unavailable, report the coverage gap.

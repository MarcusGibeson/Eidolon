# Blind final RP3 adversarial review — manual submission only

Bind the exact supplied RP3 TARGET commit/tree, new source/packet manifest and
implementation diff. This package excludes prior Claude reports, verdicts,
conclusions and reviewer probes. The original RP2 source and neutral path
qualification facts are supplied for independent disposable reproductions.

Independently challenge actual Git directory/worktree metadata/branch-lock
calculation, configured compatibility requirements, unqualified versions/config,
deep/nested layouts, spaces, drive case, source extraction bounds and refusal
before claims/branches/worktrees/validation. Verify legitimate short fixtures.
Run all six offline suites and independent cases using the fixed short-root
procedure and genuinely authorized probe-file permission, or record limitations.

Assess preserved claim-store security, ownership, native holds, exclusive claims,
resume receipts, event chain, operator repair scope and legacy Grok Build refusal.
Do not equate cooperative-host compatibility with OS isolation or custody.
Preserve skips and historical obligations; no formal finding closure is authorized.

Return your separately attributable fresh PASS/PASS_WITH_NON_BLOCKING_FINDINGS/
REVISE/FAIL/INCOMPLETE verdict and readiness, exact identities, actual execution,
failures/skips/probes, severity/location/reproducer/blocking/narrow-remediation
findings and scope limitations. Human disposition remains mandatory.

No automatic submission, Grok Build, repairs, actual model/provider tasks,
production/M6 campaigns, policy adoption, activation, other reviewers, push,
merge/release/deploy or autonomous development. All six gates remain false.

# Independent RP3 implementation, planning and authority assessment

Use the operator-supplied frozen TARGET, new RP3 manifest and exact archive SHA.
Parent RP2: d561f3daeecee619325c3951d7eee3de4156a567. The actual containing RP3
commit/tree is supplied externally to avoid circular self-commit identity.

Independently inspect the exact implementation diff and actual source. Reproduce
the diagnosed original RP2 Git-path failure only with the provided immutable
rp2_source and disposable repositories. Challenge corrected short-path behavior,
actual .git/commondir/worktree metadata, branch/reflog lock expansion and profile
qualification. Reject unsupported layouts before claims, branches, worktrees or
validation. Verify configuration/authority roots are not silently changed.

Run all six offline suites through REVIEWER_INSTRUCTIONS.md. Add reviewer-owned
negative cases when the narrow permission preflight is actually authorized and
works. Treat permission/capability/quota failures honestly. Preserve denied probes
as NOT EXECUTED. Passing producer rehearsals are not independent evidence.

Verify claim-store functions, retained native flags/handles, exclusive creation,
ownership, simulation scope, live resume receipts, event history and finding-bound
repair authority remain preserved. Challenge both public/private entrypoints.
Check that historical C2-C4/R2/G1 and all earlier unrelated findings remain open,
and that broad native-child/hostile-bootstrap/privileged-host limitations persist.

The Claude package separately supplies the original RP2 INCOMPLETE report and
binding diagnostic evidence. Preserve its 87 passed / 46 failed / 7 errors /
1 skipped record. Do not adopt its conclusions or producer counts as your verdict.

Return PASS/PASS_WITH_NON_BLOCKING_FINDINGS/REVISE/FAIL/INCOMPLETE and
READY_FOR_OPERATOR_ACCEPTANCE or NOT_READY_FOR_OPERATOR_ACCEPTANCE, exact HEAD,
tree, manifest, archive, diff and inspected-source hashes; actual test/probe counts,
skips/failures, severity/file/line/evidence/reproducer/blocking/narrow-remediation
findings and remaining trust/authority obligations. No formal historical closure.

Read-only independent review only. No source repairs, Pipeline V2/V3 activation,
Routing Policy V1 adoption, M6/accepted runtime changes, production tests, Grok
Build, other reviewers, push/merge/release/deploy or autonomous development. All
six production gates remain false. Required blind manual Grok Bot review and the
human operator's sole acceptance decision follow; no acceptance is inferred here.

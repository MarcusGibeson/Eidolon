# Fresh independently controlled RP4 offline review

Do not coordinate through Pipeline V2/V3. Use the separately authorized direct
reviewer CLI, the operator-supplied RP4 TARGET and archive SHA-256. No reviewer is
invoked by this packet. Branch names and temporary-child prefixes are not identities.

Choose and explicitly designate a NEW disposable reviewer-owned, non-alias Windows
directory whose full absolute path is at most 32 characters. It must differ from
the producer and every previous producer/reviewer scratch. Create/copy supplied
immutable package inputs through the approved bootstrap. Preserve all failed runs.

Prerequisites remain the existing qualified Windows CPython 3.12, Git for Windows
2.40.1.windows.1 binary/configuration fingerprints, and existing PowerShell host.
Do not edit the compatibility profile, Git configuration, system settings or ACLs.

The diagnostic's verified command-local preparation is mandatory. Native child:

```powershell
$env:PATH = 'C:\Program Files\Git\cmd;' + $env:PATH
$env:TMPDIR = $null
& '<qualified Python>' -B '.\review_offline.py' --archive '.\RP4_CLAUDE.zip' --sha256 '<operator archive SHA>' --expected-head '<RP4 TARGET head>' --expected-manifest '<RP4 manifest SHA>' --scratch-root '<fresh designated root>' --powershell '<qualified PowerShell>' --suite all --preflight-only
exit $LASTEXITCODE
```

If using the existing supported Bash tool instead, the exact separately approved
command must prepend this child-shell-only preparation:

```bash
export PATH='/c/Program Files/Git/cmd':"$PATH"; unset TMPDIR; <exact frozen runner command>
```

Git Bash otherwise selects mingw64/bin/git.exe, which is a pinned component but
not the qualified cmd entrypoint. Inherited TMPDIR can point outside the runner's
unique child, overriding its TEMP/TMP and causing the audit to refuse. Clearing
TMPDIR is process-local; never set it to a parent or global /tmp directory.

Require PATH_PREFLIGHT_PASS in the ACTUAL reviewer tool environment, not merely
the coordinator's Windows shell. Next run the exact command with --suite smoke
and without --preflight-only: four bounded guarded cases verify qualification,
refusal, complete eligibility/one-use claim and legitimate nested destination.
Only after both steps pass run --suite all without --preflight-only. The seven
suites are unit, repair, c1, rp2, legacy, paths and rp4. The symlink capability test
may skip with WinError 1314; report it as SKIPPED, never PASS. No privilege changes.

The runner verifies archive, TARGET, packet manifest, members and its own helper/
profile bytes before extraction. It creates a new unique child and read-only source,
rp2_source and rp3_source copies, logs exact test counts, and hashes all source copies
after each suite. Read printed reviewer_owned_root/PREFLIGHT.json/RESULTS.json and
suite stdout/stderr. Preserve failures and distinguish pass/failure/error/skip/not
executed. When subtests fail, report per-method results plus raw failure records;
the inherited runner's raw subtraction can undercount passes on failed subtests.

Fresh reviewer probes need the exact one-file permission in REVIEWER_PERMISSIONS.md.
Only after successful approval, use the fixed --suite probe --probe '<approved file>'
runner command. The immutable RP3 module is prequalified by the fixed bootstrap and
available as sys.modules['review_rp3_baseline'] for in-process disposable reproductions.
RP2 source is also read-only. Do not execute old producer scripts with absolute paths
to original storage. Use only newly created fixtures; no accepted repositories.

Actual future Claude process environment/tool permission matching is NOT validated
by a producer rehearsal. Any failure stops dependent execution and remains evidence.
No source repairs, other reviewers, providers, configuration changes, live pipeline,
Routing Policy adoption, M5/M6 campaigns, push/merge/release/deploy or acceptance.
All six production gates remain false. Return an exact-target independent verdict,
counts, independently authored probe results/denials, findings, limitations and hashes.

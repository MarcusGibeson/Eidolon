# Open dispositions and retained limitations

## CL-RP3-4 — relative pointers and aliases (OPEN; documented, not repaired)

Normal relative .git and commondir pointers are resolved to canonical paths before
the existing absolute-path test. A relative junction targeting Git metadata within
the same registered disposable fixture can therefore be accepted. A directly
spelled absolute junction alias is refused. Outside-owner relative pointer targets
remain refused by owner-aware planning and fixture_layout metadata ownership checks.

This is canonical containment/identity enforcement, not universal refusal of every
alias spelling. Normal Git commondir ../.. references must remain usable. The
diagnostic confirmed same-owner acceptance and outside-owner refusal; it did not
establish privileged-race safety. repository_paths/absolute/fixture ownership code
is unchanged in RP4. No new alias authority, automatic relocation or root enrollment
is introduced. Historical implementation-metadata substitution finding R2 remains.

## CL-RP3-5 — availability and repeated walks (OPEN; documented, not optimized)

Every Git wrapper call qualifies the supported environment and checks repository
paths using the existing tree walk. Drift in qualified executable/configuration
identity or an unapproved environment setting refuses even existing-run loading,
read-only status and resume. Requalification is a separate operator task; failure
is not permission to disable checks or edit fingerprints.

Read-only operations repeat source-path walks. RP4 also adds eligibility reads
needed by findings 1–3; it does not optimize/cache source inventories or relax
qualification for read-only calls. Large-tree latency, narrow host compatibility,
same-process receipt lifetime and inability to resume across bootstrap restart
remain explicit limits. The existing walk and availability mechanisms are unchanged.

## Other historical findings

C2–C4, R2, G1 and every other historical LOW/INFO or unrelated finding remain open.
No producer fix, passing suite, AST comparison or package hash is formal independent
finding closure. Frozen model/governance contracts, native-child/hostile-bootstrap/
privileged-host limitations, manual Grok Bot boundary and operator acceptance remain.

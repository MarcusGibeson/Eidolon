# RP4 repair design and authority boundary

This pass repairs three reproduced RP3 defects. It retains the host-specific
Windows/CPython/Git qualification profile and the RP2 fixture/claim-store model.
Compatibility is cooperative-host evidence, not hostile-host isolation or custody.

## 1. Effective Git environment

The frozen compatibility profile, selected cmd/git.exe entry point, cmd/bin/libexec
binary hashes, system/user config hashes, include refusal and conservative budgets
are unchanged. Normal checkout CRLF conversion changes physical profile bytes;
the committed Git object and parsed qualification values remain identical to RP3.
The fresh manifest records actual copied bytes. The environment check now refuses
presence (including uncertain
empty values) of the three omitted storage overrides: GIT_INDEX_FILE,
GIT_OBJECT_DIRECTORY and GIT_ALTERNATE_OBJECT_DIRECTORIES.

The installed Git documentation/executable audit also identified related shallow,
graft, quarantine, replacement-ref, discovery and default-object-format controls:
GIT_SHALLOW_FILE, GIT_GRAFT_FILE, GIT_QUARANTINE_PATH, GIT_REPLACE_REF_BASE,
GIT_CEILING_DIRECTORIES, GIT_DISCOVERY_ACROSS_FILESYSTEM and GIT_DEFAULT_HASH.
These refuse. GIT_CONFIG_*, GIT_TRACE* and Windows GIT_REDIRECT_* settings also
refuse because their effective configuration/output storage is not in this plan.
Existing GIT_DIR/WORK_TREE/COMMON_DIR/EXEC_PATH/NAMESPACE/XDG_CONFIG_HOME refusals
remain. Author/committer and unrelated process variables are not silently scrubbed.
Errors name the unapproved setting before native Git or claim creation.

The reviewer runner retains its existing dedicated child-environment sanitization;
the implementation Git wrapper does not gain broad environment rewriting. Remote
Git/native children and privileged-host races remain outside claimed isolation.

## 2. Pre-claim source eligibility

Public start and the leased private helper retain their early environment/admin/
on-disk path checks. Impossible known layouts still refuse before any Git call.
Once those checks pass, narrowly scoped READ-ONLY Git inspection establishes
eligibility. This is intentionally permitted; no impossible zero-read-only-Git
claim is made for facts requiring committed-tree/index inspection.

The order is:

1. Parse exact task/config; validate simulation and process-local fixture ownership.
2. Qualify environment and known actual Git/admin/working paths.
3. Recheck fixture layout, baseline HEAD and ordinary cleanliness.
4. Use existing source_blobs to enumerate committed objects, require tracked-file
   presence and exact raw bytes (allowing the existing CRLF-only conversion), and
   reject unsupported source kinds or incomplete working inventories. Git index
   skip-worktree/assume-unchanged flags cannot hide these direct object/file checks.
5. Read-only diff-index --cached --quiet additionally requires the index to match
   the approved baseline, independently of correct working bytes.
6. Budget all committed destination names, actual Git metadata and branch/lock
   paths for the generated implementation destination; verify required bindings.
7. Only then exclusively create the one-use claim and run/journal artifacts.
8. Prepare/create the disposable worktree only after eligibility. Validation and
   reviewer workflow are later, separately gated operations.

Valid consumption remains one-use even if a later eligible operation fails. Resume
still needs the live bootstrap receipt and intact event history. The source_blobs
implementation and its historical raw cat-file subprocess limitation (G1) are
unchanged; the new call occurs after qualified inspection in the trusted bootstrap.
This is not a claim of formal G1 closure or atomic hostile-host custody.

## 3. Destination-aware worktree planning

Pipeline.review_destination passes the frozen Git source inventory into the actual
review-N path plan before prepare_worktree can create directories. The same helper
preserves fixture-owner checks and all Git-directory/metadata/lock budgets.

The general git() worktree-add wrapper first qualifies administrative paths, then
uses read-only ls-tree -r -z for the exact proposed revision and passes every name
to command_plan. A worktree-add command plan without an explicit inventory refuses
as GIT_PATH_INVENTORY_REQUIRED. Thus direct disposable fixture calls cannot bypass
the complete file budget by omitting the pipeline-level review helper.

The 230-character impl / 237-character review destination reproduction now refuses
before the destination, Git worktree metadata or branch is created. Nested paths,
spaces and short legitimate fixtures remain supported. No authority root moves.

## Preserved limits

DISPOSITIONS.md documents CL-RP3-4/5 without alias or performance changes. The 20
listed RP2 security mechanisms are checked against committed predecessor sources;
actual new call ordering and source binding must still be independently reviewed.
The in-process audit is workflow protection, not an OS sandbox for hostile Python,
native children, trusted bootstrap code or a privileged same-user host. Matching
local hashes do not authenticate a reviewer or operator. No acceptance follows.

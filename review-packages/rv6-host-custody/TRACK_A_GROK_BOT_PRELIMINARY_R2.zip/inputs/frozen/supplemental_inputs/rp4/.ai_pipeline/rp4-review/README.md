# RP4 bounded repair checkpoint — not accepted

Parent RP3: 718b4302951675c3e4ad70189552be8c06e9b071. The containing RP4
commit/tree and fresh manifest/archive SHA-256 values are supplied by external
TARGET.json and the operator handoff, avoiding a circular containing-commit hash.
Do not infer identity from a branch name, working path or temporary child prefix.

Scope: repair Git environment storage redirection, complete pre-claim eligibility
inventory, and full review-destination budgeting. No claim-store redesign or
changes to runtime/models/governance, alias policy, availability or performance
optimization. CL-RP3-4/5 are documented open dispositions. All historical findings
remain open unless separately resolved through an authorized independent process.

RESULTS.json contains producer execution and preserved failed attempts, not an
independent verdict. SOURCE_MANIFEST.json inventories the implementation bytes;
PRESERVATION.json binds predecessor evidence, committed objects and security ASTs.
MANIFEST.json binds this new packet, never the old RP3 implementation identity.

REVIEWER_INSTRUCTIONS.md requires command-local qualified Git selection, TMPDIR
removal, a new short disposable root, actual-tool dry preflight and guarded smoke.
REVIEWER_PERMISSIONS.md requires fresh supported host approval for any reviewer
probe. Prior approval is not reusable. Read-only copied RP2/RP3 sources support
historical reproductions; no real/accepted repository is a fixture.

Codex supplies implementation and producer validation only. No reviewer/model
invocation, Pipeline V2/V3 activation, Routing Policy V1 adoption, Grok Build,
production/M6 tests, autonomous authority, push/merge/release/deploy or acceptance
is authorized here. All six production gates remain false. The next boundary is
operator authorization for a fresh independent Claude RP4 review, then conditional
manual blind Grok Bot final review and the human operator's sole acceptance decision.

# Fresh narrow reviewer permission boundary

No live reviewer is invoked in RP4 construction. A previous direct review obtained
one host-approved Write for its designated probe, but the runner refused before
probe or suite execution. That approval cannot authorize a new file or review.

Keep the independently controlled CLI restricted/safe, no user/project settings
sources, strict empty MCP, no producer --add-dir, no other agents and no permission
bypass. Expose only Read/Grep/Glob and the selected supported shell tool plus Write.
Preapprove/request only exact frozen preflight/smoke/all/probe commands, including
their command-local PATH/TMPDIR preparation. No broad shell or Write wildcards.

Use supported manual/host permission controls. The installed CLI's host protocol can
pause on a specific Write; the operator/host must inspect the exact absolute path
and content digest and approve at most one pending creation of
<fresh reviewer root>\tools\independent_probe.py. Deny every other write or command.
No producer source/configuration write grant, persistent permission update, native
permission grant, broader ACL or security-control bypass is authorized.

If host approval is unavailable/denied, preserve it and mark probe NOT EXECUTED.
Do not create the file on the reviewer's behalf or use shell execution to evade
Write denial. Existing fixed suites and smoke do not require reviewer Write access.
OS write capability alone does not prove Claude permission matching.

The preferred native shell route exists in installed CLI 2.1.295; selecting
CLAUDE_CODE_USE_POWERSHELL_TOOL=1 and an explicitly exposed PowerShell tool requires
a separately authorized future invocation/actual-tool permission check. Tested
native/Bash producer preparations do not constitute that live check or a fresh
reviewer-owned probe. Local capture/hashes are not authenticated reviewer identity.

# Independent RP4 implementation and security review

Bind the operator-supplied exact RP4 HEAD/tree, fresh manifest and archive SHA-256.
Parent RP3 is 718b4302951675c3e4ad70189552be8c06e9b071; RP2 is
d561f3daeecee619325c3951d7eee3de4156a567. Inspect the real implementation diff.

Independently reproduce the three original defects on immutable rp3_source using
new disposable repositories, then challenge RP4 corrections: inherited storage/
discovery/output routing, missing skip-worktree/assume-unchanged bytes and index
inconsistency before claims, and full nested review-destination/admin/lock budgeting
before creation. Distinguish permitted read-only Git eligibility reads from claims,
mutating Git, worktree/directory creation, validation and reviewer dispatch.

Run all seven suites through the fixed short-root procedure and actual-tool dry
preflight/smoke. Add independent cases only after fresh exact one-file host approval.
Preserve denied probes, capability skips, all failures and incomplete attempts.
Producer counts are not independent results. Earlier INCOMPLETE verdicts and original
RP2 87 passed/46 failed/7 errors/1 skipped remain unchanged; do not reinterpret them.

Verify the 20 claimed-identical RP2 mechanisms and actual changed call paths:
bootstrap-created separate claim store, retained native handles/flags, exclusive
creation, fixture ownership, simulation-only scope, live resume receipts, source/
authorization bindings, event chain and finding-bound operator repair authority.
Challenge public/private entrypoints and low-level worktree-add bypasses.

Assess the documented open CL-RP3-4/5 dispositions without treating them as fixed.
Preserve C2–C4/R2/G1 and all prior unrelated findings; no formal closure is authorized.
Verify historical runtime/model/contracts, Routing Policy proposal, V3 offline loop,
all predecessor checkpoints/reviews and all six false production gates remain intact.

Return exactly one PASS/PASS_WITH_NON_BLOCKING_FINDINGS/REVISE/FAIL/INCOMPLETE and
READY_FOR_OPERATOR_ACCEPTANCE or NOT_READY_FOR_OPERATOR_ACCEPTANCE, bound to exact
HEAD/tree/manifest/archive/diff and inspected source identities. Include actual seven
suite counts (pass/fail/error/skip/not executed), probe approval/creation/execution
distinctions, original failures, severity/file/line/evidence/reproducer/blocking/
narrow-remediation findings and remaining trust/authority/custody limitations.

No repairs, providers/other reviewers, Pipeline V2/V3 coordination/activation, policy
adoption, production/M5/M6 tests, Grok Build, autonomous authority, push/merge/release/
deploy or acceptance. After your fresh verdict, blind manual Grok Bot review remains
conditional and the human operator alone decides acceptance.

# RV6_SUPPLEMENTAL_REVIEW_AUTHORIZATION_PROPOSAL

Version 4. PROPOSED ONLY; not adopted, not executable authority. Prepared to correct
RV6-F1 through F6 and disposition F7 through F9 from the preserved independent REVISE
of v1 digest 2de1ba0eeafe1b5896fbd842d8a4fc272be86350e349bc18c847668f121e6cf6.
Version 3 received PASS_WITH_NON_BLOCKING_FINDINGS / READY_FOR_OPERATOR_ADOPTION_DECISION. This prospective version changes only A1/A2 chronology/wording and directly dependent schedule hashes/references. Version 4 is not independently reviewed at preparation; no prior PASS or permission transfers. Prior version 2 REVISE and all historical results remain unchanged.

## A. Exact scope, precedence and adopted-authority boundary

This is a prospective supplemental effects schedule for ONE future RV6 session only.
It does not modify original RP4 contracts or reinterpret any historical approval,
RV5 attempt, failed check, reviewer verdict, source checkpoint or mandatory gate.

Frozen RP3: 718b4302951675c3e4ad70189552be8c06e9b071; manifest SHA-256
cc837ae172dee4d6df6c9c54ce12f006a83dc62f3a60258698a24c25b6e7cd0a.
Frozen RP4: 4cbb4a97b9e1b6d66d1281690e1c7b55b8e137a8, direct child of RP3;
manifest SHA-256 6c040ae42545e8397c95683ea455bdc9450045ad2b9245da6aefbd771f2aad34.
RP4 frozen REVIEWER_PERMISSIONS.md SHA-256:
b37e86f2dff432898320f80d352c52b94f3b6b25bc1ea82502325243c7f4a314.
Exact governing copies and previous review are supplied read-only in review/frozen_v1
and historical. Their integrity is separately inventoried; summaries never replace them.

The actual conflict: frozen CLAUDE_HANDOFF.md:7-15 mandates disposable dynamic
original/corrected reproductions; REVIEWER_PERMISSIONS.md:13-17 allows one authored
probe and denies every other write/command; REVIEWER_INSTRUCTIONS.md:45-57 supplies
runner-generated copies/logs/fixtures. An additional sequencing conflict exists:
instructions:37-41 orders preflight/smoke/all/probe, while the final reproduction
request:88 says do not repeat the seven completed suites without independent need.
Only AFTER exact operator adoption, separate execution authority and host grants does
this schedule prospectively permit its declared generated effects and supplemental
preflight/smoke/probe sequence. It does not claim the old restriction already did so.
All other frozen requirements remain. An unaddressed conflict stops execution.

The human operator may adopt project procedure within their authority; the proposal
cannot override managed policy, OS or host permissions. Codex and reviewer output
cannot adopt it. Drafting, reviewing, packaging or a favourable verdict supplies no
operational grant. Changes to these bytes or bound schedules require a new digest and
fresh independent review. A later exact adoption is separate from probe/tool authoring,
process execution, acceptance and release.

## B. Bound schedules and their precedence

The following six data documents are normative parts of this proposal. Their exact
hashes close resource/operation/tool/input scope. Human text and JSON must agree;
a contradiction or missing input stops, rather than choosing a permissive reading.
Only named generated classes and bounded parameter substitutions are allowed.

| Bound document | SHA-256 |
|---|---|
| RESOURCE_BOUNDS.json | `ea0e55b22b6f0e407532643b082136a5edc85d4449595d07066cce6bf2622fd7` |
| COMMANDS.json | `6a5f3add71c1623cba2606b565934026285b935ac4cba2de4b7a0c8b3216ef8d` |
| HOST_OPERATIONS.json | `9aaa6b1a5e9359e33d8e56f371fdd6ea6c7f2d280f5f4e0b4e6d9fb386de90c4` |
| GIT_OPERATION_INVENTORY.json | `5d67a8b584e52d454a00e197c002c90d2484c392b98b6d4a412ced2afeaae8be` |
| SOURCE_VERIFICATION_MATRIX.json | `24b5d5a51465c9c2109e5ca0dbbc39522d3ff95aac6ccf3f4f94eef0c7ceaaee` |
| RUNTIME_IDENTITIES.json | `d0f869270aaac961e8cda9e0e327ec3e60512f0b95b37f0074d11f96bb5d1753` |

The supplemental source matrix binds every extra input by bytes and digest, including
actual RP3 packet/manifest bytes absent from the old RP4 archive. These are evidence
copies and committed-object data, not new repositories or a regenerated source archive.
The old RP4_CLAUDE.zip remains exact SHA-256
8cde7d5b78c30b3f3020e3b5e40d1e20cf38ba30d793a5f849c55665e316ca33.

## C. Reviewer authoring versus generated effects

Exactly one reviewer-authored executable source file may be proposed:
C:\Users\marcu\rv6\tools\independent_probe.py.
Before creation, reviewer supplies its complete pending contents; operator/host must
approve exact canonical path and content SHA-256 through supported one-time permission
controls. Verify content after the one Write and before execution. Creation approval
never implies execution approval. No additional reviewer-authored script/notebook,
program, generated code, arbitrary direct write, wildcard, persistent permission rule,
replacement probe, shell rewrite of a denied Write or coordinator-authored probe.
A changed probe stops and requires a new exact prospective decision; no overwrite.

The one-file rule limits reviewer authoring/direct tool actions. It does NOT implicitly
authorize child files. Only separately approved exact bootstrap/runner/probe commands
may generate the finite effects expressly listed here and in the bound schedules.
Host tool code is a different, expressly scoped operator-side component, never a way
for the reviewer to author more programs. It has its own review/approval prerequisite.

For CL-RP3-3 only, each primary owner may contain ONE data placeholder named claude.exe
with exact bytes SYNTHETIC_BINARY_NOT_EXECUTED (ASCII, no newline), and ONE data file
supported-help.txt with exact bytes SYNTHETIC local help fixture (ASCII, no newline).
They are generated fixture data, not an executable program. Pin hashes in synthetic
provider config as required by frozen validate_config; NEVER launch the placeholder.
Synthetic fixture-local live_dispatch_enabled/agent_use_authorized values may be true
only to reach frozen offline branches using the approved in-process executor stub.
They grant no real agent authority, never alter producer config or production gates.
An implementation worktree AND the single declared review worktree are allowed for
the same CL3 run. No prohibition here is to be read as requiring a real provider.

## D. Closed bootstrap and host-tool prerequisites (F1/F2)

The sole future task root is R = C:\Users\marcu\rv6. It has NOT been created.
Do not reuse/delete it if it exists. H0 checks absence, existing parent alias/reparse
conditions, canonical local path, staged input/runtime identities and preliminary
path arithmetic before any R write. Preliminary arithmetic is NOT represented as the
frozen checker. H0 refusal produces only terminal output; preserve its host transcript
under a separately approved capture boundary if available, otherwise record that gap.

The frozen reviewer_plan REQUIRES an existing root. Therefore, after exact approvals,
H1 creates only R, inputs, bootstrap, host, tools and host/tmp and host/session, copies
the declared inputs and exact top-level runner members, and records bootstrap state.
These LIMITED bootstrap effects are expressly permitted BEFORE frozen preflight.
No synthetic owner/store/repository/worktree or extracted implementation copy is
created by H1. H4a qualifies actual process/approval capture first; then H2 runs the one --preflight-only command from COMMANDS.json in Claude's
actual supported tool environment. On nonzero/refusal/missing proof, STOP and preserve
R and failed evidence; do not delete, retry, relocate, normalize sources or continue.
Only after actual H4a qualification, PATH_PREFLIGHT_PASS and Claude-executed H3 verification may H4b smoke/probe run.

There is deliberately NO undefined 'approved capture tool' grant. HOST_OPERATIONS.json
is the exhaustive H0-H9 responsibility/input/output/refusal contract. Runtime paths
and on-disk digests are in RUNTIME_IDENTITIES.json, and exact existing runner argv are
in COMMANDS.json. The missing operator-side bootstrap/verifier/capture/sealer CODE
is NOT implemented or authorized by this proposal. Before ANY H0 check, H1 write or live RV6
invocation, a separately authorized tool-preparation pass must supply exact code and
command digests, full bounded argv/effects, an actual independent review of those
bytes, explicit operator approval and separate supported host grants. No unknown,
placeholder or merely declared hash satisfies this prerequisite; absent bindings
mean BLOCKED. This is the explicit tooling-review option required by RV6-F2, not a
permission to add unreviewed helpers to an execution handoff.

Host bootstrap/verifier may stage/hash/verify only named inputs and frozen runtime
qualification locations. Capture may wrap observations with timestamps/argv/offsets,
but CASE_RESULTS.json and REPORT.md must be byte-exact captures of the independent
reviewer's own framed output. No coordinator-produced per-case verdict or rewritten
review. Source verification is technical evidence independently recomputed by Claude through
the approved H3 command in its actual qualified shell, not a reviewer identity claim. Probe cannot read R/inputs outside its frozen
audit boundary; host verification must not try to bypass that boundary.

## E. Exhaustive generated namespace and finite accounting

Allowed R descendants:

1. inputs/RP4_CLAUDE.zip; byte-exact supplemental_inputs descendants in the bound
   SOURCE_VERIFICATION_MATRIX; and the bound proposal/schedules/tool/approval inputs
   identified in the separately reviewed H1 concrete input manifest. No other source
   package, git archive regeneration, download or producer write.
2. bootstrap/: exactly the 19 top-level members of the original archive (their names
   and hashes are in its PACKAGE_MANIFEST, plus PACKAGE_MANIFEST itself); unchanged
   review_offline.py, review_guard.py, git_paths.py and profile. No new helper here.
3. tools/independent_probe.py only, by the exact fresh one-file approval.
4. host/: only RESOURCE_BOUNDS.host_records and host/tmp, host/session for the
   separately qualified control plane. Temporary files must be confined there,
   inventoried at seal, and may not contain generated programs or unrelated data.
5. At most two r3-<8 lowercase hex> children: one smoke, one probe. Each contains the
   frozen runner's source/.ai_pipeline, rp2_source/.ai_pipeline, rp3_source/.ai_pipeline,
   PREFLIGHT.json, RESULTS.json, t/, logs/smoke.stdout.log and smoke.stderr.log OR
   probe.stdout.log and probe.stderr.log. The probe child also has reviewer_probe.py,
   a byte-exact runner copy, not a second independently authored program.
6. In each t/: frozen-generated owner/store names plus t/rv6-evidence in the probe
   child. The latter contains at most six case JSON files and six finding logs,
   one allocations JSON, source-before/source-after JSON and one report data file;
   no executable code. stdout frames preserve classifications/report independently
   of fixture cleanup. Inputs/copies remain immutable.
7. Owner: repo synthetic repository and fixture-local config/task/synthetic text,
   owner-local alt index/object areas for CL1, declared impl AND review worktrees,
   and the CL3 data placeholder/help. Each store is a separate sibling with claims/
   and runs/ and their frozen synthetic task/config/auth/event/head/lock/checkpoint/
   diff/source/validation/dispatch-intent/completion/output records, <stem>.prompt.txt
   and <stem>.log synthetic executor evidence. No authority
   roots are selected by candidate/task data; retain bootstrap ownership, protected
   claim directory handles and exclusive one-use claim creation.
8. Git administration: only objects, refs/reflogs/locks, config, HEAD, index and normal
   linked-worktree metadata generated by the closed commands in owned trees. Inert
   *.sample template data created by qualified git init is allowed, never executed;
   no custom/executable hook, alias, include, remote or global configuration change.

Exactly six primary cases: CL-RP3-1/RP3, /RP4; CL-RP3-2/RP3, /RP4;
CL-RP3-3/RP3, /RP4. At most one primary owner/repo and one separate coordinator store
per case: six plus six. Exactly one fixed smoke invocation with four frozen tests
has a separate allocation cap of four owners and four stores. Thus at most TEN
fixture owners/repositories and TEN separately created stores, not ten total files,
trees or linked worktrees. No replacement owner/store or retries.

Per implementation: CL1 at most six variants (the three named routing variables,
each one within-owner nonempty target and empty string), CL2 at most two variants,
CL3 one. Across primary cases: at most 18 task IDs/start attempts/claim files/run
directories/implementation worktrees, and two review worktrees. Each task ID is new;
consumed claims/runs/failures cannot be erased to reuse authority. Other Git discovery,
trace/output variables are OUT of this supplemental dynamic scope, not newly approved
or declared repaired; existing fixed-suite/historical findings remain preserved.
Actual primary allocation/variant/task/claim/run/branch/worktree/file counts and paths
are required. Do not report proposed maxima as observed successful allocations.

For four frozen auto-cleaned smoke fixtures, record only observable test names,
terminal output, SUITE_COUNTS, frozen RESULTS and post-run t inventory. Individual
ephemeral paths/inventories not emitted by the unchanged runner are NOT_OBSERVABLE,
not invented or independently inferred from four test names. No extra observer or
new allocations are authorized to manufacture these unavailable records.

## F. Closed process scope and exact host boundaries

Exact outer preflight/smoke/probe argument arrays and their command-local environment
are in COMMANDS.json. Their runtime identities are pinned. Parent-command approval
must expressly cover the scheduled generated-child effects; a Python approval alone
grants none. Concrete internal Git argv must match GIT_OPERATION_INVENTORY forms and
approved probe content/RESOURCE_BOUNDS; capture actual generated paths/argv. There is
no unsupported requirement for a separate interactive prompt on each nested frozen
subprocess, and no wildcard shell grant. The closed list explicitly includes
Git diff-index --cached --quiet <commit> --, cat-file --batch, ls-tree -r -z,
local init/config/add/commit, relevant rev-parse/status/diff/merge-base/update-index
and worktree-add forms. Unlisted options/aliases/worktree move/ref rewrites stop.

The designated Git entrypoint is C:\Program Files\Git\cmd\git.exe, reference
2.40.1.windows.1. Preserve unchanged binary AND configuration fingerprints and all
frozen compatibility budgets: Git directory 200, file 230, branch-lock 230 and scratch
root 32. These are qualified local requirements, not universal Git/Windows limits.
PATH must prioritize cmd, inherited TMPDIR must be removed for the child, and the
frozen runner sets TEMP/TMP to its child/t. The exact selected Python is pinned 3.12;
no bare python fallback (current coordinator shell resolves 3.11). No global PATH,
Git config, Windows setting, ACL, installation or profile change.

Only qualified Python executing the frozen runner/guard/in-process approved probe,
qualified local Git in owned fixtures, and the separately reviewed exact host tools
are permitted offline processes. Frozen smoke is unchanged. Probe validation and
reviewer stubs are finite in-process callables producing visibly synthetic data;
observational wrappers may record and delegate unmodified operations but must not
replace/refuse preflight, invent the target exception, bypass claim or inventory
semantics, or synthesize an independent reviewer verdict. No provider executable is
launched by the probe. No arbitrary child Python, shell, PowerShell, cmd junction
creation or legacy suite is needed or granted by this supplemental schedule.

Separate project adoption, explicit execution authorization, one exact probe Write
and exact outer command/host-tool grants are all required. Host denial wins; preserve
it and mark dependent checks NOT EXECUTED. No credential/private-runtime access for
probe, socket/network/remote Git, production repo/native security test, privilege,
Grok/Grok Build, pipeline activation or autonomous development. The ONE separately
authorized real Claude review control plane may authenticate/contact its provider;
that exception never applies to offline reproduction code or children.

## G. Independence and control-plane disposition (F8)

Require default interactive/manual host permission semantics, no bypass, no user/
project/local setting sources, strict empty MCP, connectors disabled, no browser,
Agent/Task or inherited callable tools, and no producer add-dir. Effective tools:
Read/Grep/Glob plus exactly selected supported PowerShell and pending Write; only
read tools may be preallowed. Built-in non-callable metadata does not itself grant a
tool; record effective callable inventory. CLI2.1.295 native-shell selection remains
a supported-but-not-yet-observed future configuration, not a qualified live claim.
No proposal review or historical Write grant carries forward.

Capture actual CLI/runtime digests, full argv/cwd, effective settings/MCP/tools,
non-secret environment changes, every requested/granted/denied permission and process
terminal record. Default mode must actually allow supported exact approvals; if the
host cannot express or demonstrate them, STOP. Do not change permission mode to bypass.

All task AND control-plane writes are limited to R, with host/tmp and host/session
explicitly scheduled. No outside-R write is granted by this proposal. Permitted
outside-R reads are exact proposal/source inputs and runtime/Git configuration
qualification locations, and separate first-party reviewer authentication by the
control plane only, never credentials exposed to probe. The future host-tool review
must demonstrate actual nonpersistent launch/temp containment or stop before cases.
If an unavoidable outside-R control-plane write is found, this proposal provides NO
exception; return its exact path/effect for a fresh prospective operator disposition
and applicable independent review. Do not infer either absence or interference.

## H. Complete source and packet verification (F3 / RV6v2-N1)

SOURCE_VERIFICATION_MATRIX.json binds each supplied execution source, every supplied
RP3/RP4 packet including MANIFEST and SOURCE_MANIFEST, every original archive member,
and RP2 runner baseline inputs. Rows distinguish raw Git bytes (OID/content SHA/length),
supplied bytes, archive-member bytes, manifest-recorded bytes and observed checkout
bytes. 82 RP3/RP4 bindings comprise 61 execution source plus 21 packet files; RP2
baseline rows are separate. Checkout observations are provenance only, never future
execution inputs. Files absent from a manifest by deliberate self-exclusion must be
externally pinned and proven tree members; this is not permission to omit other rows.
Archive-generated evidence is pinned as such, not misrepresented as committed source.

H3 verifies raw object type/length/OID and complete tree membership chains from exact
RP3/RP4 HEADs and direct parent linkage. Each per-file declared relation is either raw
equality or raw.replace(CRLF, LF).replace(LF, CRLF) producing precisely the pinned
supplied bytes. This prospective rule relates committed objects to frozen materialized
inputs ONLY. Every archive/source-manifest, supplied-packet/manifest-entry, archive
alias, extraction and before/after comparison remains strict byte equality. No source
normalization, edit, regeneration, new expected digest or semantic equivalence. Missing
proof/row or an undeclared representation difference stops and preserves failure.

All other supplied governing and historical inputs have exact INPUT_INVENTORY hashes
and roles. New proposal/schedules are bound by REVIEW_TARGET.json, not self-hashed.
This review-only candidate package supplies original archive bytes in inputs and
supplemental proof/packet copies; staging them for execution is separately authorized.
The original archive and manifest digests in A are unchanged.

H3 MUST be a separately independently reviewed exact verifier command invoked and
awaited by Claude in its actual qualified selected shell after H2, before smoke or
probe. It must recompute every identity; reading host receipts alone is insufficient.
No verifier code is supplied or authorized here. Missing exact tool bytes, argv,
review, project execution authority or host grant BLOCKS execution before H0.

## I. Ordering, observation and failure handling (N2-N7)

Mandatory outer order is H0, H1, H4a, H2, H3, H4b, H5, H6, H7, H8. H9 is nested fixture lifecycle, not a post-H7 command: unchanged smoke auto-cleanup occurs in H4b; approved primary cleanup occurs inside the one H6 process after required observations are preserved. H0 itself requires
separately reviewed exact tool code and host approval before invocation. H1 has only
the declared bootstrap effects. H4a qualifies/captures the actual reviewer environment
and affected approvals BEFORE any reviewer preflight. H4a requires terminal launch/initialization and approval-capture proof only: it executes no frozen runner, smoke, probe or fixture. H2 uses the frozen exact
--suite all --preflight-only form; it does NOT execute all suites. H4b is one terminal
unchanged smoke after H2/H3 success; H5 one fresh content/path-bound Write; H6 one sequential probe. H4b is preparatory execution evidence, not the mandatory original/corrected reproduction and not repetition of all seven regression suites. It executes only the four frozen tests listed below, within the unchanged four-owner/four-store cap. No second smoke or new smoke artifact is authorized.
No shell wildcard grant or reuse of historical approvals.

The exact probe/parent approvals must enumerate closed Git forms, resource counts
and generated path templates before allocation. Concrete random paths and argv are
captured after allocation and checked against those templates. Observation includes
for-each-ref --format=%(refname), worktree list --porcelain, and raw cat-file --batch
calls at RP3 supervised.py:538 and RP4:546. No unrelated Git operation is authorized.

CL1 observes all three declared storage variables, nonempty owner-contained target
and empty-string variants in each implementation. CL2 executes both short and length
variants within its cap and records whether/where claim/run creation and the actual
eventual refusal occur. It must not assume the outcome. CL3 MUST observe RP3 accepting
the invalid expanded destination, creating relevant destination artifacts, AND its
actual subsequent refusal from unchanged code. Path expansion or a stub-generated
exception alone is insufficient. Compare RP4's pre-artifact refusal. Record exact
exception/source, claims/runs/refs/worktrees/files, validation/provider attempts and
terminal result for every case. Stub outputs are conspicuously synthetic; no real
provider invocation. <stem>.prompt.txt and <stem>.log are explicitly scheduled store
data, not additional reviewer-authored scripts.

Foreground sequential awaited commands only. Preserve original stdout/stderr, initial
failures, capability limitations and missing evidence. Four unchanged smoke fixtures
are auto-cleaned: record actual terminal counts and available evidence; ephemeral
per-owner detail absent from frozen output is NOT_OBSERVABLE, never invented. Primary
cases require full before/after allocation and side-effect inventories before cleanup.

The H4b tests are exactly the unchanged review_guard.py smoke selection:
EnvironmentTests.test_index_file_override_refused_before_git_claim_or_mutation;
EnvironmentTests.test_qualified_entrypoint_required;
EligibilityTests.test_valid_claim_is_created_after_complete_inventory;
DestinationTests.test_nested_destination_file_budget_is_complete.
Observe the actual unittest names, stdout/stderr, SUITE_COUNTS (collected/passed/
failures/errors/skipped), runner PREFLIGHT.json and RESULTS.json (exit_code,
timed_out, source_copy_exact), logs/smoke.stdout.log and smoke.stderr.log, terminal
status and post-run t residue through already approved capture/verifier effects.
No SMOKE.json or unavailable per-owner file is promised. Proceed only with actual
four passes, zero failures/errors/skips, exact sources, terminal exit 0 and complete
required evidence. Refusal before execution is NOT_EXECUTED; timeout/missing terminal
or evidence is INCOMPLETE; executed failures/errors/skips retain their exact counts
and stop dependent steps. Neither exit 0 nor this preparatory smoke satisfies any
of the three mandatory reproduction pairs. No probe, provider, legacy/all-suite
execution or extra resource is permitted by H4a/H4b.


H7 captures independent probe CASE_RESULTS and Claude's actual final narrative verbatim,
with stream offsets and hashes. No coordinator-authored verdict. H9 is not an actor
after H7: only the unchanged automatic smoke lifecycle in H4b and the approved probe
inside H6 may clean their allocated fixtures. Before primary explicit cleanup, emit
and flush required before/after allocation, side-effect and source observations to
captured stdout/declared evidence outside the owner/store being removed. Require
exact cleanup approval, ownership and canonical containment; absent grant, uncertain
ownership/path, failed containment or missing required inventory stops and forbids
additional explicit cleanup. Never delete root, inputs, immutable copies, logs,
case records or failed evidence. Frozen finalizers may still run during failure or
unwind; preserve the exception, partial observations and available residue, and
record unavailable ephemeral detail as missing/INCOMPLETE rather than invent it.
Capture cleanup errors/outcomes. H7 examines emitted inventories, these outcomes and
post-run t residue, not already deleted live fixtures. No host cleanup tool, second
probe, retry or residue sweep is granted; residue remains for separate operator
disposition. Cleanup failure or missing required evidence cannot be a successful gate.
H8 waits for writers to close, inventories finalized immutable files, seals last, and
prints final status only to terminal. Never hash a still-changing stdout log. Any
missing/mismatched required evidence prevents an inferred acceptance-gate result.

## J. Verbatim evidence, terminal closure and finalization

Probe reports six terminal case classifications and full observations in framed
probe-authored JSON stdout and declared evidence data. Host CASE_RESULTS is a byte-
exact capture of that independently authored/executed probe output. REPORT.md is the
actual Claude final narrative/verdict captured from the reviewer control-plane response,
not a probe-generated report substituted for Claude. Preserve both raw streams and
offsets. Host wrappers may not supply/rewrite the independent verdict. Missing actual
Claude final output remains INCOMPLETE even if all probe cases report success.
Reviewer must distinguish technical results from governance/
permission sufficiency and report PASS/PASS_WITH_NON_BLOCKING_FINDINGS/REVISE/FAIL/
INCOMPLETE plus readiness bound to exact implementation/proposal/evidence identities.

Before sealing, await processes, verify terminal exit/timeout, finish captures and
close SESSION/STDERR/report writers. Freeze source-after and allocation records.
Hash finalized evidence only. EVIDENCE_HASHES records final files and explicit
missing/mismatched entries; it excludes only itself and SEAL. SEAL binds the closed
inventory and proposal digest. No actively changing log is hashed, no finalizer appends
to an inventoried stream, no inventory is silently repaired. Raw input paths retained
outside R are listed as immutable external inputs, not falsely claimed copied outputs.
Missing approval, case, terminal record or required integrity evidence means incomplete/
unsatisfied evidence, irrespective of process success. Any excluded/unreadable file
is explicit and cannot be hidden as a pass.

## K. Preserved status and mandatory stop

RP4 remains NOT ACCEPTED, actual independent regression result194/0/0/1 and
PASS_WITH_NON_BLOCKING_FINDINGS unchanged. Mandatory gate remains UNSATISFIED pending
separate adjudication of admissible reproduction evidence. RV5 remains non-adopted,
including its preserved59/60 historical hash result. Original v1 REVISE and all
failed reviews/experiments remain intact. CL-RP4-1..4, CL-RP3-4/5, C2-C4/R2/G1 and all
other historical findings are not closed here. No RP5, repair of frozen source/tests,
contract replacement, Routing Policy adoption, accepted M5/M6 runtime/model change,
Grok invocation, live controller, autonomous authority, push/merge/release/deployment
or acceptance. All six production gates remain FALSE:
GIT_EXECUTION_AVAILABLE, PHYSICAL_PREPARATION_AVAILABLE, PRODUCTION_ANCHOR_AVAILABLE,
PRODUCTION_CANDIDATE_AVAILABLE, PRODUCTION_PROVISIONING_AVAILABLE, PRODUCTION_SCOPE_AVAILABLE.

Next decision after this proposal's review: exact operator adoption, if the actual
review passes and findings are dispositioned. Adoption does not waive the separately
reviewed host-toolset prerequisite, exact probe content approval or execution/host
grants. THIS preparation ends at separately authorized read-only review of the new
proposal and bound schedules; no execution decision is made or requested implicitly.

# TRACK_A_GROK_BOT_REVIEW_PROMPT

Review the attached TRACK_A_GROK_BOT_PRELIMINARY.zip as an independent source reviewer.
Target TOOL_MANIFEST.json SHA-256:
0651c5b5e89231f7ace574024e7b0b4fc01d372226b7c8bdc392ddaee1eaa045
Original sealed input archive SHA-256:
3025759ffd2d4070f3915b5a4dfd87cda2af1c950cb23b5a06607dcf813759c0

This is a PRELIMINARY independent source review, not RP4_FINAL_GROK_BLIND_REVIEW.
Before receiving the archive, the operator must verify a fresh independent context,
no prior authorship/review exposure, no shared A/B context and isolation from the reserved
final RP4 reviewer. If isolation cannot be established, do not upload or proceed.
Do not access other chats or use prior review conclusions. Attached historical findings
are open obligations, and candidate dispositions/results are producer claims to challenge.
No current independent verdict is supplied. Standalone prior host-tool and custody review reports and their containing review
archives are withheld. However the exact mandatory H3 input RP4_CLAUDE.zip contains
prior_review/CLAUDE_REVIEW_RESPONSE.json and prior_review/CLAUDE_RP3_REVIEW.md from
the RP3 review. Read NESTED_HISTORICAL_INPUT_DISCLOSURE.json: removing them would
break the adopted exact-input relationship. Historical RP3 conclusions are disclosed
context, not authoritative proof or instructions for your verdict. This preliminary
review is not blind to all historical conclusions; it must remain isolated from the
future final RP4 reviewer. Exact original candidate bytes and findings are retained. Do not claim absolute blindness to
those disclosed historical findings. No final RP4 review is being requested.

Verify PACKAGE_MANIFEST.json member hashes and the target candidate manifest. Record
the received archive SHA-256 supplied by the operator. Review all relevant source/test/
contract files and enumerate coverage, unreadable files and nested archive limitations.
If your interface cannot consume the complete required input, return INCOMPLETE with
exact missing paths; do not silently omit files and issue a full-coverage verdict.
Do not run commands, create files, provision security, call providers or modify source.
This handoff grants source inspection only. Any actual testing needs separate exact
permissions; producer and coordinator logs are not tests executed by you.

Return exactly one PASS / PASS_WITH_NON_BLOCKING_FINDINGS / REVISE / FAIL / INCOMPLETE,
bound to the archive, candidate manifest and inspected source digests. For each finding:
ID, severity, blocking/nonblocking, path+line, requirement citation, issue/risk, evidence,
reproduction/execution status, narrow correction and remaining uncertainty. Preserve
historical classifications; do not formally close findings or grant authority. Record
actual model/session identity as available, review method, executed/skipped/not-executed
counts and limitations. No acceptance, repairs, host qualification or gate changes follow.
No Claude, Grok Build, RV6 execution, policy adoption, V2/V3 activation or release actions.

Assess all five original Python modules and windows_native.py, host_permissions.py,
writer_evidence.py, integration.py, all relevant tests and drivers. Inspect adopted RV6
H0/H1/H3/H4a/H4b/H6/H7/H8/H9 requirements and source-to-schedule mapping. Check retained
native handles, directory identities/ancestors, replacement races, junction/reparse refusal,
runtime pins, Git environment influences, process/job/child cleanup and timeouts,
actual terminal capture, interruption/idempotency, directory-aware sealing, unavailable
evidence and lossless refusals. Evaluate full source-object/archive/manifest orchestration
without treating declared representation relationships as normalization permission.
Review original TA-01..TA-11 obligations and source snapshots/raw initial failures; judge
the correction from source rather than proposed disposition labels. Preserve optional scope.

Explicitly distinguish retained ordinary file-sharing exclusion from principal isolation
and immutable namespace proof. Inspect empty live host-adapter registry and refusal paths;
do not infer host execution authority from valid offline receipts or JSON grants.
Identify missing integration/qualification originating in adopted requirements separately
from optional improvements. Decide suitability for separately authorized host qualification.

Producer reference:81 passed/0 failed/0 errors/1 capability skip. Separately, Codex executed
the unchanged driver at hqr3:81/0/0/1, terminal exit0; source unchanged. These observations
must be independently assessed as supplied evidence, never attributed to Grok testing.
The symlink WinError1314 skip is not a pass; junction refusal actually ran. hqr3 is now
historical, so do not rerun there. No RV6 probe/reproduction was executed.

Return module coverage, actual independently executed test counts (zero unless genuinely
executed with new authorization), remaining host qualification, and exactly one:
READY_FOR_HOST_QUALIFICATION / NOT_READY_FOR_HOST_QUALIFICATION.
Source review cannot satisfy the mandatory independent RV6 dynamic reproduction gate.

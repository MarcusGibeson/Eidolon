from pathlib import Path
import sys,os,json,unittest,hashlib,shutil
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'candidate'));root=Path(r'C:\Users\marcu\hqa3');assert root.is_dir();assert not (R/'evidence/FINAL_UNIT.json').exists()
os.environ['EIDOLON_OFFLINE_TEST_ROOT']=str(root)
import test_integration as T
T.Tests.counter=5000
snapshot=R/'evidence/FINAL_TESTED_CODE';snapshot.mkdir()
pins={}
for p in (R/'candidate').glob('*.py'):pins[p.name]=hashlib.sha256(p.read_bytes()).hexdigest();shutil.copyfile(p,snapshot/p.name)
with (R/'evidence/FINAL_UNIT.log').open('x',encoding='utf-8') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(T))
d={'passed':r.testsRun-len(r.failures)-len(r.errors)-len(r.skipped),'failed':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'source_sha256':pins,'resources':T.LEDGER,'reason':'One final freeze regression run after adding separately tested H1 staging and H7 byte capture. No user retry bound increased; producer test driver prior4 attempts unchanged.','source_snapshot':'FINAL_TESTED_CODE','actual_RV6':False}
(R/'evidence/FINAL_UNIT.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n');print(json.dumps({k:v for k,v in d.items() if k not in ('resources','source_sha256')}));raise SystemExit(0 if r.wasSuccessful() else 1)

"""Single-use qualification driver. No permission grant or RV6 execution."""
from pathlib import Path
import sys,json,os,hashlib,argparse,unittest
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'candidate'))
from host_core import require,no_alias
from windows_native import PinnedTree,child
def main():
 p=argparse.ArgumentParser();p.add_argument('--root',required=True);p.add_argument('--preflight-only',action='store_true');a=p.parse_args();root=Path(a.root).absolute()
 require(root in (Path(r'C:\Users\marcu\hqa3'),Path(r'C:\Users\marcu\hqr3')),'OFFLINE_ROOT_REQUIRED');no_alias(root.parent);require(not root.exists(),'ROOT_EXISTS_PRESERVE')
 if a.preflight_only:print(json.dumps({'root_absent':True,'source_or_tests_executed':False,'root_created':False,'host_permission_granted':False}));return 0
 with PinnedTree(root.parent) as t:
  h=child(t.root,root.name,True,create=True);t.handles.append(h);os.environ['EIDOLON_OFFLINE_TEST_ROOT']=str(root)
  import test_integration as T
  sys.path.insert(0,str(R));import test_staging_followup as S
  evidence=root/'qualification-evidence';evidence.mkdir();pins={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'candidate').iterdir() if p.is_file()}
  (evidence/'SOURCE_BEFORE.json').write_text(json.dumps(pins,indent=2),encoding='utf-8');suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(T),unittest.defaultTestLoader.loadTestsFromTestCase(S.StageTests)])
  with (evidence/'TESTS.log').open('x',encoding='utf-8') as f:r=unittest.TextTestRunner(stream=f,verbosity=2).run(suite)
  changed=[n for n,v in pins.items() if hashlib.sha256((R/'candidate'/n).read_bytes()).hexdigest()!=v];t.validate();summary={'passed':r.testsRun-len(r.failures)-len(r.errors)-len(r.skipped),'failed':len(r.failures),'errors':len(r.errors),'skipped':len(r.skipped),'source_before_sha256':pins,'source_changed':changed,'resources':T.LEDGER,'execution_authorized':False,'actual_RV6':False}
  (evidence/'RESULTS.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in summary.items() if k not in ('resources','source_before_sha256')}));return 0 if r.wasSuccessful() and not changed else 1
if __name__=='__main__':raise SystemExit(main())

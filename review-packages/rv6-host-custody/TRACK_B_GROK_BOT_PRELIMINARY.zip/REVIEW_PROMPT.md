# TRACK_B_GROK_BOT_REVIEW_PROMPT

Review the attached TRACK_B_GROK_BOT_PRELIMINARY.zip as an independent source reviewer.
Target RECIPE_MANIFEST.json SHA-256:
096ec9ca12c32590321f0c8aaa647b0553655d946e54cf5e785d10a804111d28
Original sealed input archive SHA-256:
a23a58829804a6d00194c05690a40ec6ca78e4d770dc48741a1fd1392a5296cf

This is a PRELIMINARY independent source review, not RP4_FINAL_GROK_BLIND_REVIEW.
Before receiving the archive, the operator must verify a fresh independent context,
no prior authorship/review exposure, no shared A/B context and isolation from the reserved
final RP4 reviewer. If isolation cannot be established, do not upload or proceed.
Do not access other chats or use prior review conclusions. Attached historical findings
are open obligations, and candidate dispositions/results are producer claims to challenge.
No current independent verdict is supplied. Full standalone prior reviewer reports and
their containing archives are withheld; exact original candidate bytes are retained,
including historical obligations intrinsic to them. Do not claim absolute blindness to
those disclosed historical findings. No final RP4 review is being requested.

Verify PACKAGE_MANIFEST.json member hashes and the target candidate manifest. Record
the received archive SHA-256 supplied by the operator. Review all relevant source/test/
contract files and enumerate coverage, unreadable files and nested archive limitations.
If your interface cannot consume the complete required input, return INCOMPLETE with
exact missing paths; do not silently omit files and issue a full-coverage verdict.
Do not run commands, create files, provision security, call providers or modify source.
This handoff grants source inspection only. Any actual testing needs separate exact
permissions; producer and coordinator logs are not tests executed by you.

Return exactly one PASS / PASS_WITH_NON_BLOCKING_FINDINGS / REVISE / FAIL / INCOMPLETE,
bound to the archive, candidate manifest and inspected source digests. For each finding:
ID, severity, blocking/nonblocking, path+line, requirement citation, issue/risk, evidence,
reproduction/execution status, narrow correction and remaining uncertainty. Preserve
historical classifications; do not formally close findings or grant authority. Record
actual model/session identity as available, review method, executed/skipped/not-executed
counts and limitations. No acceptance, repairs, host qualification or gate changes follow.
No Claude, Grok Build, RV6 execution, policy adoption, V2/V3 activation or release actions.

Assess the revised Option A specification, pure custody_predicates.py and tests, ten-check
contract/collection requirements, twelve-phase sequence, protected-stage/signing bootstrap,
principal decisions, command inventory, negative verification and disable-only recovery.
R2-B01: noncircular account/qualification ordering; raw verifiable evidence for every ledger
check; meaningful predicates; missing/inconclusive refusal; exact approval boundaries.
R2-B02: staging creation order; ancestor owner/ACL/replacement protection; trusted loading;
independent manifest pins; external signing-key custody; trust-store effects; separately
reviewed source and signed-output manifests; revocation and evidence-preserving rollback.
Challenge historical F01-F05 and relevant F06-F13/nonblocking obligations without treating
proposed dispositions as closure. Assess current administrator/shared-user migration,
token/groups/privileges/integrity/elevation/linked tokens, effective access vs static ACL,
launch evidence, AllSigned and absent principals/signing capability. No prior proposal
or code scaffold is an executable adopted provisioning procedure.

Producer36 synthetic predicate tests and59 structural checks are supplied evidence only;
no actual account/ACL/signing/launch/access-denial provisioning or host qualification ran.
Do not execute run_checks.py: it is preserved historical producer code, not a read-only
review entrypoint, and attempt1 modifies the source contract. Inspect it only.
Return status of R2-B01/B02 and dependent historical findings, new blocking/nonblocking
findings, remaining concrete custody decisions, required runtime verification and one:
READY_FOR_OPERATOR_PROVISIONING_DECISION / NOT_READY_FOR_PROVISIONING_DECISION.
Distinguish adequacy of a proposal from executable provisioning readiness and deployed
security. No project or host authority is granted by a favourable review.

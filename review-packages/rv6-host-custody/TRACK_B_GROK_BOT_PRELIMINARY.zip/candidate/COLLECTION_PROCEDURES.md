# Exact collection procedures — prospective, not executed

Common binding: freeze observer source/compiled manifest, API argument/object/principal sets, output schema and verifier manifest; review independently; obtain exact operator and host command grants before collection. Before relying on evidence, inspect collector image and primary token via a parent-retained process handle, capture PID/starttime/session, UTC, exact source/output manifests and raw API status/results. Collector output is not trusted because it has a matching local hash. The evaluator accepts only a separately approved expected context; output never grants authority. Every unresolved principal, access-denied query, missing page, unsupported API, privilege-assisted unknown or collection error is INCOMPLETE_REFUSED. Read-only collection creates only its exclusive approved evidence output plus declared audit records.

Dangerous masks: FILE_WRITE_DATA=2, FILE_APPEND_DATA=4, FILE_WRITE_EA=16, FILE_WRITE_ATTRIBUTES=256, FILE_DELETE_CHILD=64, DELETE=0x10000, WRITE_DAC=0x40000, WRITE_OWNER=0x80000. Evaluate all masks separately and combined with the same generic mapping. For directories include parent deletion/replacement and every ancestor. Static DACL inspection is not effective access and neither is runtime denial.

Required access matrix keys are the Cartesian product of approved actual token identities, exact FileIds/object identities and dangerous-right masks. Include filtered and linked/elevated marcu contexts and group closure, sandbox users/groups, all well-known groups, actual custodian and future roles once they exist. No synthetic group-only token may substitute for an actual effective-access context. Trusted maintenance contexts are explicitly separated from agent-reachable contexts. LSA rights/privileges are evaluated even when disabled.

## migration_no_admin_agent_contexts

Earliest phase 1. Verifier custody_predicates.py:evaluate_check/migration.
APIs/commands: EnumProcesses+OpenProcessToken+GetTokenInformation(TokenUser,TokenGroups,TokenPrivileges,TokenElevationType,TokenLinkedToken); NetLocalGroupGetMembers all groups; EnumServicesStatusExW+QueryServiceConfigW; Task Scheduler ITaskService/GetFolder/GetTasks recursive read-only; RegGetValueW HKLM Policies/System UAC.
Raw artifact evidence/migration_no_admin_agent_contexts.json must contain processes, services, tasks, agent_reachable_admin_sids, unobserved_objects.
Acceptance: No agent process/task/service or launch credential can reach custodian, Administrators or an elevated/linked token; all enumerations complete. Custodian identity and migration authority independently pinned.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## stage_effective_exclusion

Earliest phase 2. Verifier custody_predicates.py:evaluate_check/rights.
APIs/commands: GetNamedSecurityInfoW owner/DACL/protection on stage and every ancestor; AuthzInitializeContextFromToken + AuthzAccessCheck for each pinned principal/token and each dangerous mask; GetFileInformationByHandle FileId/volume and reparse attributes.
Raw artifact evidence/stage_effective_exclusion.json must contain objects, access_matrix, unobserved_objects.
Acceptance: Exact approved owner/DACL/protection and no reparse; every dangerous right denied to each agent-reachable context including parent FILE_DELETE_CHILD. Custodian/SYSTEM/admin trusted maintenance contexts explicitly identified.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## evidence_parent_effective_exclusion

Earliest phase 2. Verifier custody_predicates.py:evaluate_check/rights.
APIs/commands: GetNamedSecurityInfoW; AuthzAccessCheck; GetFileInformationByHandle.
Raw artifact evidence/evidence_parent_effective_exclusion.json must contain objects, access_matrix, unobserved_objects.
Acceptance: Same complete per-object/per-token matrix on evidence root and ancestors, protected owner/DACL; no candidate or agent mutation rights.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## policy_ancestor_effective_exclusion

Earliest phase 5. Verifier custody_predicates.py:evaluate_check/rights.
APIs/commands: GetNamedSecurityInfoW; AuthzAccessCheck; GetFileInformationByHandle.
Raw artifact evidence/policy_ancestor_effective_exclusion.json must contain objects, access_matrix, unobserved_objects.
Acceptance: Same matrix for proposed policy root and every ancestor after separately authorized creation; no assertion that root exists before phase5.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## LSA_rights

Earliest phase 1. Verifier custody_predicates.py:evaluate_check/lsa.
APIs/commands: LsaOpenPolicy(POLICY_LOOKUP_NAMES); LsaEnumerateAccountRights for every bound SID including group-derived rights; NetLocalGroupGetMembers.
Raw artifact evidence/LSA_rights.json must contain sid_rights, unobserved_objects.
Acceptance: Complete exact principal set; no unapproved bypass/logon/service/task privilege; inherited group rights included; precise allowlists approved per role. Future role rows collected again after phase4.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## native_script_signature

Earliest phase 2. Verifier custody_predicates.py:evaluate_check/signature.
APIs/commands: WinVerifyTrust(WINTRUST_ACTION_GENERIC_VERIFY_V2); CryptQueryObject/AuthentiCode signed-content extraction; CertGetCertificateChain+CertVerifyCertificateChainPolicy; CertEnumCertificatesInStore LocalMachine Root/TrustedPublisher read-only.
Raw artifact evidence/native_script_signature.json must contain files, trust_store_inventory, unobserved_objects.
Acceptance: Exact signed-output file hashes, independent signer allowlist, valid chains/time/revocation observations, reviewed unsigned source hash and exact signature-only relation; all executable/script/DLL members covered.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## module_and_DLL_load_context

Earliest phase 6. Verifier custody_predicates.py:evaluate_check/loading.
APIs/commands: QueryFullProcessImageNameW retained parent handle; GetEnvironmentStringsW child capture; EnumProcessModulesEx + GetModuleFileNameExW from observer; GetCurrentDirectoryW; GetTokenInformation.
Raw artifact evidence/module_and_DLL_load_context.json must contain runtime, module_hashes, environment, unobserved_objects.
Acceptance: Windows PowerShell Desktop5.1 exact PSHOME/image hash/argv/cwd; every loaded module/DLL approved by hash; exact complete environment, no unknown COR_/COMPlus_/profiling overrides; trusted protected TEMP/TMP.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## launch_feasibility

Earliest phase 7. Verifier custody_predicates.py:evaluate_check/launch.
APIs/commands: CreateProcess exact separately reviewed isolated launcher (mutating, separate command grant); QueryFullProcessImageNameW; parent OpenProcessToken retained process handle; GetTokenInformation TokenUser/TokenOwner/TokenGroups/TokenPrivileges/TokenIntegrityLevel/TokenElevation/TokenElevationType/TokenLinkedToken.
Raw artifact evidence/launch_feasibility.json must contain processes, negative_access, unobserved_objects.
Acceptance: Exactly the four created-role SIDs and their parent-observed primary non-elevated tokens; complete group/privilege allowlists; owner==user; no linked token; approved desktop/session isolation; runtime denial evidence follows phase9. NOT a prerequisite for account creation.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## all_local_group_queries

Earliest phase 1. Verifier custody_predicates.py:evaluate_check/groups.
APIs/commands: NetLocalGroupEnum level0; NetLocalGroupGetMembers level2 for every returned group, paginated until NERR_Success; LookupAccountSidW.
Raw artifact evidence/all_local_group_queries.json must contain groups, query_errors, unobserved_objects.
Acceptance: Complete local group enumeration with zero query errors/unresolved members, exact approved membership closure. Explicit operator disposition required for INTERACTIVE nested in Performance Log Users559. Recollect after account creation.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## maintenance_token

Earliest phase 2. Verifier custody_predicates.py:evaluate_check/token.
APIs/commands: GetCurrentProcess+OpenProcessToken(TOKEN_QUERY); GetTokenInformation TokenUser/TokenOwner/TokenType/TokenGroups/TokenPrivileges/TokenElevation/TokenElevationType/TokenLinkedToken; QueryFullProcessImageNameW.
Raw artifact evidence/maintenance_token.json must contain token, unobserved_objects.
Acceptance: Primary elevated Full custodian token under approved exact SID, never marcu; complete attributes/privileges match approved set, process owner/image/argv/source binding all exact; actor demonstrably outside agent-reachable credentials.
Binding/authority: Read-only observation under separately reviewed pinned collector grant; phase7 launcher and phase9 negative access require separate mutating grants. Unknown or missing evidence refuses; no QUALIFIED override.

## Runtime negative access (phase9 only)

A separate reviewed launcher obtains the actual role token and fixed canary target set. Parent observes SID, owner, groups/attributes, all privileges, integrity/elevation/linked-token state and image/session from retained handles. For each role and exact approved canary/ancestor exercise create/write/append/delete/rename/replace/WRITE_DAC/WRITE_OWNER independently. Capture exact requested rights, Win32/NT status, target FileId, before/after digest and SDDL, and cleanup result. A denied call is insufficient if the target changed or process identity is unknown. No real registry, authority anchor, accepted runtime or frozen source is a canary. Missing or skipped denial case blocks the final ledger. Current phase performs none.

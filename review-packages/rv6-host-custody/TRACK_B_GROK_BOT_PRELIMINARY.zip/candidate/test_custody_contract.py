import unittest,copy,json
from pathlib import Path
from custody_predicates import *
def fixture():
 roles=['S-1-5-21-1-'+str(i) for i in range(4)];h='a'*64
 c={k:h for k in PINS};c.update(collection_session='synthetic-not-host',expected_observer_token_sha256=h,expected_principals=['worker','maintenance'],agent_tokens=['worker'],maintenance_sid='S-1-5-21-1-99',trusted_maintenance_sids=['S-1-5-21-1-99'],agent_reachable_sids=roles,forbidden_agent_groups=['S-1-5-32-544'],expected_role_sids=roles,expected_objects={},expected_access_grants={},expected_token_proofs={'worker':h,'maintenance':h},expected_lsa_rights={s:['SeChangeNotifyPrivilege'] for s in roles},signed_files={'entry.ps1':{'signed_sha256':h,'unsigned_sha256':h,'signature_relation_sha256':h}},expected_signers=['SYNTHETIC'],expected_trust_store_inventory=[{'store':'synthetic','sha256':h}],expected_runtime={'PSEdition':'Desktop','PSHOME':r'C:\Windows\System32\WindowsPowerShell\v1.0','image_sha256':h},expected_modules={'kernel32.dll':h},expected_environment={'SystemRoot':r'C:\Windows'},expected_token_groups={s:[{'sid':'S-1-5-32-545','attributes':7}] for s in roles},expected_privileges={s:[{'name':'SeChangeNotifyPrivilege','attributes':3}] for s in roles},expected_role_image_sha256=h,expected_desktop_session='approved-isolated-session',expected_canaries=['synthetic-canary'],expected_group_closure={'Users':roles},expected_maintenance_owner='S-1-5-32-544',expected_maintenance_groups=['S-1-5-32-544'],expected_maintenance_privileges=['SeChangeNotifyPrivilege'],expected_maintenance_image_sha256=h)
 b={n:{'id':n,'context_sha256':None,'collector_manifest_sha256':h,'verifier_manifest_sha256':h,'collection_session':c['collection_session'],'collection_UTC':'synthetic-UTC','unobserved_objects':[],'api_errors':[],'enumeration_complete':True,'observer_token_sha256':h,'raw_api_trace':[{'API':'synthetic','status':0}]} for n in CHECKS}
 b['migration_no_admin_agent_contexts'].update(processes=[{'actor':'agent','identity_sha256':h,'sid':roles[0],'elevated':False,'linked_token':None,'groups':['S-1-5-32-545']}],services=[],tasks=[],agent_reachable_admin_sids=[])
 for id in ('stage_effective_exclusion','evidence_parent_effective_exclusion','policy_ancestor_effective_exclusion'):
  obj={'owner_sid':c['maintenance_sid'],'sddl':'SYNTHETIC-APPROVED-DACL','file_id':'volume:file'};c['expected_objects'][id]={'target':obj};c['expected_access_grants'][id]={};rows=[]
  for p in c['expected_principals']:
   for mask in MASKS:
    granted=0 if p=='worker' else mask;c['expected_access_grants'][id][p+'|target|'+str(mask)]=granted;rows.append({'token_id':p,'object_id':'target','requested_mask':mask,'api_status':0,'granted_mask':granted,'token_proof_sha256':h})
  b[id].update(objects=[dict(obj,object_id='target',reparse_tag=0,dacl_protected=True)],access_matrix=rows)
 b['LSA_rights']['sid_rights']=copy.deepcopy(c['expected_lsa_rights'])
 b['native_script_signature'].update(files=[dict(c['signed_files']['entry.ps1'],path='entry.ps1',signer_thumbprint='SYNTHETIC',WinVerifyTrust_status=0,chain_policy_status=0,revocation_status=0)],trust_store_inventory=copy.deepcopy(c['expected_trust_store_inventory']))
 b['module_and_DLL_load_context'].update(runtime=copy.deepcopy(c['expected_runtime']),module_hashes=copy.deepcopy(c['expected_modules']),environment=copy.deepcopy(c['expected_environment']))
 processes=[{'sid':s,'owner_sid':s,'TokenType':1,'TokenElevationType':1,'elevated':False,'linked_token':None,'integrity':8192,'parent_observed':True,'retained_process_identity':'synthetic-pid-'+s,'starttime':'synthetic-start','groups':c['expected_token_groups'][s],'privileges':c['expected_privileges'][s],'image_sha256':h,'desktop_session':c['expected_desktop_session']} for s in roles]
 negatives=[{'sid':s,'target':t,'action':a,'win32_error':5,'before_sha256':h,'after_sha256':h,'cleanup_status':'RECORDED_COMPLETE'} for s in roles for t in c['expected_canaries'] for a in ('create','write','append','delete','rename','replace','WRITE_DAC','WRITE_OWNER')]
 b['launch_feasibility'].update(processes=processes,negative_access=negatives);b['all_local_group_queries'].update(groups=copy.deepcopy(c['expected_group_closure']),query_errors=[])
 b['maintenance_token']['token']={'sid':c['maintenance_sid'],'owner_sid':c['expected_maintenance_owner'],'TokenType':1,'TokenElevationType':2,'elevated':True,'groups':c['expected_maintenance_groups'],'privileges':c['expected_maintenance_privileges'],'image_sha256':h}
 for row in b.values():row['context_sha256']=digest(c)
 return b,c
class ContractTests(unittest.TestCase):
 def setUp(self):self.b,self.c=fixture()
 def deny(self):
  with self.assertRaises(EvidenceRefusal):evaluate_bundle(self.b,self.c)
 def test_consistent_synthetic_bundle_never_authority(self):r=evaluate_bundle(self.b,self.c);self.assertEqual(len(r['checks']),10);self.assertFalse(r['execution_authority']);self.assertFalse(r['operational_qualification'])
 def test_attestation_only_refused(self):self.b={n:{'id':n,'status':'QUALIFIED'} for n in CHECKS};self.deny()
 def test_unknown_verifier(self):self.b[CHECKS[0]]['verifier_manifest_sha256']='f'*64;self.deny()
 def test_wrong_context(self):self.b[CHECKS[0]]['context_sha256']='f'*64;self.deny()
 def test_missing_check(self):del self.b[CHECKS[0]];self.deny()
 def test_extra_check(self):self.b['unknown']={};self.deny()
 def test_unobserved_object(self):self.b[CHECKS[0]]['unobserved_objects']=['unknown'];self.deny()
 def test_API_error(self):self.b[CHECKS[0]]['api_errors']=[5];self.deny()
 def test_incomplete_enumeration(self):self.b[CHECKS[0]]['enumeration_complete']=False;self.deny()
 def test_missing_raw_trace(self):self.b[CHECKS[0]]['raw_api_trace']=[];self.deny()
 def test_agent_admin(self):self.b[CHECKS[0]]['processes'][0]['groups']=['S-1-5-32-544'];self.deny()
 def test_migration_task_admin(self):self.b[CHECKS[0]]['tasks']=[{'actor':'agent','identity_sha256':'a'*64,'sid':self.c['expected_role_sids'][0],'elevated':True}];self.deny()
 def test_missing_access_cell(self):self.b['stage_effective_exclusion']['access_matrix'].pop();self.deny()
 def test_duplicate_access_cell(self):r=self.b['stage_effective_exclusion']['access_matrix'];r.append(r[0]);self.deny()
 def test_agent_writable(self):self.b['stage_effective_exclusion']['access_matrix'][0]['granted_mask']=2;self.deny()
 def test_parent_reparse(self):self.b['stage_effective_exclusion']['objects'][0]['reparse_tag']=1024;self.deny()
 def test_wrong_owner(self):self.b['stage_effective_exclusion']['objects'][0]['owner_sid']='unknown';self.deny()
 def test_LSA_unknown(self):self.b['LSA_rights']['sid_rights']['S-1-unknown']=[];self.deny()
 def test_LSA_bypass(self):self.b['LSA_rights']['sid_rights'][self.c['expected_role_sids'][0]]=['SeTcbPrivilege'];self.deny()
 def test_signature_failure(self):self.b['native_script_signature']['files'][0]['WinVerifyTrust_status']=1;self.deny()
 def test_source_signature_relation(self):self.b['native_script_signature']['files'][0]['unsigned_sha256']='f'*64;self.deny()
 def test_unapproved_signer(self):self.b['native_script_signature']['files'][0]['signer_thumbprint']='UNKNOWN';self.deny()
 def test_trust_store_drift(self):self.b['native_script_signature']['trust_store_inventory']=[];self.deny()
 def test_wrong_runtime(self):self.b['module_and_DLL_load_context']['runtime']['PSEdition']='Core';self.deny()
 def test_unknown_module(self):self.b['module_and_DLL_load_context']['module_hashes']['unknown.dll']='f'*64;self.deny()
 def test_wrong_environment(self):self.b['module_and_DLL_load_context']['environment']['COR_PROFILER']='unknown';self.deny()
 def test_parent_token_absent(self):self.b['launch_feasibility']['processes'][0]['parent_observed']=False;self.deny()
 def test_linked_token(self):self.b['launch_feasibility']['processes'][0]['linked_token']={};self.deny()
 def test_wrong_role_sid(self):self.b['launch_feasibility']['processes'][0]['sid']='S-1-unknown';self.deny()
 def test_negative_case_absent(self):self.b['launch_feasibility']['negative_access'].pop();self.deny()
 def test_canary_changed(self):self.b['launch_feasibility']['negative_access'][0]['after_sha256']='f'*64;self.deny()
 def test_group_unknown(self):self.b['all_local_group_queries']['groups']['Unknown']=[];self.deny()
 def test_maintenance_filtered(self):self.b['maintenance_token']['token']['TokenElevationType']=3;self.deny()
 def test_missing_principals(self):self.c['expected_role_sids']=None;self.deny()
 def test_missing_pin(self):self.c['collector_manifest_sha256']='0'*64;self.deny()
 def test_ten_semantic_fields_required(self):
  for n,key in [('migration_no_admin_agent_contexts','processes'),('stage_effective_exclusion','objects'),('evidence_parent_effective_exclusion','access_matrix'),('policy_ancestor_effective_exclusion','objects'),('LSA_rights','sid_rights'),('native_script_signature','files'),('module_and_DLL_load_context','runtime'),('launch_feasibility','processes'),('all_local_group_queries','groups'),('maintenance_token','token')]:
   with self.subTest(check=n):
    b,c=fixture();del b[n][key]
    with self.assertRaises(EvidenceRefusal):evaluate_bundle(b,c)

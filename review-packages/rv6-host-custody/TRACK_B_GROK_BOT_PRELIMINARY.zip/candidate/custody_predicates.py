"""Pure offline semantic evaluator. No host collection, provisioning or authority.

Expected context MUST come from separately adopted protected authority, never
the candidate. Even a fully consistent bundle returns no host qualification.
Native collector authentication, actual host grants and independent review are
external prerequisites, explicitly not emulated by these data predicates.
"""
import hashlib,json,re
class EvidenceRefusal(ValueError):pass
def need(ok,why):
 if not ok:raise EvidenceRefusal(why)
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
MASKS=(2,4,16,256,64,65536,262144,524288)
MASKS=MASKS+(sum(MASKS),)
BYPASS={'SeDebugPrivilege','SeTcbPrivilege','SeImpersonatePrivilege','SeAssignPrimaryTokenPrivilege','SeCreateTokenPrivilege','SeBackupPrivilege','SeRestorePrivilege','SeTakeOwnershipPrivilege','SeLoadDriverPrivilege','SeManageVolumePrivilege','SeSecurityPrivilege','SeRelabelPrivilege','SeTrustedCredManAccessPrivilege','SeSystemEnvironmentPrivilege','SeCreateSymbolicLinkPrivilege'}
CHECKS=('migration_no_admin_agent_contexts','stage_effective_exclusion','evidence_parent_effective_exclusion','policy_ancestor_effective_exclusion','LSA_rights','native_script_signature','module_and_DLL_load_context','launch_feasibility','all_local_group_queries','maintenance_token')
PINS=('unsigned_source_manifest_sha256','signed_output_manifest_sha256','operator_authorization_sha256','collector_manifest_sha256','verifier_manifest_sha256')
def context(c):
 for n in PINS:need(isinstance(c.get(n),str) and re.fullmatch('[0-9a-f]{64}',c[n]) and c[n]!='0'*64,'MISSING_AUTHORITY_PIN:'+n)
 need(c.get('collection_session') and len(c.get('expected_role_sids',[]))==4 and len(set(c['expected_role_sids']))==4,'ROLE_IDENTITY_UNRESOLVED')
 need(all(isinstance(v,str) and v.startswith('S-1-') for v in c['expected_role_sids']),'ROLE_IDENTITY_UNRESOLVED')
 need(c.get('maintenance_sid') and c['maintenance_sid'] not in c['expected_role_sids'] and c['maintenance_sid']!= 'S-1-5-21-792233167-3427833224-1744323547-1001','CUSTODIAN_UNRESOLVED')
 need(c.get('expected_principals') and c.get('expected_objects') and c.get('agent_tokens'),'EXPECTED_SCOPE_MISSING')
 need(set(c['agent_tokens'])<=set(c['expected_principals']),'EXPECTED_SCOPE_MISMATCH')
def evaluate_check(id,row,c):
 context(c);need(id in CHECKS,'UNKNOWN_CHECK');need(isinstance(row,dict) and row.get('id')==id,'WRONG_CHECK')
 need(row.get('context_sha256')==digest(c),'CONTEXT_BINDING_MISMATCH')
 need(row.get('collector_manifest_sha256')==c['collector_manifest_sha256'] and row.get('verifier_manifest_sha256')==c['verifier_manifest_sha256'],'VERIFIER_BINDING_MISMATCH')
 need(row.get('collection_session')==c['collection_session'] and row.get('collection_UTC'),'COLLECTION_BINDING_MISSING')
 need(row.get('unobserved_objects')==[] and row.get('api_errors')==[] and row.get('enumeration_complete') is True,'INCOMPLETE_RAW_OBSERVATION')
 need(row.get('observer_token_sha256')==c.get('expected_observer_token_sha256') and c.get('expected_observer_token_sha256'),'OBSERVER_NOT_BOUND')
 need(row.get('raw_api_trace') and all(isinstance(v,dict) and v.get('status')==0 for v in row['raw_api_trace']),'RAW_API_TRACE_MISSING')
 if id=='migration_no_admin_agent_contexts':
  for k in ('processes','services','tasks'):need(isinstance(row.get(k),list),'MIGRATION_ENUMERATION_MISSING')
  need(row.get('agent_reachable_admin_sids')==[],'AGENT_ADMIN_AUTHORITY_REMAINS')
  rows=row['processes']+row['services']+row['tasks'];need(rows,'EMPTY_MIGRATION_INVENTORY')
  for r in rows:
   need(r.get('actor') in ('agent','human','system') and r.get('identity_sha256'),'UNCLASSIFIED_LAUNCH_CONTEXT')
   if r['actor']=='agent':need(not r.get('elevated') and r.get('linked_token') is None and not set(r.get('groups',[]))&set(c['forbidden_agent_groups']) and r.get('sid') not in c['trusted_maintenance_sids'],'AGENT_PRIVILEGED_CONTEXT')
 elif id in ('stage_effective_exclusion','evidence_parent_effective_exclusion','policy_ancestor_effective_exclusion'):
  expected=c['expected_objects'].get(id);need(expected,'OBJECT_SCOPE_MISSING');actual=row.get('objects');need(isinstance(actual,list) and len(actual)==len(expected),'OBJECT_SCOPE_MISMATCH');need({r['object_id'] for r in actual}==set(expected),'OBJECT_SCOPE_MISMATCH')
  for r in actual:
   e=expected[r['object_id']];need(r.get('owner_sid')==e['owner_sid'] and r.get('sddl')==e['sddl'] and r.get('file_id')==e['file_id'] and r.get('reparse_tag')==0 and r.get('dacl_protected') is True,'OBJECT_IDENTITY_OR_DACL_MISMATCH')
  requested={(p,o,m) for p in c['expected_principals'] for o in expected for m in MASKS};matrix=row.get('access_matrix',[]);keys=[(r['token_id'],r['object_id'],r['requested_mask']) for r in matrix];need(len(keys)==len(set(keys)) and set(keys)==requested,'INCOMPLETE_EFFECTIVE_RIGHTS_MATRIX')
  for r in matrix:
   need(r.get('api_status')==0 and r.get('token_proof_sha256')==c['expected_token_proofs'][r['token_id']],'ACCESS_QUERY_OR_TOKEN_PROOF_FAILED')
   key=r['token_id']+'|'+r['object_id']+'|'+str(r['requested_mask']);want=c['expected_access_grants'][id][key]
   need(r.get('granted_mask')==want,'EFFECTIVE_ACCESS_MISMATCH')
   if r['token_id'] in c['agent_tokens']:need(r['granted_mask']==0,'AGENT_WRITABLE_OBJECT')
 elif id=='LSA_rights':
  rows=row.get('sid_rights',{});need(set(rows)==set(c['expected_lsa_rights']),'INCOMPLETE_LSA_SCOPE')
  for sid,rights in rows.items():
   need(sorted(rights)==sorted(c['expected_lsa_rights'][sid]),'LSA_RIGHTS_MISMATCH')
   if sid in c['agent_reachable_sids']:need(not set(rights)&BYPASS,'AGENT_LSA_BYPASS_PRIVILEGE')
 elif id=='native_script_signature':
  rows=row.get('files',[]);need(len(rows)==len(c['signed_files']) and {r['path'] for r in rows}==set(c['signed_files']),'SIGNED_SET_INCOMPLETE')
  for r in rows:
   e=c['signed_files'][r['path']];need(r.get('signed_sha256')==e['signed_sha256'] and r.get('unsigned_sha256')==e['unsigned_sha256'] and r.get('signature_relation_sha256')==e['signature_relation_sha256'],'SIGNED_SOURCE_RELATION_MISMATCH');need(r.get('signer_thumbprint') in c['expected_signers'] and r.get('WinVerifyTrust_status')==0 and r.get('chain_policy_status')==0 and r.get('revocation_status')==0,'SIGNATURE_NOT_QUALIFIED')
  need(row.get('trust_store_inventory')==c['expected_trust_store_inventory'],'TRUST_STORE_DRIFT')
 elif id=='module_and_DLL_load_context':
  need(row.get('runtime')==c['expected_runtime'] and row['runtime'].get('PSEdition')=='Desktop' and row['runtime'].get('PSHOME', '').lower()==r'C:\Windows\System32\WindowsPowerShell\v1.0'.lower(),'UNQUALIFIED_NATIVE_RUNTIME')
  need(row.get('module_hashes')==c['expected_modules'] and bool(row['module_hashes']),'MODULE_LOAD_MISMATCH');need(row.get('environment')==c['expected_environment'],'ENVIRONMENT_MISMATCH');need(not any(k.upper().startswith(('COR_','COMPLUS_')) for k in row['environment']),'PROFILER_ENVIRONMENT_REFUSED')
 elif id=='launch_feasibility':
  processes=row.get('processes',[]);need(len(processes)==4 and {p['sid'] for p in processes}==set(c['expected_role_sids']),'ROLE_PROCESS_SCOPE_MISMATCH')
  for p in processes:
   need(p.get('parent_observed') is True and p.get('retained_process_identity') and p.get('starttime') and p.get('owner_sid')==p['sid'],'ROLE_PARENT_PROOF_MISSING')
   need(p.get('TokenType')==1 and p.get('TokenElevationType')==1 and p.get('elevated') is False and p.get('linked_token') is None and p.get('integrity') in (4096,8192),'ROLE_TOKEN_REFUSED')
   need(p.get('groups')==c['expected_token_groups'][p['sid']] and p.get('privileges')==c['expected_privileges'][p['sid']] and p.get('image_sha256')==c['expected_role_image_sha256'] and p.get('desktop_session')==c['expected_desktop_session'],'ROLE_IDENTITY_MISMATCH')
   need(not {x['name'] for x in p['privileges']}&BYPASS,'ROLE_BYPASS_PRIVILEGE')
  expected={(s,t,a) for s in c['expected_role_sids'] for t in c['expected_canaries'] for a in ('create','write','append','delete','rename','replace','WRITE_DAC','WRITE_OWNER')};rows=row.get('negative_access',[]);keys=[(r['sid'],r['target'],r['action']) for r in rows];need(len(keys)==len(set(keys)) and set(keys)==expected,'NEGATIVE_TEST_SCOPE_INCOMPLETE')
  for r in rows:need(r.get('win32_error')==5 and r.get('before_sha256')==r.get('after_sha256') and r.get('before_sha256') and r.get('cleanup_status')=='RECORDED_COMPLETE','RUNTIME_DENIAL_NOT_ESTABLISHED')
 elif id=='all_local_group_queries':need(row.get('groups')==c['expected_group_closure'] and bool(row.get('groups')) and row.get('query_errors')==[],'LOCAL_GROUP_SCOPE_MISMATCH')
 elif id=='maintenance_token':
  t=row.get('token',{});need(t.get('sid')==c['maintenance_sid'] and t.get('TokenType')==1 and t.get('TokenElevationType')==2 and t.get('elevated') is True and t.get('owner_sid')==c['expected_maintenance_owner'],'MAINTENANCE_TOKEN_REFUSED');need(t.get('groups')==c['expected_maintenance_groups'] and t.get('privileges')==c['expected_maintenance_privileges'] and t.get('image_sha256')==c['expected_maintenance_image_sha256'],'MAINTENANCE_CONTEXT_MISMATCH')
 return {'id':id,'predicate_result':'CONSISTENT_OFFLINE_DATA','host_qualified':False,'execution_authority':False}
def evaluate_bundle(bundle,expected_context):
 context(expected_context);need(set(bundle)==set(CHECKS),'TEN_CHECK_SET_INCOMPLETE')
 results=[evaluate_check(n,bundle[n],expected_context) for n in CHECKS]
 return {'classification':'PREDICATES_CONSISTENT_REQUIRES_AUTHENTICATED_COLLECTION_AND_INDEPENDENT_REVIEW','checks':results,'operational_qualification':False,'execution_authority':False,'policy_adoption':False}

_semantic_check=evaluate_check
def evaluate_check(id,row,c):
 try:return _semantic_check(id,row,c)
 except EvidenceRefusal:raise
 except (KeyError,TypeError,IndexError,ValueError) as e:raise EvidenceRefusal('INCOMPLETE_OR_MALFORMED_EVIDENCE:'+str(e)) from e
_semantic_bundle=evaluate_bundle
def evaluate_bundle(bundle,expected_context):
 try:return _semantic_bundle(bundle,expected_context)
 except EvidenceRefusal:raise
 except (KeyError,TypeError,IndexError,ValueError) as e:raise EvidenceRefusal('INCOMPLETE_OR_MALFORMED_EVIDENCE:'+str(e)) from e

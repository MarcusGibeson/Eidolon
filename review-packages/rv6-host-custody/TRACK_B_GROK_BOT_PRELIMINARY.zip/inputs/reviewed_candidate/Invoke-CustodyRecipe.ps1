#Requires -Version 5.1
# PROPOSED ONLY: no execution/adoption authority supplied by this file.
[CmdletBinding()]
param([ValidateSet('Plan','CreateAccounts','CreateStorage','InitializeRoleProfiles','DisableCreatedAccounts','VerifyReadOnly')][string]$Action='Plan',
 [string]$RecipeManifestSha256,[switch]$Execute,[string]$CustodianBinding,[string]$CustodianBindingSha256,
 [string]$PreflightFile,[string]$PreflightSha256,[string]$AuthorizationFile,[string]$AuthorizationSha256,
 [string]$HostApprovalFile,[string]$HostApprovalSha256,[string]$IdentityReceipt,[string]$IdentityReceiptSha256,[string]$EvidenceRoot)
Set-StrictMode -Version Latest;$ErrorActionPreference='Stop'
if(-not $Execute -or $Action -eq 'Plan'){[pscustomobject]@{kind='PROPOSED_ONLY';execution_authorized=$false;custodian='GLADOS_2POINT0\EidolonCustodian';mandatory_holds='Signing, migration, protected stage, qualified effective-rights and exact host/project grants';accounts_created=0}|ConvertTo-Json;return}
# Prospective signed entry point support. Must start in a new pinned -NoProfile
# Windows process FROM protected staging; it cannot secure its own mutable origin.
function Load-VerifiedRecipe([string]$ExpectedManifest){
 $env:PSModulePath=Join-Path $PSHOME 'Modules'
 Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1') -ErrorAction Stop
 Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Management\Microsoft.PowerShell.Management.psd1') -ErrorAction Stop
 if([IO.Path]::GetFullPath($PSScriptRoot) -ine 'C:\ProgramData\EidolonMaintenance\staging\custody-r2'){throw 'Unqualified staging path'}
 # Minimal guard is duplicated before loading any support bytes.
 $p=$PSScriptRoot
 while($p){$i=Get-Item -Force -LiteralPath $p;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Stage ancestor alias'};$n=[IO.Path]::GetDirectoryName($p);if($n -eq $p){break};$p=$n}
 $a=Get-Acl -LiteralPath $PSScriptRoot
 if(-not $a.AreAccessRulesProtected -or $a.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne 'S-1-5-32-544'){throw 'Unprotected stage'}
 $trusted=@();foreach($r in $a.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])){if($r.IsInherited -or $r.AccessControlType -ne 'Allow'){throw 'Unexpected staging ACE'};$sid=$r.IdentityReference.Value;if($sid -eq 'S-1-3-4'){if([int]$r.FileSystemRights -ne 131072){throw 'Bad owner rights'}}elseif($sid -notin @('S-1-5-18','S-1-5-32-544') -or [int]$r.FileSystemRights -ne 2032127){throw 'Stage writable/readable by unexpected principal'}else{$trusted+=$sid}}
 if(@($trusted|Select-Object -Unique).Count -ne 2){throw 'Missing trusted stage principals'}
 $hash={param([byte[]]$b)$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($b))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
 $raw=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'RECIPE_MANIFEST.json'))
 if((& $hash $raw) -cne $ExpectedManifest){throw 'Externally pinned manifest mismatch'}
 $m=[Text.Encoding]::UTF8.GetString($raw)|ConvertFrom-Json;$verified=@{};$names=@('RECIPE_MANIFEST.json')
 foreach($row in $m.files){if($row.name -cnotmatch '^[A-Za-z0-9_.-]+$'){throw 'Nonlocal member'};if($verified.ContainsKey($row.name)){throw 'Duplicate recipe member'};$q=Join-Path $PSScriptRoot $row.name;$i=Get-Item -Force -LiteralPath $q;if($i.PSIsContainer -or ($i.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Recipe member alias/type'};$bytes=[IO.File]::ReadAllBytes($q);if($bytes.Length -ne $row.bytes -or (& $hash $bytes) -cne $row.sha256){throw 'Recipe member mismatch'};$verified[$row.name]=$bytes;$names+=$row.name}
 $actual=@(Get-ChildItem -Force -LiteralPath $PSScriptRoot|ForEach-Object {$_.Name}|Sort-Object);$wanted=@($names|Sort-Object)
 if(($actual -join "`n") -cne ($wanted -join "`n")){throw 'Unlisted/missing recipe member'}
 return $verified
}

$verified=Load-VerifiedRecipe $RecipeManifestSha256
. ([ScriptBlock]::Create([Text.Encoding]::UTF8.GetString($verified['Secure-Recipe.ps1'])))
$config=[Text.Encoding]::UTF8.GetString($verified['PROVISIONING_CONFIG.json'])|ConvertFrom-Json
$binding=Read-ApprovedJson $CustodianBinding $CustodianBindingSha256
$ledger=Read-ApprovedJson $PreflightFile $PreflightSha256
$auth=Read-ApprovedJson $AuthorizationFile $AuthorizationSha256
$hostGrant=Read-ApprovedJson $HostApprovalFile $HostApprovalSha256
Assert-True ($auth.action -ceq $Action -and $hostGrant.action -ceq $Action) 'Wrong exact action'
Assert-True ($auth.preflight_sha256 -ceq $PreflightSha256 -and $auth.custodian_binding_sha256 -ceq $CustodianBindingSha256) 'Preflight/context not bound'
$actualBinding=[ordered]@{entrypoint='Invoke-CustodyRecipe.ps1';action=$Action;recipe_manifest_sha256=$RecipeManifestSha256;evidence_root=[IO.Path]::GetFullPath($EvidenceRoot);custodian_binding_path=[IO.Path]::GetFullPath($CustodianBinding);custodian_binding_sha256=$CustodianBindingSha256;preflight_path=[IO.Path]::GetFullPath($PreflightFile);preflight_sha256=$PreflightSha256;identity_receipt_path=$IdentityReceipt;identity_receipt_sha256=$IdentityReceiptSha256}
$actualCommandHash=Bytes-Sha ([Text.UTF8Encoding]::new($false).GetBytes(($actualBinding|ConvertTo-Json -Depth 6 -Compress)))
Assert-True ($auth.command_binding_sha256 -ceq $actualCommandHash -and $hostGrant.command_binding_sha256 -ceq $actualCommandHash) 'Actual command binding differs'
Assert-PreflightLedger $ledger $binding
Assert-True ([Security.Principal.WindowsIdentity]::GetCurrent().Name -ieq $binding.custodian_account) 'Wrong actual maintenance account before compilation'
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.LocalAccounts\Microsoft.PowerShell.LocalAccounts.psd1') -ErrorAction Stop
# Compile ONLY already verified source strings in a pre-established admin-only temp.
$compile='C:\ProgramData\EidolonMaintenance\compile-tmp';Assert-AdminStage $compile
$env:TEMP=$compile;$env:TMP=$compile
Add-Type -TypeDefinition ([Text.Encoding]::UTF8.GetString($verified['TokenNative.cs'])) -ErrorAction Stop
Assert-FutureExecution $binding $auth $hostGrant $ledger
Assert-True ($auth.transaction_id -cmatch '^[0-9a-f]{32}$') 'Exact transaction required'
$expected='C:\ProgramData\EidolonMaintenance\evidence\'+$auth.transaction_id
Assert-True ([IO.Path]::GetFullPath($EvidenceRoot) -ieq $expected -and $auth.evidence_root -ieq $expected) 'Unapproved evidence root'
Assert-AdminStage (Split-Path -Parent $expected);Assert-NoAlias $expected
Assert-True (-not (Test-Path -LiteralPath $expected)) 'Attempt exists; preserve and stop'
Add-Type -TypeDefinition ([Text.Encoding]::UTF8.GetString($verified['NativeDirectory.cs'])) -ErrorAction Stop
$adminSddl='O:BAD:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;RC;;;OW)'
[EidolonCustodyRecipe.NativeDirectory]::CreateNew($expected,$adminSddl)
$events=[Collections.Generic.List[object]]::new();$created=[Collections.Generic.List[object]]::new()
try {
 $events.Add(@{kind='INTENT';action=$Action;authority=$AuthorizationSha256;host=$HostApprovalSha256;preflight=$PreflightSha256})
 if($Action -eq 'CreateAccounts'){
  # Establish group-query feasibility before the first New-LocalUser.
  foreach($g in Get-LocalGroup -ErrorAction Stop){[void]@(Get-LocalGroupMember -SID $g.SID -ErrorAction Stop)}
  foreach($name in $config.accounts){Assert-True (-not (Get-LocalUser -Name $name -ErrorAction SilentlyContinue)) 'Existing role name; no reuse'}
  foreach($name in $config.accounts){$password=Read-Host ('Human supplies only new '+$name+' password') -AsSecureString;$u=New-LocalUser -Name $name -Password $password -AccountNeverExpires -Disabled -ErrorAction Stop;$row=@{name=$name;SID=$u.SID.Value};$created.Add($row);$events.Add(@{kind='CREATED_DISABLED';identity=$row});Add-LocalGroupMember -SID 'S-1-5-32-545' -Member $name -ErrorAction Stop}
  Exact-Output (Join-Path $expected 'IDENTITIES.json') ([Text.UTF8Encoding]::new($false).GetBytes((@{recipe_manifest_sha256=$RecipeManifestSha256;created=@($created.ToArray());all_disabled=$true}|ConvertTo-Json -Depth 10)))
 }else{
  $ids=Read-ApprovedJson $IdentityReceipt $IdentityReceiptSha256
  Assert-True ($auth.identity_receipt_sha256 -ceq $IdentityReceiptSha256 -and $ids.recipe_manifest_sha256 -ceq $RecipeManifestSha256) 'Wrong identity receipt'
  Assert-True (@($ids.created).Count -ge 1 -and @($ids.created).Count -le 4) 'Identity bound exceeded'
  if($Action -eq 'DisableCreatedAccounts'){
   $errors=@();foreach($row in $ids.created){try{Assert-True ($row.name -cin $config.accounts) 'Unknown role';$u=Get-LocalUser -SID $row.SID -ErrorAction Stop;$events.Add(@{kind='DISABLE_INTENT';SID=$row.SID;actual_name=$u.Name});Disable-LocalUser -SID $u.SID -ErrorAction Stop;$events.Add(@{kind='DISABLED';SID=$row.SID})}catch{$errors+=$_.Exception.Message;$events.Add(@{kind='DISABLE_FAILED';SID=$row.SID;error=$_.Exception.Message})}};Assert-True ($errors.Count -eq 0) ($errors -join '; ')
  }else{
   Assert-True (@($ids.created).Count -eq 4) 'Four exact disabled workers required'
   foreach($row in $ids.created){$u=Get-LocalUser -SID $row.SID -ErrorAction Stop;Assert-True ($u.Name -ceq $row.name -and $row.name -cin $config.accounts -and -not $u.Enabled) 'Identity changed or enabled unexpectedly'}
   if($Action -eq 'CreateStorage'){
    foreach($d in $config.directories){Assert-NoAlias $d.path;Assert-True (-not (Test-Path -LiteralPath $d.path)) 'Storage exists; preserve and stop'}
    foreach($d in $config.directories){$read=@();foreach($n in $d.readers){$read+=@($ids.created|Where-Object {$_.name -ceq $n})[0].SID};$traverse=@();foreach($n in $d.traverse_only){$traverse+=@($ids.created|Where-Object {$_.name -ceq $n})[0].SID};$s=Custody-Sddl $binding.custodian_SID $read $traverse;[EidolonCustodyRecipe.NativeDirectory]::CreateNew($d.path,$s);$events.Add(@{kind='PROTECTED_DIRECTORY_CREATED';path=$d.path;sddl=$s})}
   }elseif($Action -eq 'InitializeRoleProfiles'){
    foreach($row in $ids.created){$wanted='C:\Users\'+$row.name;Assert-True (-not (Test-Path -LiteralPath $wanted)) 'Existing role profile; do not reuse';$actual=[EidolonCustodyRecipe.NativeDirectory]::CreateRoleProfile($row.SID,$row.name);Assert-True ($actual -ieq $wanted) 'Unexpected created profile';$events.Add(@{kind='PROFILE_CREATED';SID=$row.SID;path=$actual})}
   }elseif($Action -eq 'VerifyReadOnly'){
    foreach($d in $config.directories){Assert-NoAlias $d.path;$a=Get-Acl -LiteralPath $d.path;$events.Add(@{kind='ACL_ENTRY_OBSERVATION_NOT_EFFECTIVE_ACCESS';path=$d.path;owner=$a.Owner;sddl=$a.Sddl;runtime_denial_tested=$false})}
   }
  }
 }
 $events.Add(@{kind='TERMINAL';exit=0;accepted=$false;policy_adopted=$false})
}catch{$events.Add(@{kind='FAILED';message=$_.Exception.Message;created=@($created.ToArray());no_automatic_cleanup=$true});throw}
finally{Exact-Output (Join-Path $expected 'EVENTS.json') ([Text.UTF8Encoding]::new($false).GetBytes((@($events.ToArray())|ConvertTo-Json -Depth 12)))}

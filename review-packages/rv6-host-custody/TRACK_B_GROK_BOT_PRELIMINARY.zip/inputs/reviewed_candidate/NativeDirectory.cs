// PROPOSED ONLY. Compile/call only under a separately approved human execution.
using System;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Text;
[assembly: DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
namespace EidolonCustodyRecipe {
  public static class NativeDirectory {
    [StructLayout(LayoutKind.Sequential)] struct SECURITY_ATTRIBUTES {
      public int nLength;
      public IntPtr lpSecurityDescriptor;
      [MarshalAs(UnmanagedType.Bool)] public bool bInheritHandle;
    }
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool ConvertStringSecurityDescriptorToSecurityDescriptorW(
      string sddl, uint revision, out IntPtr descriptor, out uint size);
    [DllImport("kernel32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    static extern bool CreateDirectoryW(string path, ref SECURITY_ATTRIBUTES attributes);
    [DllImport("kernel32.dll")] static extern IntPtr LocalFree(IntPtr pointer);
    [DllImport("userenv.dll", CharSet=CharSet.Unicode)]
    static extern int CreateProfile(string sid, string name, StringBuilder path, uint length);
    public static string CreateRoleProfile(string sid, string name) {
      StringBuilder path = new StringBuilder(32768);
      int result = CreateProfile(sid, name, path, 32768);
      if (result != 0) throw new InvalidOperationException("CreateProfile HRESULT " + result.ToString("X8"));
      return path.ToString();
    }
    public static void CreateNew(string path, string sddl) {
      IntPtr descriptor; uint size;
      if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(sddl, 1, out descriptor, out size))
        throw new Win32Exception(Marshal.GetLastWin32Error());
      try {
        SECURITY_ATTRIBUTES attributes = new SECURITY_ATTRIBUTES {
          nLength = Marshal.SizeOf(typeof(SECURITY_ATTRIBUTES)),
          lpSecurityDescriptor = descriptor, bInheritHandle = false
        };
        // Existing target is an error. Never return/reuse an existing directory.
        if (!CreateDirectoryW(path, ref attributes))
          throw new Win32Exception(Marshal.GetLastWin32Error());
      } finally { LocalFree(descriptor); }
    }
  }
}

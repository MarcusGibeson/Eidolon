using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Security.Principal;
using System.Text;
[assembly: DefaultDllImportSearchPaths(DllImportSearchPath.System32)]
// PROPOSED READ-ONLY token inspection. Not compiled or executed during preparation.
public static class EidolonTokenNative {
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool OpenProcessToken(IntPtr p,uint access,out IntPtr t);
 [DllImport("advapi32.dll",SetLastError=true)] static extern bool GetTokenInformation(IntPtr t,int cls,IntPtr b,int len,out int needed);
 [DllImport("advapi32.dll",CharSet=CharSet.Unicode,SetLastError=true)] static extern bool LookupPrivilegeName(string system,ref Luid luid,StringBuilder name,ref int size);
 [DllImport("kernel32.dll")] static extern IntPtr GetCurrentProcess();
 [DllImport("kernel32.dll")] static extern bool CloseHandle(IntPtr h);
 [StructLayout(LayoutKind.Sequential)] struct SidAttr {public IntPtr Sid;public uint Attributes;}
 [StructLayout(LayoutKind.Sequential)] struct GroupHead {public uint Count;public SidAttr First;}
 [StructLayout(LayoutKind.Sequential)] struct Luid {public uint Low;public int High;}
 [StructLayout(LayoutKind.Sequential)] struct Priv {public Luid Id;public uint Attributes;}
 public class Group {public string SID;public uint Attributes;public bool Enabled;public bool DenyOnly;}
 public class Privilege {public string Name;public uint Attributes;}
 public class Report {public string SID;public int TokenType;public int ElevationType;public bool Elevated;public string LinkedToken;public string IntegritySID;public List<Group> Groups;public List<Privilege> Privileges;}
 static IntPtr Info(IntPtr token,int cls) {
  int n;GetTokenInformation(token,cls,IntPtr.Zero,0,out n);
  if(n<=0 || n>1048576)throw new Win32Exception(Marshal.GetLastWin32Error());
  IntPtr b=Marshal.AllocHGlobal(n);
  if(!GetTokenInformation(token,cls,b,n,out n)){int e=Marshal.GetLastWin32Error();Marshal.FreeHGlobal(b);throw new Win32Exception(e);}return b;
 }
 static int Integer(IntPtr token,int cls){IntPtr b=Info(token,cls);try{return Marshal.ReadInt32(b);}finally{Marshal.FreeHGlobal(b);}}
 static string SidAt(IntPtr token,int cls){IntPtr b=Info(token,cls);try{return new SecurityIdentifier(Marshal.ReadIntPtr(b)).Value;}finally{Marshal.FreeHGlobal(b);}}
 public static Report Current(){return ProcessHandle(GetCurrentProcess());}
 public static Report ProcessHandle(IntPtr process) {
  IntPtr t;if(!OpenProcessToken(process,8,out t))throw new Win32Exception(Marshal.GetLastWin32Error());
  try {
   var r=new Report();r.SID=SidAt(t,1);r.TokenType=Integer(t,8);r.ElevationType=Integer(t,18);r.Elevated=Integer(t,20)!=0;r.IntegritySID=SidAt(t,25);
   // MS TOKEN_ELEVATION_TYPE explicitly defines Default as having no linked token.
   // Full/Limited are unacceptable for workers regardless of linked-token handle.
   r.LinkedToken=r.ElevationType==1?"ABSENT_BY_TOKEN_ELEVATION_TYPE_DEFAULT":"PRESENT_OR_UNACCEPTABLE_ELEVATION_TYPE";
   r.Groups=new List<Group>();IntPtr g=Info(t,2);
   try{int count=Marshal.ReadInt32(g);if(count<0||count>1024)throw new Exception("Group limit");int start=Marshal.OffsetOf(typeof(GroupHead),"First").ToInt32();int stride=Marshal.SizeOf(typeof(SidAttr));for(int i=0;i<count;i++){var a=(SidAttr)Marshal.PtrToStructure(IntPtr.Add(g,start+i*stride),typeof(SidAttr));r.Groups.Add(new Group{SID=new SecurityIdentifier(a.Sid).Value,Attributes=a.Attributes,Enabled=(a.Attributes&4)!=0,DenyOnly=(a.Attributes&16)!=0});}}
   finally{Marshal.FreeHGlobal(g);}
   r.Privileges=new List<Privilege>();IntPtr q=Info(t,3);
   try{int count=Marshal.ReadInt32(q);if(count<0||count>256)throw new Exception("Privilege limit");int stride=Marshal.SizeOf(typeof(Priv));for(int i=0;i<count;i++){var a=(Priv)Marshal.PtrToStructure(IntPtr.Add(q,4+i*stride),typeof(Priv));int n=0;LookupPrivilegeName(null,ref a.Id,null,ref n);if(n<1||n>256)throw new Exception("Privilege name unavailable");var name=new StringBuilder(n+1);int cap=name.Capacity;if(!LookupPrivilegeName(null,ref a.Id,name,ref cap))throw new Win32Exception(Marshal.GetLastWin32Error());r.Privileges.Add(new Privilege{Name=name.ToString(),Attributes=a.Attributes});}}
   finally{Marshal.FreeHGlobal(q);}return r;
  } finally{CloseHandle(t);}
 }
}

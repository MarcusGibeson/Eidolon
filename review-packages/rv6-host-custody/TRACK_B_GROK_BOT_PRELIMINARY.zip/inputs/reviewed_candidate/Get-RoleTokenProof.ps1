#Requires -Version 5.1
# PROPOSED signed child. Does not compile code or trust WindowsIdentity.Groups.
param([Parameter(Mandatory=$true)][string]$ExpectedSid,[Parameter(Mandatory=$true)][string]$ExpectedAccount,
 [Parameter(Mandatory=$true)][string]$AssemblyPath,[Parameter(Mandatory=$true)][string]$AssemblySha256,
 [Parameter(Mandatory=$true)][string]$SupportPath,[Parameter(Mandatory=$true)][string]$SupportSha256)
Set-StrictMode -Version Latest;$ErrorActionPreference='Stop'
$env:PSModulePath=Join-Path $PSHOME 'Modules'
function Sha([byte[]]$b){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($b))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
foreach($p in @($AssemblyPath,$SupportPath)){$q=[IO.Path]::GetFullPath($p);if($q -notlike 'C:\ProgramData\EidolonPolicy\qualification\*'){throw 'Unqualified proof bundle'};while($q){$i=Get-Item -Force -LiteralPath $q;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Bundle alias'};$n=[IO.Path]::GetDirectoryName($q);if($n -eq $q){break};$q=$n}}
$asm=[IO.File]::ReadAllBytes($AssemblyPath);if((Sha $asm) -cne $AssemblySha256){throw 'Native token assembly changed'}
$support=[IO.File]::ReadAllBytes($SupportPath);if((Sha $support) -cne $SupportSha256){throw 'Token support changed'}
[void][Reflection.Assembly]::Load($asm)
. ([ScriptBlock]::Create([Text.Encoding]::UTF8.GetString($support)))
$r=[EidolonTokenNative]::Current();$actual=[Security.Principal.WindowsIdentity]::GetCurrent()
if($actual.Name -ine $ExpectedAccount){throw 'Wrong actual account'}
$allowed=@('S-1-1-0','S-1-2-0','S-1-2-1','S-1-5-4','S-1-5-11','S-1-5-15','S-1-5-32-545','S-1-5-64-10','S-1-5-113','S-1-16-4096','S-1-16-8192')
Assert-WorkerToken $r $ExpectedSid $allowed
[ordered]@{kind='ACTUAL_ROLE_TOKEN_PROOF';SID=$r.SID;account=$actual.Name;pid=$PID;token=$r;runtime=[string]$PSVersionTable.PSVersion;effective_access_tested=$false;policy_adopted=$false}|ConvertTo-Json -Depth 10

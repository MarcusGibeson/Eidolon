# Prospective signed entry point support. Must start in a new pinned -NoProfile
# Windows process FROM protected staging; it cannot secure its own mutable origin.
function Load-VerifiedRecipe([string]$ExpectedManifest){
 $env:PSModulePath=Join-Path $PSHOME 'Modules'
 Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1') -ErrorAction Stop
 Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Management\Microsoft.PowerShell.Management.psd1') -ErrorAction Stop
 if([IO.Path]::GetFullPath($PSScriptRoot) -ine 'C:\ProgramData\EidolonMaintenance\staging\custody-r2'){throw 'Unqualified staging path'}
 # Minimal guard is duplicated before loading any support bytes.
 $p=$PSScriptRoot
 while($p){$i=Get-Item -Force -LiteralPath $p;if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Stage ancestor alias'};$n=[IO.Path]::GetDirectoryName($p);if($n -eq $p){break};$p=$n}
 $a=Get-Acl -LiteralPath $PSScriptRoot
 if(-not $a.AreAccessRulesProtected -or $a.GetOwner([Security.Principal.SecurityIdentifier]).Value -ne 'S-1-5-32-544'){throw 'Unprotected stage'}
 $trusted=@();foreach($r in $a.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier])){if($r.IsInherited -or $r.AccessControlType -ne 'Allow'){throw 'Unexpected staging ACE'};$sid=$r.IdentityReference.Value;if($sid -eq 'S-1-3-4'){if([int]$r.FileSystemRights -ne 131072){throw 'Bad owner rights'}}elseif($sid -notin @('S-1-5-18','S-1-5-32-544') -or [int]$r.FileSystemRights -ne 2032127){throw 'Stage writable/readable by unexpected principal'}else{$trusted+=$sid}}
 if(@($trusted|Select-Object -Unique).Count -ne 2){throw 'Missing trusted stage principals'}
 $hash={param([byte[]]$b)$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($b))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
 $raw=[IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'RECIPE_MANIFEST.json'))
 if((& $hash $raw) -cne $ExpectedManifest){throw 'Externally pinned manifest mismatch'}
 $m=[Text.Encoding]::UTF8.GetString($raw)|ConvertFrom-Json;$verified=@{};$names=@('RECIPE_MANIFEST.json')
 foreach($row in $m.files){if($row.name -cnotmatch '^[A-Za-z0-9_.-]+$'){throw 'Nonlocal member'};if($verified.ContainsKey($row.name)){throw 'Duplicate recipe member'};$q=Join-Path $PSScriptRoot $row.name;$i=Get-Item -Force -LiteralPath $q;if($i.PSIsContainer -or ($i.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Recipe member alias/type'};$bytes=[IO.File]::ReadAllBytes($q);if($bytes.Length -ne $row.bytes -or (& $hash $bytes) -cne $row.sha256){throw 'Recipe member mismatch'};$verified[$row.name]=$bytes;$names+=$row.name}
 $actual=@(Get-ChildItem -Force -LiteralPath $PSScriptRoot|ForEach-Object {$_.Name}|Sort-Object);$wanted=@($names|Sort-Object)
 if(($actual -join "`n") -cne ($wanted -join "`n")){throw 'Unlisted/missing recipe member'}
 return $verified
}

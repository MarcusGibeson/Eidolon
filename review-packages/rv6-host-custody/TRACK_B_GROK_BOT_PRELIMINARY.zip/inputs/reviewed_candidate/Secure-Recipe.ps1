# Prospective security support. Loaded only from verified in-memory bytes.
function Assert-True([bool]$Ok,[string]$Message){if(-not $Ok){throw $Message}}
function Bytes-Sha([byte[]]$Raw){$h=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($h.ComputeHash($Raw))).Replace('-','').ToLowerInvariant()}finally{$h.Dispose()}}
function Assert-NoAlias([string]$Path){$p=[IO.Path]::GetFullPath($Path);Assert-True ($p -notlike '\\*' -and $p.Substring(2) -notmatch ':') 'Local canonical path required';while($p){if(Test-Path -LiteralPath $p){Assert-True (-not ((Get-Item -Force -LiteralPath $p).Attributes -band [IO.FileAttributes]::ReparsePoint)) 'Reparse path refused'};$n=[IO.Path]::GetDirectoryName($p);if($n -eq $p){break};$p=$n}}
function Assert-AdminStage([string]$Path){
 Assert-NoAlias $Path;$a=Get-Acl -LiteralPath $Path
 Assert-True ($a.AreAccessRulesProtected -and $a.GetOwner([Security.Principal.SecurityIdentifier]).Value -eq 'S-1-5-32-544') 'Stage must be Administrators-owned with protected DACL'
 $rules=@($a.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]));$full=@()
 foreach($r in $rules){Assert-True (-not $r.IsInherited) 'Inherited staging ACE refused';Assert-True ($r.AccessControlType -eq 'Allow') 'Unexpected stage deny ACE';$sid=$r.IdentityReference.Value
  if($sid -eq 'S-1-3-4'){Assert-True ([int]$r.FileSystemRights -eq 131072) 'Owner Rights must be READ_CONTROL only'}
  else{Assert-True ($sid -in @('S-1-5-18','S-1-5-32-544') -and [int]$r.FileSystemRights -eq 2032127) 'Unexpected staging principal or rights';$full+=$sid}
 };Assert-True (@($full|Select-Object -Unique).Count -eq 2) 'Stage lacks exact SYSTEM/Administrators grants'
}
function Read-ApprovedJson([string]$Path,[string]$Hash){Assert-NoAlias $Path;Assert-AdminStage (Split-Path -Parent $Path);$b=[IO.File]::ReadAllBytes($Path);Assert-True ((Bytes-Sha $b) -ceq $Hash) 'Approval/evidence hash mismatch';[Text.Encoding]::UTF8.GetString($b)|ConvertFrom-Json}
function Assert-PreflightLedger($Ledger,$Binding){
 Assert-True ($Ledger.kind -ceq 'QUALIFIED_CUSTODY_PREFLIGHT' -and $Ledger.schema_version -eq 2) 'Qualified preflight schema required'
 Assert-True ($Ledger.custodian_SID -ceq $Binding.custodian_SID -and $Ledger.recipe_manifest_sha256 -ceq $RecipeManifestSha256) 'Preflight identity mismatch'
 $required=@('migration_no_admin_agent_contexts','stage_effective_exclusion','evidence_parent_effective_exclusion','policy_ancestor_effective_exclusion','LSA_rights','native_script_signature','module_and_DLL_load_context','launch_feasibility','all_local_group_queries','maintenance_token')
 foreach($name in $required){$rows=@($Ledger.checks|Where-Object {$_.id -ceq $name});Assert-True ($rows.Count -eq 1 -and $rows[0].status -ceq 'QUALIFIED' -and $rows[0].raw_evidence_sha256 -cmatch '^[0-9a-f]{64}$' -and $rows[0].verifier_manifest_sha256 -cmatch '^[0-9a-f]{64}$') ('Missing/unknown security evidence: '+$name);[void](Read-ApprovedJson $rows[0].raw_evidence_path $rows[0].raw_evidence_sha256);[void](Read-ApprovedJson $rows[0].verifier_manifest_path $rows[0].verifier_manifest_sha256)}
 # Hashes are provenance, not human authentication. Their producer, raw inputs,
 # effective tokens and host grant must be independently qualified before use.
 Assert-True ($Ledger.unknown_count -eq 0) 'Unresolved preflight blocks provisioning'
}
function Assert-WorkerToken($Token,[string]$ExpectedSid,$AllowedGroups){
 Assert-True ($Token.SID -ceq $ExpectedSid -and $Token.TokenType -eq 1) 'Wrong primary token user/type'
 Assert-True ($Token.ElevationType -eq 1 -and -not $Token.Elevated -and $Token.LinkedToken -ceq 'ABSENT_BY_TOKEN_ELEVATION_TYPE_DEFAULT') 'Elevated/filtered/linked worker token refused'
 Assert-True ($Token.IntegritySID -in @('S-1-16-4096','S-1-16-8192')) 'Worker integrity must be low/medium'
 $users=$false
 foreach($g in $Token.Groups){$sid=$g.SID
  if($sid -eq 'S-1-5-32-545' -and $g.Enabled -and -not $g.DenyOnly){$users=$true}
  Assert-True ($sid -in $AllowedGroups -or $sid -match '^S-1-5-5-\d+-\d+$') ('Unapproved token group, including deny-only: '+$sid)
 };Assert-True $users 'Enabled standard Users membership required'
 foreach($p in $Token.Privileges){Assert-True ($p.Name -in @('SeChangeNotifyPrivilege','SeIncreaseWorkingSetPrivilege','SeTimeZonePrivilege','SeShutdownPrivilege','SeUndockPrivilege')) ('Unapproved privilege, enabled or disabled: '+$p.Name)}
}
function Custody-Sddl([string]$CustodianSid,[string[]]$Readers,[string[]]$TraverseOnly=@()){
 Assert-True ($CustodianSid -cmatch '^S-1-5-21-(\d+-){3}\d+$' -and $CustodianSid -cne 'S-1-5-21-792233167-3427833224-1744323547-1001') 'Separate approved custodian SID required'
 $s='O:'+$CustodianSid+'D:P(A;OICI;FA;;;SY)(A;OICI;FA;;;BA)(A;OICI;FA;;;'+$CustodianSid+')(A;OICI;RC;;;OW)'
 foreach($sid in $Readers){Assert-True ($sid -cmatch '^S-1-5-21-(\d+-){3}\d+$') 'Exact role SID required';$s+='(A;CI;0x1200a9;;;'+$sid+')(A;OIIO;0x120089;;;'+$sid+')'}
 foreach($sid in $TraverseOnly){Assert-True ($sid -cmatch '^S-1-5-21-(\d+-){3}\d+$') 'Exact role SID required';$s+='(A;;0x100020;;;'+$sid+')'};return $s
}
function Exact-Output([string]$Path,[byte[]]$Raw){$f=[IO.File]::Open($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None);try{$f.Write($Raw,0,$Raw.Length);$f.Flush()}finally{$f.Dispose()}}
function Assert-FutureExecution($Binding,$Authority,$HostGrant,$Ledger){
 Assert-True ($Binding.custodian_account -ceq 'GLADOS_2POINT0\EidolonCustodian') 'Dedicated custodian proposal not approved/bound'
 Assert-True ($Binding.custodian_SID -cmatch '^S-1-5-21-(\d+-){3}\d+$' -and $Binding.custodian_SID -cne 'S-1-5-21-792233167-3427833224-1744323547-1001') 'Shared/current SID cannot be custodian'
 Assert-True ([Security.Principal.WindowsIdentity]::GetCurrent().Name -ieq $Binding.custodian_account) 'Actual maintenance account differs'
 Assert-PreflightLedger $Ledger $Binding
 $token=[EidolonTokenNative]::Current();Assert-True ($token.SID -ceq $Binding.custodian_SID -and $token.Elevated -and $token.ElevationType -eq 2 -and $token.TokenType -eq 1) 'Actual dedicated elevated custodian token required'
 Assert-True ($Authority.recipe_manifest_sha256 -ceq $RecipeManifestSha256 -and $HostGrant.recipe_manifest_sha256 -ceq $RecipeManifestSha256) 'Authority targets wrong recipe'
 Assert-True ($Authority.command_binding_sha256 -ceq $HostGrant.command_binding_sha256 -and $Authority.action -ceq $HostGrant.action) 'Exact project/host commands not bound'
 Assert-True ($Authority.review_verdict -in @('PASS','PASS_WITH_NON_BLOCKING_FINDINGS') -and $Authority.review_report_sha256 -cmatch '^[0-9a-f]{64}$') 'Independent exact review required'
 Assert-True ($HostGrant.protocol -ceq 'SUPPORTED_HOST_GRANT' -and $HostGrant.raw_host_event_sha256 -cmatch '^[0-9a-f]{64}$') 'Fresh supported host grant capture required; local receipts alone are not authority'
}

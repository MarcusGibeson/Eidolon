from pathlib import Path
import json,sys,unittest,ast,hashlib
R=Path(__file__).resolve().parent;C=R/'candidate';sys.path.insert(0,str(C));attempt=int(sys.argv[1]);assert attempt in (1,2)
def put(p,d):
 with p.open('x',encoding='utf-8',newline='\n') as f:f.write(json.dumps(d,indent=2)+'\n')
contract=json.loads((C/'TEN_CHECK_CONTRACT.json').read_text());tree=ast.parse((C/'custody_predicates.py').read_text());keys=sorted({n.slice.value for n in ast.walk(tree) if isinstance(n,ast.Subscript) and isinstance(n.value,ast.Name) and n.value.id=='c' and isinstance(n.slice,ast.Constant) and isinstance(n.slice.value,str)})
if attempt==1:
 contract['context_required']=sorted(set(contract['context_required'])|set(keys));contract['dangerous_rights']['combined_mask']=sum(contract['dangerous_rights'].values())
 for row in contract['checks']:row['verifier']='custody_predicates.py:evaluate_check';row['predicate_dispatch_id']=row['id']
 (C/'TEN_CHECK_CONTRACT.json').write_text(json.dumps(contract,indent=2)+'\n',encoding='utf-8',newline='\n')
checks=[]
def check(name,value):checks.append({'name':name,'passed':bool(value)})
seq=json.loads((C/'PROVISIONING_SEQUENCE.json').read_text());boot=json.loads((C/'BOOTSTRAP_PLAN.json').read_text());findings=json.loads((C/'FINDING_DISPOSITIONS.json').read_text());commands=json.loads((C/'PROSPECTIVE_COMMANDS.json').read_text())
check('12 ordered phases',[p['phase'] for p in seq['phases']]==list(range(1,13)))
for p in seq['phases']:check('acyclic prerequisites phase'+str(p['phase']),all(d<p['phase'] for d in p['requires']))
check('launch after creation',seq['phases'][6]['name']=='QUALIFIED_ROLE_PROCESS_LAUNCH' and seq['phases'][3]['name']=='CREATE_IDENTIFY_DISABLED_ROLE_ACCOUNTS')
check('full ledger after negative tests',seq['phases'][9]['name']=='ALL_TEN_LEDGER_EVALUATION' and seq['phases'][8]['name']=='BOUNDED_NEGATIVE_ACCESS')
check('no circular launch gate','launch_feasibility' in seq['create_accounts_excludes'] and 'launch_feasibility' not in seq['precreate_subset'])
check('exact ten predicates',len(contract['checks'])==10 and len({r['id'] for r in contract['checks']})==10)
for r in contract['checks']:
 check(r['id']+' exact verifier',r['verifier']=='custody_predicates.py:evaluate_check')
 check(r['id']+' exact raw schema',bool(r['required_raw_fields']) and bool(r['collector_APIs']) and r['failure'].startswith('REFUSED'))
check('complete context keys',set(keys)<=set(contract['context_required']))
check('all25 findings preserved',len(findings['entries'])==25 and all(not r['formal_closure'] and r['original']['classification']==r['classification_preserved'] for r in findings['entries']))
check('both blockers present',{'R2-B01','R2-B02'}<={r['original']['id'] for r in findings['entries']})
check('all10 new nonblocking retained',len(findings['new_nonblocking'])==10)
check('all protected ancestors specified',len(boot['directories'])==6 and all(s.startswith('O:BAG:BAD:P') and 'RC;;;OW' in s for s in boot['directories'].values()))
check('no signed identity invented',boot['signing']['actual_key_exists']=='UNVERIFIED' and boot['signing']['actual_cert_exists']=='UNVERIFIED')
check('separate signed manifest','SIGNED_OUTPUT_MANIFEST.json' in boot['signing']['manifests'])
check('bootstrap post migration',boot['order'][0].startswith('independent migration'))
check('out of band pin',any('out-of-band' in s for s in boot['order']))
check('no AllSigned bypass','no ExecutionPolicy bypass' in boot['signing']['AllSigned'])
check('unknown identities refuse','Unknown identity means refuse' in boot['rollback'])
check('disable-only rollback independent',any(r['id']=='DISABLE_CREATED_ACCOUNTS' and 'all_ten_passed' in r['excludes_forward_gates'] for r in commands['commands']))
check('all command templates unqualified',all(r.get('live_command_qualified') is False for r in commands['commands']))
for p in C.glob('*.json'):
 json.loads(p.read_text());check('JSON '+p.name,True)
for p in C.glob('*.py'):ast.parse(p.read_text());check('Python syntax '+p.name,True)
put(R/f'evidence/STATIC_ATTEMPT_{attempt}.json',{'passed':sum(r['passed'] for r in checks),'failed':sum(not r['passed'] for r in checks),'checks':checks,'actual_host_operations':0})
import test_custody_contract as T
with (R/f'evidence/PREDICATE_ATTEMPT_{attempt}.log').open('x',encoding='utf-8') as f:result=unittest.TextTestRunner(stream=f,verbosity=2).run(unittest.defaultTestLoader.loadTestsFromModule(T))
summary={'passed':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),'failed':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'static_passed':sum(r['passed'] for r in checks),'static_failed':sum(not r['passed'] for r in checks),'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in C.iterdir() if p.is_file()},'host_collection_or_provisioning':False,'synthetic_data_only':True}
put(R/f'evidence/RESULTS_ATTEMPT_{attempt}.json',summary);print(json.dumps({k:v for k,v in summary.items() if k!='source_sha256'}));raise SystemExit(0 if result.wasSuccessful() and all(r['passed'] for r in checks) else 1)
